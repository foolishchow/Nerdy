(function() {
    window.AI = window.AI || {};
    if ("${ai_evn}".length == 3) {
        AI = {
            app_url: '${app_url}',
            InterFaceIp: '${InterFaceIp}',
            InterfaceUrl: 'jike-platform',
            //个人资料头像上传url
            // UploadInterfaceUrl: '/mobile/upload/file',
            // 最长登录天数
            // longestDay: 3,
            // 个人头像前置路径
            // headpicPreffix: '${headpicPreffix}/mobile/upload/showImg?remoteFile=',
            // headpicPreffix: '${headpicPreffix}/JikeMobile/ImgUpDown/img?remoteFile=',
            // InterfaceName: '/mobile'
        }
    } else {
        AI = {
            //静态页面请求地址
            // app_url: 'http://192.168.0.150:9300',
            app_url: 'http://10.21.67.88:9200',
            wap_url: 'http://192.168.2.136:9100',
            // 后台接口请求地址
            // InterFaceIp: 'http://10.21.67.100:8080/',
            InterfaceUrl: 'jike-platform',
            // 上传文件接口
            // UploadInterfaceUrl: '/mobile/upload/file',
            //个人资料头像上传url
            // UploadInterfaceUrl:'/mobile/upload/file',
            // 最长登录天数
            // longestDay: 3,
            // 个人头像前置路径
            // headpicPreffix: 'http://10.20.16.74:8282/mobile/upload/showImg?remoteFile=',
            // headpicPreffix:'http://10.20.16.74:8181/JikeMobile/ImgUpDown/img?remoteFile=',
            // InterfaceName: '/mobile'
        }

    }
})();


