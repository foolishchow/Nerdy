(function() {
    var cache = function(key, value) {
        if (value == undefined) {
            return cache.get(key);
        } else {
            if ((typeof value).toLowerCase() != "string") value = JSON.stringify(value);
            var d = $.Deferred();
            api.setPrefs({
                key: key,
                value: value
            });
            return d.promise();
        }
    };
    cache.get = function(key) {
        var userName = api.getPrefs({
            sync: true,
            key: key
        });
        try {
            var a = JSON.parse(userName);
            userName = a;
        } catch (e) {

        }
        return userName;
    };
    cache.update = function(key, value) {
        var data = api.getPrefs({
            sync: true,
            key: key
        });
        data = JSON.stringify(key);
        data = $.extend({}, data, value);
        api.setPrefs({
            key: key,
            value: JSON.stringify(data)
        });
    };
    cache.clear = function(key) {
        api.removePrefs({
            key: key
        });
    };


    window.closeSelf = function() {
        api.closeFrame();
    };
    window.addPrefs = function() {
        var ip = $('.ipBox').val();
        if (ip == "") return;
        ip = 'http://' + ip.replace('http://', '');
        var prefs = cache("testConfig");
        if (prefs && prefs.value != undefined) {
            prefs = prefs.value.split(',');
        } else {
            prefs = [];
        }
        prefs.push(ip);
        cache("testConfig", {
            value: prefs.join(',')
        });
        refresh();
    };
    window.refresh = function() {
        $('.list ul').html('');
        $('.current').html('');
        var current = cache("AI_app_url").value;
        var prefs = cache("testConfig");
        if (prefs && prefs.value != undefined) {
            prefs = prefs.value.split(',');
        } else {
            prefs = [];
        }
        prefs.forEach(function(pref) {
            if (pref != "") {
                var li = [
                    '<li>',
                        '<div onclick="setPrefs(this);">' + pref + '</div>',
                ];
                if( current == pref){
                    li.push('<span class="disabled">删除</span>');
                }else{
                    li.push('<span onclick="deletePrefs(this);">删除</span>');
                }
                        
                li.push('</li>');
                $('.list ul').append(li.join(''));
            }
        });
        if (current != "") {
            $('.current').html("<div>" + current + "</div>");
        }
    };

    window.setPrefs = function(obj) {
        var ip = $(obj).text().replace(/^\s*|\s*$/, '');
        cache("AI_app_url", {
            value: ip
        });
        refresh();
        api.toast({
            msg: '设置成功!'
        });
    };
    window.deletePrefs = function(obj){
        var ip = $(obj).parent().find('div').text().replace(/^\s*|\s*$/, '');
        var prefs = cache("testConfig");
        if (prefs && prefs.value != undefined) {
            prefs = prefs.value.split(',');
        } else {
            prefs = [];
        }
        var index = $.inArray(ip,prefs);
        if( index > -1 ){
            prefs.splice(index,1)
        };
        cache("testConfig", {
            value: prefs.join(',')
        });
        refresh();
    }
    window.clearAll = function() {
        cache("AI_app_url", {
            value: ""
        });
        cache("testConfig", {
            value: ''
        });
        refresh();
        api.toast({
            msg: '清除成功!'
        });
    }
    apiready = function() {
        refresh();
    };
})();
