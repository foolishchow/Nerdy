J(function(){
    // api.openFrame({})
    var router = Jutil.router('home');
    router.rect={
        x:0,
        y:0,
        w:api.winWidth,
        h:api.winHeight 
    };
    Jview.openFrame(router)

    // var listener = Jview.frame(router);

    // listener.changed = function (index,name) {
    //     $('.tarbar > .item').removeClass('active')
    //     $('.tarbar > .item').eq(index).addClass("active")
    // };
    // $('.tarbar > .item').click(function(){
    //     listener.index = $(this).index();
    // })
});

