    new Vue({
        el: '#app',
        data: {
            checklist: {
                options: [{
                    label: '被禁用',
                    value: false,
                    disabled: true
                }, {
                    label: '选项A',
                    value: false
                }, {
                    label: '选项B',
                    value: false
                }, {
                    label: '选项C',
                    value: false
                }, {
                    label: '选项D',
                    value: false
                }],
                value: ['选项A'],

                checked1: true,
                checked2: false,
                checked3: false,

            },
            radio: {
                options: [{
                    label: '被禁用',
                    value: '',
                    disabled: true
                }, {
                    label: '选项A',
                    value: 'a'
                }, {
                    label: '选项B',
                    value: 'b'
                }, {
                    label: '选项C',
                    value: 'c'
                }, {
                    label: '选项D',
                    value: 'd'
                }],
                value: 'a',

            },
            num1: '3',


            imgSrc: 'http://fuss10.elemecdn.com/b/18/0678e57cb1b226c04888e7f244c20jpeg.jpeg',

            navbar: {
                selected: '1'
            },

            sheetVisible: false,

            actions: [{
                name: 'openToast',
                method: this.openToast
            }, {
                name: 'openAlert',
                method: this.openAlert
            }]
        },

        created: function() {
            var em = this;
            this.rightButtons = [{
                content: 'Mark as Unread',
                style: { background: 'lightgray', color: '#fff' }
            }, {
                content: 'Delete',
                style: { background: 'red', color: '#fff' },
                handler: function (){
                    em.$messagebox('delete')
                } 
            }];
        },

        methods: {
            handleClick: function() {
                this.$toast('点击了按钮');
            },
            checkboxHandler: function() {
                this.$toast('选择了 checkbox');
            },
            openToast: function() {
                this.$toast('toast提示');
            },
            inputNumberChange: function() {
                // console.log(arguments)
                console.log(num1)
            },
            openIndicator: function() {
                var vm = this;
                this.$indicator.open();
                setTimeout(function() {
                    vm.$indicator.close();
                }, 1500)
            },
            openAlert: function() {
                console.log(1111111)
                this.$messagebox.alert('操作成功!', '提示');
            },

            openConfirm: function() {
                this.$messagebox.confirm('确定执行此操作?', '提示').then(function() {
                    //确定
                }, function() {
                    //取消
                });
            }

        }
    });
