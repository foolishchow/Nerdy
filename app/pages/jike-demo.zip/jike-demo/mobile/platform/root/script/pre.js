var cache = function(key, value) {
    if (value == undefined) {
        return cache.get(key);
    } else {
        if ((typeof value).toLowerCase() != "string") value = JSON.stringify(value);
        var d = $.Deferred();
        api.setPrefs({
            key: key,
            value: value
        });
        return d.promise();
    }
};
cache.get = function(key) {
    var userName = api.getPrefs({
        sync: true,
        key: key
    });
    try {
        var a = JSON.parse(userName);
        userName = a;
    } catch (e) {

    }
    return userName;
};
cache.update = function(key, value) {
    var data = api.getPrefs({
        sync: true,
        key: key
    });
    data = JSON.stringify(key);
    data = $.extend({}, data, value);
    api.setPrefs({
        key: key,
        value: JSON.stringify(data)
    });
};
cache.clear = function(key) {
    api.removePrefs({
        key: key
    });
};
window.AI = {
    app_url: ""
};
var app_url = 'http://192.168.0.135';
window.go = function() {
    app_url = cache.get("AI_app_url").value;
    AI.app_url = app_url;
    api.openWin({
        name: 'index',
        url: app_url + "/platform/root/prd.html",
        showProgress: true,
        slidBackEnabled: false,
        animation: {
            type: "fade"
        },
        delay: 300,
        bounces: false
    });
}

window.goDemos = function() {
    app_url = cache.get("AI_app_url").value;
    AI.app_url = app_url;
    api.openWin({
        name: 'index',
        url: app_url + "/modules/demo/index.html",
        showProgress: true,
        slidBackEnabled: false,
        animation: {
            type: "fade"
        },
        delay: 300,
        bounces: false
    });
}
window.selfConfig = function() {
    api.openFrame({
        name: "configFrame" + (+new Date),
        url: "widget://static/platform/root/config.html",
        showProgress: true,
        slidBackEnabled: true,
        rect: {
            x: 0,
            y: 0,
            w: 'auto',
            h: api.winHeight
        },
        pageParam: {
            updateTitle: false
        },
        animation: {
            type: "fade"
        },
        delay: 10,
        bounces: false
    });
}
