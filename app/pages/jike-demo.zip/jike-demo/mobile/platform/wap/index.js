(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
    typeof define === 'function' && define.amd ? define(factory) :
    (global.App = factory());
}(this, (function () { 'use strict';

/*  */



var History = function History() {
    this.filters = [];
    this.hashLine = [];
    this.isBack = false;
    this.current = this.getHash(window.location.href);
    this.init();
    window.addEventListener("hashchange", this.hashchange.bind(this));
};

var prototypeAccessors = { isRoot: {} };

prototypeAccessors.isRoot.get = function () {
    return this.current.hash == '' ? true : false;
};

History.prototype.listen = function listen (cb) {
    this.filters.push(cb);
};

History.prototype.unlisten = function unlisten (cb) {
    var index = $.inArray(cb, this.filters);
    if (index > -1) {
        this.filters.splice(index, 1);
    }
};

History.prototype.getHash = function getHash (url) {
    if (url.indexOf('#!') == -1) { return { hash: '' }; }
    var arr = url.replace(/^(.*?)\#\!/, '').split('/');
    var obj = {};
    obj.hash = arr[0];
    obj.timestap = arr[1];
    return obj;
};

History.prototype.hashchange = function hashchange (event) {
    var oldHash = this.getHash(event.oldURL),
        newHash = this.getHash(event.newURL);
    this.current = newHash;
    this.attach(oldHash, newHash);
};

History.prototype.attach = function attach (oldHash, newHash) {
        var this$1 = this;

    this.isBack = false;
    var backStep = 1;
    for (var i = this.hashLine.length - 1; i > -1; i--) {
        var prev = this$1.hashLine[i];
        // console.info('=============================');
        // console.info(newHash);
        // console.info('-------------');
        // console.info(prev);
        // console.info('=============================');
        if(prev.hash == newHash.hash && prev.timestap == newHash.timestap){
            this$1.isBack = true;
            var length = this$1.hashLine.length -1;
            backStep = (length - i);
            break;
        }
    }
    // console.info(this.isBack);
    if(!this.isBack) {
        this.hashLine.push(newHash);
    }else{
        var i$1 = 0;
        while(i$1 < backStep){
            var hash = this$1.hashLine.pop();
            hash.win.close();
            i$1++;
        }
        this.hashLine[this.hashLine.length-1].win.show();
        return;
    }
    /*{
        current: newHash,
        history: oldHash
    }*/
    this.filters.forEach(function (item) {
        item(oldHash, newHash, this$1);
    });
};

History.go = function go (router, param) {
    var timestap = new Date().getTime();
    router += '/' + timestap;

    location.hash = "#!" + router;
};

History.prototype.back = function back (){
    if(this.hashLine.length > 1){
        window.history.back();
    }else{
        App.initPage();
    }
};

History.prototype.init = function init () {
        var this$1 = this;

    if (!this.isRoot) {
        var oldHash = this.getHash(window.location.href),
            newHash = this.getHash(window.location.href);
        setTimeout(function () {
            this$1.attach(oldHash, newHash, this$1);
        }, 1);
    }
};

Object.defineProperties( History.prototype, prototypeAccessors );

var Api = function Api(view) {
    this.view = view;
    this.______config = view.config;
};

var prototypeAccessors$2 = { winWidth: {},winHeight: {},pageParam: {},winName: {},frameName: {} };

prototypeAccessors$2.winWidth.get = function () {
    return $('#base-root').width();
};

prototypeAccessors$2.winHeight.get = function () {
    return $('#base-root').height();
};

prototypeAccessors$2.pageParam.get = function () {
    return this.______config.pageParam;
};

prototypeAccessors$2.winName.get = function (){
    if(this.view.viewType == 'win'){
        return this.view.name;
    }else{
        return this.view.win.name;
    }
};

prototypeAccessors$2.frameName.get = function (){
    if(this.view.viewType == 'win'){
        return undefined;
    }else{
        return this.view.name;
    }
};

Api.prototype.openWin = function openWin (param) {
    Win.router(param);
};

Api.prototype.openFrame = function openFrame (param) {
    this.view.openFrame(param);
};

Api.prototype.openFrameGroup = function openFrameGroup (param,callBack){
    this.view.openFrameGroup(param,callBack);
};

Api.prototype.setFrameGroupIndex = function setFrameGroupIndex (param){
    this.view.setFrameGroupIndex(param);
};

Api.prototype.execScript = function execScript (param){
    Win.execScript(param);
};

Api.prototype.closeWin = function closeWin (param){
    if(param == undefined){
        app.history.back();
    }else{
        app.closeWin(param);
    }
};

Api.prototype.closeToWin = function closeToWin (){
    console.info("尽请期待");
};

Api.prototype.alert = function alert (){

};

Api.prototype.confirm = function confirm (){

};

Api.prototype.prompt = function prompt (){

};

Api.prototype.toast = function toast (){

};
    
Api.prototype.actionsheet = function actionsheet (){

};

Object.defineProperties( Api.prototype, prototypeAccessors$2 );

var JsSdk = function (){
    var JsSdk = function (func){
        $(function(){
            func();
        });
    };

    // var J = JsSdk;
    // J.util = {};
    // J.util.cloneObject = function(obj){
    //     return JSON.parse(JSON.stringify(obj))
    // }
    return JsSdk;
};

var Inject = function Inject(view) {
    var global = {};
    global.view = view;
    global.salt = view.salt;
    global.api = new Api(view);
    global.JsSdk = new JsSdk();
    global.root = "[salt='" + (view.salt) + "'] ai-main-wrap[ai-name='" + (view.html_root) + "'] ";
    if(view.viewType == 'win'){
        global.root = "[win-name='" + (view.name) + "']" + (global.root);
    }else{
        var now = global.root;
        global.root = "[win-name='" + (view.win.name) + "'][salt='" + (view.win.salt) + "'] [frame-name='" + (view.name) + "']" + now;
    }
    // console.info(global.root);
    global = new SdkGenerater(global);
    this.global = global;
    this.api = global.api;
};

/**/
/**
 * [Queuejs 依赖载入js方法]
 * 
 * version 0.7a
 * author 12050231
 * @example
Queuejs.init({
    src: [
        "a.js",
        "b.js",
        "c.js",
        "d.js",
        [
            e.js,
            f.js
        ]
    ],
},function(){
    alert("加载完毕")
});
 * )
 */
var _loader = function _loader(list,headTag,callback){
    if(list.length == 0 ){
        callback();
        return;
    }
    if(callback) { this.callback = callback; }
    headTag = headTag || document.getElementsByTagName('head')[0];
    this.headTag = headTag;
    this.modules = [];
    this.init(list);
    this.load();
};

_loader.prototype.init = function init (list){
        var this$1 = this;

    this.file = [];
    if (list) {
        //检测参数是否是数组
        list = list.constructor === Array ? list : [list];
        //获取所有需要异步载入的脚本文件，拆分数据
        for (var i = 0; i < list.length; i++) {
            if(list[i].constructor !== Array){
                //src变成数组变量
                list[i] = [list[i]];
            }
            this$1.file.push(list[i]);
        }
    }
};

_loader.prototype.load = function load (){
        var this$1 = this;

    var fileList = this.file.shift();
    this.currentList = fileList;
    //添加文件
    for (var i = 0; i < fileList.length; i++) {
        var url = fileList[i];
        var appendDom = document.createElement("script");
        appendDom.src = url;//+"?timestap="+(+new Date);
        appendDom.type = "text/javascript";
        //加载完毕和出错都载入下一个文件，防止资源阻塞
        appendDom.onload = appendDom.onerror = function (){
            this$1._load();
        };
        var scriptname = url.replace(/\.js$/,'').replace(/\./gi,'_');
        scriptname = scriptname.split('/');
        while(scriptname.length > 3){
            scriptname.shift();
        }
        this$1.modules.push(scriptname.join("-"));
        this$1.headTag.appendChild(appendDom);
    }
};

_loader.prototype._load = function _load (){
    //当前资源文件
    var p = this.currentList;
    if (!p) {
        return;
    }
    //清一个数组的队列
    p.shift();
    //资源载入后回调事件
    if (!p.length) {
        //再次执行
        if (this.file.length) {
            this.load();
        }else{
            if(typeof this.callback == 'function'){
                this.callback();
            }
            return;
        }
    }
};

_loader.prototype.getModule = function getModule (moduleName){
    var index = $.inArray(moduleName,this.modules);
    if( index > -1){
        this.modules.splice(index,1);
        /*console.info(`
index:    ${index}
moduleName:   ${moduleName}
modules:  ${this.modules}
        `);*/

        return true;
    }else{
        return false;
    }
};

var ScriptLoader = function ScriptLoader(list, builder) {
    this.salt = builder.salt;
    this.builder = builder;
    this.size = list.length;
    this.modules = [];
    // pending : (status)  0:inited;1:loading;2:loaded;
    this.pending = 0;
    this.init(list,builder);
};

var prototypeAccessors$1 = { length: {},status: {} };

ScriptLoader.prototype.init = function init (list,builder){
        var this$1 = this;

    this.inject = new Inject(builder.view);
    this.pending = 1;
    this.loader = new _loader(list,builder.$el.children('ai-scripts').eq(0)[0],function (){
        this$1.pending = 2;
    });
};

prototypeAccessors$1.length.get = function (){
    return this.size;
};

ScriptLoader.prototype.getModule = function getModule (moduleName){
    if(this.loader.getModule(moduleName)){
//         console.info(`
// getModule <-   ${moduleName}
// name  <-   ${this.builder.view.name}
// type  <-   ${this.builder.view.viewType}

//         `)
        return this.inject;
    }else{
        return false;
    }
        
};
prototypeAccessors$1.status.get = function (){
    return this.pending;
};

Object.defineProperties( ScriptLoader.prototype, prototypeAccessors$1 );

/*  */

var Builder = function Builder(view) {
    this.loaded = false;
    this.salt = view.salt;
    this.$el = view.$el;
    this.$content = view.$content;
    this.config = view.config;
    this.view = view;
    this.init();
};

Builder.prototype.init = function init () {
        var this$1 = this;

    var url = this.config.url.replace(AI.app_url + '/modules', '');
    $.getJSON('../../modules/' + url + '?timestap=' + (+new Date))
        .always(function (){
            this$1.view.$loading.hide();
        })
        .then(function (data) {
            var html = data.html,
                title = data.title;
            if( this$1.view.viewType == 'frame'){
                document.title = title;
            }    
            this$1.view.html_root = data.name;
            this$1.$content.html(html);
            this$1.$scripts = new ScriptLoader(data.scripts, this$1);
        })

        .fail(function (err){
            if(err.status == 404){
                var html = "\n                        <ai-main-wrap>\n                            <div class=\"err-404\"></div>\n                            <div class=\"err-desc\">\n                                您请求的页面不存在！！！\n                            </div>\n                        </ai-main-wrap>\n                    ";
                this$1.$content.html(html);
            }
        });
};

Builder.prototype.execScript = function execScript (param) {
        var this$1 = this;

    var execed = false;
    var interval = setInterval(function () {
        if ( this$1.$scripts && this$1.$scripts.pending == 2 ) {
            clearInterval(interval);
            new Function(("\n                        var inject = arguments[0];\n                        var Global = inject.global,\n                            global = Global,\n                            api = inject.api,\n                            JsSdk = Global.JsSdk,\n                            api = Global.api,\n                            J = JsSdk,\n                            Jutil = JsSdk.util,\n                            Jhelper = J.helper,\n                            Jnav = J.nav,\n                            Jlocation = J.location,\n                            Jview = J.view;\n                            " + (param.script) + ";\n                "))(this$1.$scripts.inject);
            }
        }, 50);
    };

/*  */

var View = function View(config) {
    this.builder = new Builder(this);
};

var Frame = (function (View$$1) {
    function Frame(win,config,salt,content){
        if(content){
            this.$parantContent = content;
        }else{
            this.$parantContent = win.$content;
        }
        this.init(win,config,salt);
        View$$1.call(this, config,salt);
    }

    if ( View$$1 ) Frame.__proto__ = View$$1;
    Frame.prototype = Object.create( View$$1 && View$$1.prototype );
    Frame.prototype.constructor = Frame;

    var prototypeAccessors = { viewType: {} };

    prototypeAccessors.viewType.get = function (){
        return 'frame'
    };

    Frame.prototype.init = function init (win,config,salt){
        this.win = win;
        (salt == undefined) & (salt = +new Date);
        var name = config.name,
            rect = config.rect ,
            url = config.url,
            bgColor = config.bgColor || "rgba(0,0,0,0)",
            pageParam = config.pageParam,
            animation = config.animation,
            loading = config.showProgress ? 'block' : 'none';
        
        this.name = name;
        this.config = config;
        this.salt = salt;
        // WinIndex++;
        this.$el = $(("\n            <ai-app-Frame frame-name='" + name + "' salt=\"" + salt + "\" style=\"background-color:" + bgColor + ";z-index:" + (win.frameList.length+1) + ";width:" + (rect.w) + "px;height:" + (rect.h) + "px;top:" + (rect.y) + "px;left:" + (rect.x) + "px;\">\n                <ai-app-loading style=\"\"></ai-app-loading>\n                <ai-frame-content></ai-frame-content>\n                <ai-scripts style=\"display:none\"></ai-scripts>\n            </ai-app-Frame>\n        ")).appendTo(this.$parantContent);
        this.$loading = this.$el.children('ai-app-loading');
        this.$content = this.$el.children('ai-frame-content');
    };

    Object.defineProperties( Frame.prototype, prototypeAccessors );

    return Frame;
}(View));

/*  */

var FrameGroup = function FrameGroup(win, config, callBack, salt) {
    this.frameList = [];
    this.onScroller = callBack || function() {};
    this.init(win, config, salt);
    // super(config, salt);
    // this.frameGroupList = [];
};

FrameGroup.prototype.init = function init (win, config, salt) {
    this.win = win;
    (salt == undefined) & (salt = +new Date);
    var name = config.name,
        rect = config.rect,
        size = config.frames.length,
        url = config.url,
        bgColor = config.bgColor,
        pageParam = config.pageParam,
        animation = config.animation,
        loading = config.showProgress ? 'block' : 'none';

    this.name = config.name;
    var groupWidth = rect.w * size;
    this.config = config;
    this.salt = salt;
    // WinIndex++;
    this.$el = $(("\n            <ai-app-framegroup winName='" + name + "' style=\"z-index:" + (win.frameList.length+1) + ";\n            top:" + (rect.y) + "px;left:" + (rect.x) + "px;width:" + groupWidth + "px;height:" + (rect.h) + "px;\">\n                <ai-framegroup-content>\n\n                </ai-framegroup-content>\n            </ai-app-framegroup>\n        ")).appendTo(win.$content);
    var frames = '';
    config.frames.forEach(function (frame) {
        frames += "<ai-win-content style=\"width:" + (rect.w) + "px;height:" + (rect.h) + "px;\"></ai-win-content>";
    });
    this.$content = this.$el.children('ai-framegroup-content');
    this.$frameContent = $(frames).appendTo(this.$content);
    // console.info(this.$frameContent.eq(1));
    this.initFrame();
};

FrameGroup.prototype.initFrame = function initFrame () {
    var index = parseInt(this.config.index),
        rect = this.config.rect;
    if (index == undefined || index == NaN || index < 0 || index > this.config.frames.length - 1) {
        index = 0;
    }
    this.setFrameGroupIndex({ index: index });
};

FrameGroup.prototype.setFrameGroupIndex = function setFrameGroupIndex (obj) {
        var index = obj.index;
    if (index == undefined || index == NaN || index < 0 || index > this.config.frames.length - 1) { return; }
    var left = 0 - index * this.config.rect.w;
    this.$frameContent.eq(index).siblings().children('ai-app-frame').hide({ display: 'none' });
    this.$frameContent.eq(index).children('ai-app-frame').show();
        this.$content.css({ 'margin-left': left + 'px' });
        
        if (this.frameList[index] == undefined) {
        var config = this.config.frames[index];
        config.rect = this.config.rect;

        var frame = new Frame(this.win, config, null, this.$frameContent.eq(index));
        this.frameList[index] = frame;
        this.win.frameList.push(frame);
    }
    this.onScroller({
        index: index,
            name: this.frameList[index].name
    });
};

var Base64 = function Base64(){
    this._keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    // this.shorted = {
    // name:'',

    // };
};
    
 
// public method for encoding
Base64.prototype.encode = function encode (input) {
        var this$1 = this;

    var output = "";
    var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
    var i = 0;
    input = this._utf8_encode(input);
    while (i < input.length) {
        chr1 = input.charCodeAt(i++);
        chr2 = input.charCodeAt(i++);
        chr3 = input.charCodeAt(i++);
        enc1 = chr1 >> 2;
        enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
        enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
        enc4 = chr3 & 63;
        if (isNaN(chr2)) {
            enc3 = enc4 = 64;
        } else if (isNaN(chr3)) {
            enc4 = 64;
        }
        output = output +
        this$1._keyStr.charAt(enc1) + this$1._keyStr.charAt(enc2) +
        this$1._keyStr.charAt(enc3) + this$1._keyStr.charAt(enc4);
    }
    return output;
};
 
// public method for decoding
Base64.prototype.decode = function decode (input) {
        var this$1 = this;

    var output = "";
    var chr1, chr2, chr3;
    var enc1, enc2, enc3, enc4;
    var i = 0;
    input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
    while (i < input.length) {
        enc1 = this$1._keyStr.indexOf(input.charAt(i++));
        enc2 = this$1._keyStr.indexOf(input.charAt(i++));
        enc3 = this$1._keyStr.indexOf(input.charAt(i++));
        enc4 = this$1._keyStr.indexOf(input.charAt(i++));
        chr1 = (enc1 << 2) | (enc2 >> 4);
        chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
        chr3 = ((enc3 & 3) << 6) | enc4;
        output = output + String.fromCharCode(chr1);
        if (enc3 != 64) {
            output = output + String.fromCharCode(chr2);
        }
        if (enc4 != 64) {
            output = output + String.fromCharCode(chr3);
        }
    }
    output = this._utf8_decode(output);
    return output;
};
 
// private method for UTF-8 encoding
Base64.prototype._utf8_encode = function _utf8_encode (string) {
    string = string.replace(/\r\n/g,"\n");
    var utftext = "";
    for (var n = 0; n < string.length; n++) {
        var c = string.charCodeAt(n);
        if (c < 128) {
            utftext += String.fromCharCode(c);
        } else if((c > 127) && (c < 2048)) {
            utftext += String.fromCharCode((c >> 6) | 192);
            utftext += String.fromCharCode((c & 63) | 128);
        } else {
            utftext += String.fromCharCode((c >> 12) | 224);
            utftext += String.fromCharCode(((c >> 6) & 63) | 128);
            utftext += String.fromCharCode((c & 63) | 128);
        }
 
    }
    return utftext;
};
 
// private method for UTF-8 decoding
Base64.prototype._utf8_decode = function _utf8_decode (utftext) {
    var string = "";
    var i = 0;
    var c = 0,
    c1 = 0,
    c2 = 0,
    c3 = 0;
    while ( i < utftext.length ) {
        c = utftext.charCodeAt(i);
        if (c < 128) {
            string += String.fromCharCode(c);
            i++;
        } else if((c > 191) && (c < 224)) {
            c2 = utftext.charCodeAt(i+1);
            string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
            i += 2;
        } else {
            c2 = utftext.charCodeAt(i+1);
            c3 = utftext.charCodeAt(i+2);
            string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
            i += 3;
        }
    }
    return string;
};

/*  */

var WinIndex = 0;
var winList = [];

var Win = (function (View$$1) {
    function Win(config, salt) {
        this.frameList = [];
        this.frameGroupList = [];
        this.init(config, salt);
        View$$1.call(this, config, salt);
    }

    if ( View$$1 ) Win.__proto__ = View$$1;
    Win.prototype = Object.create( View$$1 && View$$1.prototype );
    Win.prototype.constructor = Win;

    var prototypeAccessors = { viewType: {} };
    var staticAccessors = { type: {},list: {} };

    prototypeAccessors.viewType.get = function () {
        return 'win'
    };

    staticAccessors.type.get = function () {
        return 'window';
    };

    staticAccessors.list.get = function () {
        return winList;
    };

    Win.execScript = function execScript (param) {
        var target;

        for (var i = winList.length - 1; i > -1; i--) {
            var win = winList[i];
            if (win.name == param.name) {
                target = win;
                break;
            }
        }
       /* winList.some((win) => {
            if (win.name == param.name) {
                target = win;
                return true;
            }
        });*/
        if (target == undefined) { return; }
        if (param.frameName) {
            var _target = target;
            target = undefined;
            _target.frameList.some(function (frame) {
                if (frame.name == param.frameName) {
                    target = frame;
                    return true;
                }
            });
        }
        if (target) {
            target.builder.execScript(param);
        }
    };

    Win.getModule = function getModule (moduleName) {
        var result;
        winList.some(function (win) {
            var _module = win.builder.$scripts.getModule(moduleName);
            if (_module) {
                result = _module;
                return true;
            } else {
                win.frameList.some(function (frame) {
                    if (frame.builder.$scripts == undefined) { return false; }
                    var __module = frame.builder.$scripts.getModule(moduleName);
                    if (__module) {
                        result = __module;
                        return true;
                    }
                });
                if (result) { return true; }
            }
        });
        return result;
    };

    Win.prototype.init = function init (config, salt) {

        (salt == undefined) & (salt = +new Date);
        var name = config.name,
            url = config.url,
            bgColor = config.bgColor || '#f4f5f7',
            pageParam = config.pageParam,
            animation = config.animation,
            loading = config.showProgress ? 'block' : 'none';

        this.name = name;
        this.config = config;
        this.salt = salt;
        WinIndex++;
        this.$el = $(("\n            <ai-app-Win win-name='" + name + "' salt=\"" + salt + "\" style=\"z-index:" + WinIndex + ";background-color:" + bgColor + ";\">\n                <ai-win-content></ai-win-content>\n                <ai-app-loading style=\"\"></ai-app-loading>\n                <ai-scripts style=\"display:none\"></ai-scripts>\n            </ai-app-Win>\n        ")).appendTo($('#base-root'));
        this.$content = this.$el.children('ai-win-content');
        this.$loading = this.$el.children('ai-app-loading');
        Win.list.push(this);
        // this.animate = new animate(this);
    };

    Win.prototype.openFrame = function openFrame (param) {
        this.frameList.push(new Frame(this, param));
    };

    Win.prototype.openFrameGroup = function openFrameGroup (param, callBack) {
        this.frameGroupList.push(new FrameGroup(this, param, callBack));
    };

    Win.prototype.setFrameGroupIndex = function setFrameGroupIndex (param) {
        this.frameGroupList.forEach(function (frameGroup) {
            if (frameGroup.name == param.name) {
                frameGroup.setFrameGroupIndex(param);
            }
        });
    };
    Win.prototype.hide = function hide () {
        this.$el.hide();
    };
    Win.prototype.show = function show () {
        this.$el.show();
    };
    Win.prototype.close = function close () {
        this.$el.remove();
        delete this;
    };
    Win.router = function router (param) {
        History.go(new Base64().encode(JSON.stringify(param)));
    };
    Win.newInstance = function newInstance (config) {
        return new Win(config);
    };

    Win.buildInstance = function buildInstance (oldHash, newHash, history) {
        if (history.isRoot) {
            App$1.initPage();
            return;
        }
        var option = false;
        try {
            option = JSON.parse(new Base64().decode(history.current.hash));
        } catch (e) {
            App$1.initPage();
        }
        if (option != false) {
            var length = history.hashLine.length - 1;
            history.hashLine[length].win = new Win(option, history.current.timestap);
            (length > 0) && history.hashLine[length - 1].win.hide();
        }

    };

    Win.router = function router (option) {
        History.go(new Base64().encode(JSON.stringify(option)));
    };

    Object.defineProperties( Win.prototype, prototypeAccessors );
    Object.defineProperties( Win, staticAccessors );

    return Win;
}(View));

/*  */

var App$1 = function App() {
    this.history = new History();
    this.history.listen(Win.buildInstance);
    this.init();
};

var staticAccessors = { history: {},Win: {},Frame: {},Base64: {} };

staticAccessors.history.get = function () {
    return History;
};

staticAccessors.Win.get = function () {
    return Win;
};

staticAccessors.Frame.get = function () {
    return Frame;
};

staticAccessors.Base64.get = function () {
    return new Base64();
};

App$1.prototype.init = function init () {
    if (this.history.isRoot) {
        App$1.initPage(this.history);
    }
};

App$1.initPage = function initPage (history) {
    var win = {
        url: '../platform/root/prd.html',
        name: 'root'
    };
    Win.router(win);
};
App$1.prototype.viewChange = function viewChange (oldHash, newHash, history) {
    console.info(arguments);
};

App$1.prototype.getModule = function getModule (moduleName) {
    return Win.getModule(moduleName);
};

App$1.prototype.closeWin = function closeWin (param){
        
};

Object.defineProperties( App$1, staticAccessors );

if (App$1) { window.app = new App$1(); }

return App$1;

})));
