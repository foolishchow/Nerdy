var nav_template = [
    '<div class="ai-main-wrap">',
    '<section id="navtop">',
    '    <div class="top_nav" v-if="view.showTop" style="topHeight()"></div>',
    '    <!-- 导航栏-->',
    '    <div class="ai-nav">',
    '        <div class="ai-nav-back" @click="close()">',
    '            <a></a>',
    '        </div>',
    '        <div class="ai-nav-title">',
    '            <span v-text="view.title"></span>',
    '        </div>',
    '        <div class="ai-nav-right" v-if="view.buttons.config.length" >',
    '            <div v-for="button in view.buttons.config">',
    '               <a v-text="button.text" @click="buttonClick(button)"></a>',
    '            </div>',
    '            <!-- <a>完成</a> -->',
    '            <!-- <div class="navimgwrap"><img src="../../../modules/smsMarket/images/search.png"></div> -->',
    '            <!-- <div class="navimgwrap"><img src="../../../modules/smsMarket/images/search.png"></div> -->',
    '        </div>',
    '    </div>',
    '    <section class="ai-tabs" v-if="config.tabs" >',
    '       <div v-for="item in config.tabs"',
    '             v-bind:class="tabsSelected($index)" @click="tabClick($index)">',
    '           <span v-text="item.text"></span>',
    '       </div>',
    '    </section>',
    '</section>',
    '<section class="main">',
    '</section>',
    '</div>'
].join('');
var methods = {
    close: function() {
        this.api.closeWin();
    },
    topHeight: function() {
        return {
            'height': this.view.topHeight + "px"
        };
    },
    updateTitle: function(obj) {
        this.view.title = obj.title;
    },
    // configButton: function(obj) {
    //     console.info("------");
    //     this.view.buttons = obj;
    // },
    buttonClick: function(button) {
        var page = Jutil.cloneObject(this.view.buttons.page);
        J.fire({
            funcName: button.callBack,
            page: page
        });
    }
};

$.extend(methods, {
    getReact: function() {
        var api = this.api;
        var height = $(this.$el).find('#navtop').height();
        var rect = {
            x: 0,
            y: height,
            w: api.winWidth,
            h: api.winHeight - height
        };
        return rect;
    },
    navConfig: function() {
        var api = this.api;
        return {
            top: $(this.$el).find('.top_nav').length ? $(this.$el).find('.top_nav').height() : 0,
            total: $(this.$el).find('#navtop').height(),
            page: {
                winName: api.winName,
                frameName: api.frameName
            },
            pageType: (this.config.tabs != undefined && this.config.tabs.length > 0) ? 'frameGroupPage' : 'common'
        };
    }
});
//打开普通页面
$.extend(methods, {
    //打开frame
    openFrame: function() {
        // if (Global.api == undefined) return;
        var api = this.api;
        var config = Jutil.cloneObject(this.config);
        config.pageParam.__nav = this.navConfig();

        config.rect = this.getReact();
        api.openFrame(config);
    }
});
//open tabs
$.extend(methods, {
    configButton: function(obj) {
        var page = obj.page;
        this.view.tab_buttons[page.frameName] = obj;
        var pageType = this.navConfig().pageType;
        if (pageType =="frameGroupPage" && page.frameName == this.view.active_tab_name) {
            this.view.buttons = obj;
        }else if(pageType =="common"){
            this.view.buttons = obj;
        }
    },
    tabsSelected: function(index) {
        if (index == this.view.active_tab_index) {
            return {
                'active': true
            }
        }
    },
    //打开tabs
    openTabs: function() {
        var tabs = Jutil.cloneObject(this.config.tabs),
            pageParam = Jutil.cloneObject(this.config.pageParam);
        pageParam.__nav = this.navConfig();
        var index = 0;
        for (var i = 0; i < tabs.length; i++) {
            tabs[i] = $.extend({}, {
                pageParam: Jutil.cloneObject(pageParam),
                name: "tabs" + Jutil.random(4)
            }, tabs[i]);
            if (tabs[i].selected == true || tabs[i].selected == 'true') index = i;
        }
        this.view.active_tab_index = index;
        var group = {
            name: this.config.name = undefined ? Jutil.random(4, 'frameGroup') : this.config.name,
            background: '#fff',
            scrollEnabled: true,
            scroll: true,
            rect: this.getReact(),
            index: index,
            frames: tabs
        }
        this.view.tabs = Jview.frameGroup(group);
        var self = this;
        this.view.tabs.changed = function(index, name) {
            self.view.active_tab_index = index;
            self.view.active_tab_name = name;
            self.view.buttons = self.view.tab_buttons[name];
        };
    },
    tabClick: function(index) {
        this.view.active_tab_index = index;
        this.view.tabs.index = index;
    }
});

var computed = {

};
var nav_component = {
    template: nav_template,
    props: { 'configs': Object, api: Object },
    data: function() {
        var api = this.api;
        var height = 26;
        if (api && api.systemType == 'ios') {
            height = 20;
            api.setStatusBarStyle({ style: 'light' });
        }
        return {
            config: this.configs,
            view: {
                showTop: api.statusBarAppearance,
                topHeight: height,
                title: '',
                active_tab_index: 0,
                buttons: {
                    config: [],
                    page: {
                        winName: '',
                        frameName: ''
                    }
                },
                tab_buttons: {}
            }
        };
    },
    mounted: function() {
        var config = this.config;
        if (config.tabs != undefined && config.tabs.length > 0) {
            this.openTabs();
        } else {
            this.openFrame();
        }
    },

    methods: methods,
    computed: computed
};

if (!Vue.component('ai-nav')) {
    Vue.component('ai-nav', nav_component);
}

J(function() {
    var nav = new Vue({
        data: {
            model: api.pageParam
        },
        computed:{
            api:function(){
                return api;
            }
        },
        el: Global.root + ' .ai-main-wrap'
    });
    Global.nav = nav.$children[0];
});
