export MODULES="zepto event assets deferred callbacks selector ajax data assets" 
coffee make dist
cp -r ./dist/zepto.js ../../common/script/zepto/