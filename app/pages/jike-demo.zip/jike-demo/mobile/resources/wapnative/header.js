(function() {
        window.SdkGenerater = function(Global) {
                var JsSdk = Global.JsSdk,
                    J = JsSdk,
                    Jutil = Global.Jutil,
                    Jnav = Global.Jnav,
                    Jhelper = Global.Jhelper,
                    Jview = Global.Jview,
                    Jlocation = Global.Jlocation,
                    api = Global.api;
