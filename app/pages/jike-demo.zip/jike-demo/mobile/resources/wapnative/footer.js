    JsSdk = Global.JsSdk,
    J = JsSdk,
    Jutil = Global.Jutil,
    Jnav = Global.Jnav,
    Jhelper = Global.Jhelper,
    Jview = Global.Jview,
    Jlocation = Global.Jlocation;
    return Global;
}
})();
