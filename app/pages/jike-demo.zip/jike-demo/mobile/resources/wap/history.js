/* @flow */

import type App from './index';

export class History {

    // router: Router;
    filters: [];
    isRoot: false;

    // get isBack() {
    //     return false;
    // }
    get isRoot() {
        return this.current.hash == '' ? true : false;
    }

    constructor() {
        this.filters = [];
        this.hashLine = [];
        this.isBack = false;
        this.current = this.getHash(window.location.href);
        this.init();
        window.addEventListener("hashchange", this.hashchange.bind(this));
    }

    listen(cb: Function) {
        this.filters.push(cb);
    }

    unlisten(cb: Function) {
        var index = $.inArray(cb, this.filters);
        if (index > -1) {
            this.filters.splice(index, 1);
        }
    }

    getHash(url) {
        if (url.indexOf('#!') == -1) return { hash: '' };
        var arr = url.replace(/^(.*?)\#\!/, '').split('/');
        var obj = {};
        obj.hash = arr[0];
        obj.timestap = arr[1];
        return obj;
    }

    hashchange(event) {
        var oldHash = this.getHash(event.oldURL),
            newHash = this.getHash(event.newURL);
        this.current = newHash;
        this.attach(oldHash, newHash)
    }

    attach(oldHash, newHash) {
        this.isBack = false;
        let backStep = 1;
        for (let i = this.hashLine.length - 1; i > -1; i--) {
            let prev = this.hashLine[i];
            // console.info('=============================');
            // console.info(newHash);
            // console.info('-------------');
            // console.info(prev);
            // console.info('=============================');
            if(prev.hash == newHash.hash && prev.timestap == newHash.timestap){
                this.isBack = true;
                let length = this.hashLine.length -1;
                backStep = (length - i);
                break;
            }
        }
        // console.info(this.isBack);
        if(!this.isBack) {
            this.hashLine.push(newHash);
        }else{
            let i = 0;
            while(i < backStep){
                let hash = this.hashLine.pop();
                hash.win.close();
                i++;
            }
            this.hashLine[this.hashLine.length-1].win.show();
            return;
        }
        /*{
            current: newHash,
            history: oldHash
        }*/
        this.filters.forEach((item) => {
            item(oldHash, newHash, this)
        });
    }

    static go(router, param) {
        let timestap = new Date().getTime();
        router += '/' + timestap;

        location.hash = "#!" + router;
    }

    back(){
        if(this.hashLine.length > 1){
            window.history.back();
        }else{
            App.initPage();
        }
    }

    init() {
        if (!this.isRoot) {
            var oldHash = this.getHash(window.location.href),
                newHash = this.getHash(window.location.href);
            setTimeout(() => {
                this.attach(oldHash, newHash, this);
            }, 1);
        }
    }

}
