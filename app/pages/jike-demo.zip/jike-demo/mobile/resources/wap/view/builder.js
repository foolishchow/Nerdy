import {ScriptLoader} from '../loader/script'

var pending = false;

export class builder {
    
    constructor(view){
        this.$el = view.$el;
        this.$content = view.$content;
        this.config = view.config;
        this.view = view;
        this.init();
    }    

    init(){
        var url = this.config.url;
        $.getJSON('../../modules/'+url+'.html?timestap='+ (+new Date))
        .done(()=>{
        })
        .then((data)=> {
            var html = data.html;
            this.$content.html(html);
            this.$scripts = new ScriptLoader(data.scripts,this);
        });
    }



}