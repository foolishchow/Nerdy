/* @flow */

import { View } from './view'
import { Frame } from './frame'

export class FrameGroup {

    constructor(win, config, callBack, salt) {
        this.frameList = [];
        this.onScroller = callBack || function() {};
        this.init(win, config, salt);
        // super(config, salt);
        // this.frameGroupList = [];
    }

    init(win, config, salt) {
        this.win = win;
        (salt == undefined) & (salt = +new Date);
        let name = config.name,
            rect = config.rect,
            size = config.frames.length,
            url = config.url,
            bgColor = config.bgColor,
            pageParam = config.pageParam,
            animation = config.animation,
            loading = config.showProgress ? 'block' : 'none';

        this.name = config.name;
        let groupWidth = rect.w * size;
        this.config = config;
        this.salt = salt;
        // WinIndex++;
        this.$el = $(`
            <ai-app-framegroup winName='${name}' style="z-index:${win.frameList.length+1};
            top:${rect.y}px;left:${rect.x}px;width:${groupWidth}px;height:${rect.h}px;">
                <ai-framegroup-content>

                </ai-framegroup-content>
            </ai-app-framegroup>
        `).appendTo(win.$content);
        var frames = '';
        config.frames.forEach((frame) => {
            frames += `<ai-win-content style="width:${rect.w}px;height:${rect.h}px;"></ai-win-content>`;
        });
        this.$content = this.$el.children('ai-framegroup-content');
        this.$frameContent = $(frames).appendTo(this.$content);
        // console.info(this.$frameContent.eq(1));
        this.initFrame();
    }

    initFrame() {
        var index = parseInt(this.config.index),
            rect = this.config.rect;
        if (index == undefined || index == NaN || index < 0 || index > this.config.frames.length - 1) {
            index = 0;
        }
        this.setFrameGroupIndex({ index: index })
    }

    setFrameGroupIndex(obj) {
        var index = obj.index;
        if (index == undefined || index == NaN || index < 0 || index > this.config.frames.length - 1) return;
        var left = 0 - index * this.config.rect.w;
        this.$frameContent.eq(index).siblings().children('ai-app-frame').hide({ display: 'none' });
        this.$frameContent.eq(index).children('ai-app-frame').show();
        this.$content.css({ 'margin-left': left + 'px' });
        
        if (this.frameList[index] == undefined) {
            var config = this.config.frames[index];
            config.rect = this.config.rect;

            let frame = new Frame(this.win, config, null, this.$frameContent.eq(index));
            this.frameList[index] = frame;
            this.win.frameList.push(frame);
        }
        this.onScroller({
            index: index,
            name: this.frameList[index].name
        })
    }




}
