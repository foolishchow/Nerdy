/* @flow */


import type Win from './Window'
export class animate{

    constructor(win:Win){
        this.config = win.animate;
        this.$el = win.$el;
        this.init();
    }

    init(){
        
    }
}