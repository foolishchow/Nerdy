import {Win} from './win'
import {View} from './view'


export class Frame extends View{

    get viewType(){
        return 'frame'
    }

    constructor(win,config,salt,content){
        if(content){
            this.$parantContent = content;
        }else{
            this.$parantContent = win.$content;
        }
        this.init(win,config,salt);
        super(config,salt);
    }

    init(win,config,salt){
        this.win = win;
        (salt == undefined) & (salt = +new Date);
        let name = config.name,
            rect = config.rect ,
            url = config.url,
            bgColor = config.bgColor || "rgba(0,0,0,0)",
            pageParam = config.pageParam,
            animation = config.animation,
            loading = config.showProgress ? 'block' : 'none';
        
        this.name = name;
        this.config = config;
        this.salt = salt;
        // WinIndex++;
        this.$el = $(`
            <ai-app-Frame frame-name='${name}' salt="${salt}" style="background-color:${bgColor};z-index:${win.frameList.length+1};width:${rect.w}px;height:${rect.h}px;top:${rect.y}px;left:${rect.x}px;">
                <ai-app-loading style=""></ai-app-loading>
                <ai-frame-content></ai-frame-content>
                <ai-scripts style="display:none"></ai-scripts>
            </ai-app-Frame>
        `).appendTo(this.$parantContent);
        this.$loading = this.$el.children('ai-app-loading');
        this.$content = this.$el.children('ai-frame-content');
    }


}