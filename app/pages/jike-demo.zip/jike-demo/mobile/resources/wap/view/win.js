/* @flow */

import { View } from './view'
import { Frame } from './frame'
import { FrameGroup } from './frameGroup'
import { Base64 } from '../base64'
import { History } from '../history'
import App from '../index'

var WinIndex = 0;
var winList = [];

export class Win extends View {

    get viewType() {
        return 'win'
    }

    static get type() {
        return 'window';
    }

    static get list() {
        return winList;
    }

    static execScript(param) {
        var target;

        for (var i = winList.length - 1; i > -1; i--) {
            let win = winList[i];
            if (win.name == param.name) {
                target = win;
                break;
            }
        }
       /* winList.some((win) => {
            if (win.name == param.name) {
                target = win;
                return true;
            }
        });*/
        if (target == undefined) return;
        if (param.frameName) {
            let _target = target;
            target = undefined;
            _target.frameList.some((frame) => {
                if (frame.name == param.frameName) {
                    target = frame;
                    return true;
                }
            });
        }
        if (target) {
            target.builder.execScript(param);
        }
    }

    static getModule(moduleName) {
        var result;
        winList.some((win) => {
            var _module = win.builder.$scripts.getModule(moduleName);
            if (_module) {
                result = _module;
                return true;
            } else {
                win.frameList.some((frame) => {
                    if (frame.builder.$scripts == undefined) return false;
                    var __module = frame.builder.$scripts.getModule(moduleName);
                    if (__module) {
                        result = __module;
                        return true;
                    }
                });
                if (result) return true;
            }
        });
        return result;
    }

    constructor(config, salt) {
        this.frameList = [];
        this.frameGroupList = [];
        this.init(config, salt);
        super(config, salt);
    }

    init(config, salt) {

        (salt == undefined) & (salt = +new Date);
        let name = config.name,
            url = config.url,
            bgColor = config.bgColor || '#f4f5f7',
            pageParam = config.pageParam,
            animation = config.animation,
            loading = config.showProgress ? 'block' : 'none';

        this.name = name;
        this.config = config;
        this.salt = salt;
        WinIndex++;
        this.$el = $(`
            <ai-app-Win win-name='${name}' salt="${salt}" style="z-index:${WinIndex};background-color:${bgColor};">
                <ai-win-content></ai-win-content>
                <ai-app-loading style=""></ai-app-loading>
                <ai-scripts style="display:none"></ai-scripts>
            </ai-app-Win>
        `).appendTo($('#base-root'));
        this.$content = this.$el.children('ai-win-content');
        this.$loading = this.$el.children('ai-app-loading');
        Win.list.push(this);
        // this.animate = new animate(this);
    }

    openFrame(param) {
        this.frameList.push(new Frame(this, param));
    }

    openFrameGroup(param, callBack) {
        this.frameGroupList.push(new FrameGroup(this, param, callBack))
    }

    setFrameGroupIndex(param) {
        this.frameGroupList.forEach((frameGroup) => {
            if (frameGroup.name == param.name) {
                frameGroup.setFrameGroupIndex(param);
            }
        })
    }
    hide() {
        this.$el.hide();
    }
    show() {
        this.$el.show();
    }
    close() {
        this.$el.remove();
        delete this;
    }
    static router(param) {
        History.go(new Base64().encode(JSON.stringify(param)));
    }
    static newInstance(config) {
        return new Win(config);
    }

    static buildInstance(oldHash, newHash, history) {
        if (history.isRoot) {
            App.initPage();
            return;
        }
        let option = false;
        try {
            option = JSON.parse(new Base64().decode(history.current.hash));
        } catch (e) {
            App.initPage();
        }
        if (option != false) {
            let length = history.hashLine.length - 1;
            history.hashLine[length].win = new Win(option, history.current.timestap);
            (length > 0) && history.hashLine[length - 1].win.hide();
        }

    }

    static router(option) {
        History.go(new Base64().encode(JSON.stringify(option)))
    }

}
