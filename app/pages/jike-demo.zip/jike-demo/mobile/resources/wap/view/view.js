/* @flow */

import { Builder } from '../builder/builder'


export class View {

    salt: String;
    config: Object;
    $el: Element;
    $content:Element;
    $builder:Builder;

    constructor(config) {
        this.builder = new Builder(this);
    }
    

}
