/* @flow */

import {History} from '../history/history'
import {View} from '../View/index'

export class Router{

    href:()=>void;

    constructor(history:History){
        this.viewList = [];
        history.listen(this.viewChange.bind(this));
        this.history = history;
        if( history.isRoot ){
            this.otherWise();
        }else{
            this.newView(history);
        }
    }

    newView(history:History){
        this.currentView = new View(history);
        this.viewList.push(this.currentView);
    }

    otherWise(history:History){
        this.history.go('index');
    }

    viewChange(oldHash,newHash){
        console.info(arguments);
        // this.newView(history);
    }


}