export class Base{

    
}