import { Win } from '../../view/win'
export class Api {

    constructor(view) {
        this.view = view;
        this.______config = view.config;
    }

    get winWidth() {
        return $('#base-root').width();
    }

    get winHeight() {
        return $('#base-root').height();
    }

    get pageParam() {
        return this.______config.pageParam;
    }

    get winName(){
        if(this.view.viewType == 'win'){
            return this.view.name;
        }else{
            return this.view.win.name;
        }
    }

    get frameName(){
        if(this.view.viewType == 'win'){
            return undefined;
        }else{
            return this.view.name;
        }
    }

    openWin(param) {
        Win.router(param);
    }

    openFrame(param) {
        this.view.openFrame(param);
    }

    openFrameGroup(param,callBack){
        this.view.openFrameGroup(param,callBack);
    }

    setFrameGroupIndex(param){
        this.view.setFrameGroupIndex(param);
    }

    execScript(param){
        Win.execScript(param);
    }

    closeWin(param){
        if(param == undefined){
            app.history.back();
        }else{
            app.closeWin(param);
        }
    }

    closeToWin(){
        console.info(`尽请期待`);
    }

    alert(){

    }

    confirm(){

    }

    prompt(){

    }

    toast(){

    }
    
    actionsheet(){

    }

}   
