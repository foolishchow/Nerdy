/*@flow*/
import {Inject} from './inject'

/**
 * [Queuejs 依赖载入js方法]
 * 
 * version 0.7a
 * author 12050231
 * @example
Queuejs.init({
    src: [
        "a.js",
        "b.js",
        "c.js",
        "d.js",
        [
            e.js,
            f.js
        ]
    ],
},function(){
    alert("加载完毕")
});
 * )
 */
class _loader {
    constructor(list,headTag,callback){
        if(list.length == 0 ){
            callback();
            return;
        }
        if(callback) this.callback = callback;
        headTag = headTag || document.getElementsByTagName('head')[0];
        this.headTag = headTag;
        this.modules = [];
        this.init(list);
        this.load();
    }

    init(list){
        this.file = [];
        if (list) {
            //检测参数是否是数组
            list = list.constructor === Array ? list : [list];
            //获取所有需要异步载入的脚本文件，拆分数据
            for (var i = 0; i < list.length; i++) {
                if(list[i].constructor !== Array){
                    //src变成数组变量
                    list[i] = [list[i]];
                }
                this.file.push(list[i]);
            }
        }
    }

    load(){
        var fileList = this.file.shift();
        this.currentList = fileList;
        //添加文件
        for (let i = 0; i < fileList.length; i++) {
            let url = fileList[i];
            let appendDom = document.createElement("script");
            appendDom.src = url;//+"?timestap="+(+new Date);
            appendDom.type = "text/javascript";
            //加载完毕和出错都载入下一个文件，防止资源阻塞
            appendDom.onload = appendDom.onerror = ()=> {
                this._load();
            };
            let scriptname = url.replace(/\.js$/,'').replace(/\./gi,'_');
            scriptname = scriptname.split('/');
            while(scriptname.length > 3){
                scriptname.shift();
            }
            this.modules.push(scriptname.join("-"));
            this.headTag.appendChild(appendDom);
        }
    }

    _load(){
        //当前资源文件
        var p = this.currentList;
        if (!p) {
            return;
        }
        //清一个数组的队列
        p.shift();
        //资源载入后回调事件
        if (!p.length) {
            //再次执行
            if (this.file.length) {
                this.load();
            }else{
                if(typeof this.callback == 'function'){
                    this.callback();
                }
                return;
            }
        }
    }

    getModule(moduleName){
        let index = $.inArray(moduleName,this.modules);
        if( index > -1){
            this.modules.splice(index,1);
            /*console.info(`
index:        ${index}
moduleName:   ${moduleName}
modules:      ${this.modules}
            `);*/

            return true;
        }else{
            return false;
        }
    }

}

export class ScriptLoader {
    constructor(list: Array, builder) {
        this.salt = builder.salt;
        this.builder = builder;
        this.size = list.length;
        this.modules = [];
        // pending : (status)  0:inited;1:loading;2:loaded;
        this.pending = 0;
        this.init(list,builder);
    }

    init(list,builder){
        this.inject = new Inject(builder.view);
        this.pending = 1;
        this.loader = new _loader(list,builder.$el.children('ai-scripts').eq(0)[0],()=>{
            this.pending = 2;
        });
    }

    get length (){
        return this.size;
    }

    getModule(moduleName){
        if(this.loader.getModule(moduleName)){
//             console.info(`
// getModule <-   ${moduleName}
// name      <-   ${this.builder.view.name}
// type      <-   ${this.builder.view.viewType}

//             `)
            return this.inject;
        }else{
            return false;
        }
        
    }
    get status(){
        return this.pending;
    }


}
