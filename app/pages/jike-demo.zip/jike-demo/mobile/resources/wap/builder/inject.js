import { Api } from './params/api'
import { JsSdk } from './params/JsSdk'


export class Inject {

    constructor(view) {
        var global = {};
        global.view = view;
        global.salt = view.salt;
        global.api = new Api(view);
        global.JsSdk = new JsSdk();
        global.root = `[salt='${view.salt}'] ai-main-wrap[ai-name='${view.html_root}'] `;
        if(view.viewType == 'win'){
            global.root = `[win-name='${view.name}']${global.root}`
        }else{
            let now = global.root;
            global.root = `[win-name='${view.win.name}'][salt='${view.win.salt}'] [frame-name='${view.name}']${now}`;
        }
        // console.info(global.root);
        global = new SdkGenerater(global);
        this.global = global;
        this.api = global.api;
    }

}
