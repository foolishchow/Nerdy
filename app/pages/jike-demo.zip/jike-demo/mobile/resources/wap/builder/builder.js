/* @flow */

import { ScriptLoader } from './script'

var pending = false;

export class Builder {

    constructor(view: Win | Frame) {
        this.loaded = false;
        this.salt = view.salt;
        this.$el = view.$el;
        this.$content = view.$content;
        this.config = view.config;
        this.view = view;
        this.init();
    }

    init() {
        var url = this.config.url.replace(AI.app_url + '/modules', '');
        $.getJSON('../../modules/' + url + '?timestap=' + (+new Date))
            .always(()=>{
                this.view.$loading.hide();
            })
            .then((data) => {
                var html = data.html,
                    title = data.title;
                if( this.view.viewType == 'frame'){
                    document.title = title;
                }    
                this.view.html_root = data.name;
                this.$content.html(html);
                this.$scripts = new ScriptLoader(data.scripts, this);
            })

            .fail((err)=>{
                if(err.status == 404){
                    var html = `
                        <ai-main-wrap>
                            <div class="err-404"></div>
                            <div class="err-desc">
                                您请求的页面不存在！！！
                            </div>
                        </ai-main-wrap>
                    `;
                    this.$content.html(html);
                }
            });
    }

    execScript(param) {
        let execed = false;
        let interval = setInterval(() => {
            if ( this.$scripts && this.$scripts.pending == 2 ) {
                clearInterval(interval);
                new Function(`
                        var inject = arguments[0];
                        var Global = inject.global,
                            global = Global,
                            api = inject.api,
                            JsSdk = Global.JsSdk,
                            api = Global.api,
                            J = JsSdk,
                            Jutil = JsSdk.util,
                            Jhelper = J.helper,
                            Jnav = J.nav,
                            Jlocation = J.location,
                            Jview = J.view;
                            ${param.script};
                `)(this.$scripts.inject)
            }
        }, 50)
    }

}
