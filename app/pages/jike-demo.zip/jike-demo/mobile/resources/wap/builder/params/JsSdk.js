

const JsSdk = ()=>{
    var JsSdk = (func)=>{
        $(function(){
            func();
        })
    };

    // var J = JsSdk;
    // J.util = {};
    // J.util.cloneObject = function(obj){
    //     return JSON.parse(JSON.stringify(obj))
    // }
    return JsSdk;
}
export {JsSdk};