/* @flow */

import { History } from './history'
import { Win } from './view/win'
import { Frame } from './view/frame'
import { Base64 } from './base64'

export default class App {

    static get history() {
        return History;
    }

    static get Win() {
        return Win;
    }

    static get Frame() {
        return Frame;
    }

    static get Base64() {
        return new Base64();
    }

    constructor() {
        this.history = new History();
        this.history.listen(Win.buildInstance);
        this.init();
    }

    init() {
        if (this.history.isRoot) {
            App.initPage(this.history)
        }
    }

    static initPage(history) {
        var win = {
            url: '../platform/root/prd.html',
            name: 'root'
        };
        Win.router(win);
    }
    viewChange(oldHash, newHash, history) {
        console.info(arguments)
    }

    getModule(moduleName) {
        return Win.getModule(moduleName);
    }

    closeWin(param){
        
    }
}


if (App) window.app = new App();
