// (function() {
    var getScript = function(obj){

        /**
         * (function(){
         *  var a = setInterval(function(){
         *      if(window.JsSdk){
         *           clearInterval(a);
         *           J(function(){
         *                var b = window.function(JSON.stringify(param));
         *                //if obj.back 
         *                JsSdk.fire({
         *                    function:'J.fireBack',
         *                    param:{
         *                        evalId:evalId,
         *                        result:b
         *                    },
         *                    winName:page.winName,
         *                    frameName:pahe.frameName
         *                });
         *                //if obj.back end
         *           });  
         *      }
         *  },20);
         * })()
         */
        scripts = [
            ' (function(){                                                          ',
            '  var a = setInterval(function(){                                      ',
            '      if(${env}.JsSdk){                                                ',
            '           clearInterval(a);                                           ',
            '           J(function(){                                               ',
            '                var b = Global.${funcName}(${param_string});           ',  
            // '                console.info(${param_string}) ;                         ',
            // '                console.info(Global.${funcName});                          ',
        ];
        if(obj.back){
            scripts = scripts.concat([   
            '                JsSdk.fire({                                           ',
            '                    function:"J.fireBack",                             ',
            '                    param:{                                            ',
            '                        evalId:"${evalId}",                            ',
            '                        result:b                                       ',
            '                    },                                                 ',
            '                    winName:"${current_win}",                          ',
            '                    frameName:"${current_frame}"                       ',
            '                });                                                    ',
            ]);
        }
        scripts = scripts.concat([   
            '           });                                                         ',
            '      }                                                                ',
            '  },20);                                                              ',
            ' })();                                                                 '
        ]);
        scripts = scripts.join('\n');
        scripts = J.template(scripts,obj);
        // api.toast({
        //     msg:scripts,
        //     duration:100000
        // });
        return scripts;
    }
    /**
     * [JsSdk.fire 调用目标win/frame的方法]
     * @param  {Object} obj       [入参]
     *         {
     *             funcName:''  [string]  方法名称
     *             param:''     [object]  方法入参  可选 default:{}
     *             winName:''   [string]  所属win的名称
     *             frameName:'' [string]  所属frame的名称
     *             back:false   [boolean] 目标页面执行成功后是否回调 default:false
     *         }
     * @useage
     *     //不需要回调
     *     JsSdk.fire({
     *         funcName:"alert",
     *         param:{name:11},
     *         page:{
     *             winName:"winName",
     *             frameName:"frameName"
     *         }
     *     })
     *     //回调
     *     var a = JsSdk.fire({
     *         funcName:"alert",
     *         param:{name:11},
     *         page:{
     *             winName:"winName",
     *             frameName:"frameName"
     *         },
     *         back:true
     *     });
     *     a.then(function(data){
     *         //回调目标页面执行结果
     *     })
     */
    J.fire = function(obj) {
        if (obj.param == undefined) obj.param = {};

        var scripts = "",
            evalId = Jutil.random(3, 'evalId_');
        var innerparam = $.extend({},obj);
        var page = J.context;
        innerparam.param_string = JSON.stringify(innerparam.param);
        innerparam.current_win = page.winName;
        innerparam.current_frame = page.frameName;
        innerparam.evalId = evalId;
        innerparam.env = Jutil.isApp() ? 'window':'Global';
        // innerparam.winName = obj.page.winName;
        // innerparam.frameName = obj.page.frameName

         /**
         * (function(){
         *  var a = setInterval(function(){
         *      if(JsSdk){
         *           clearInterval(a);
         *           J(function(){
         *                var b = window.function(JSON.stringify(param));
         *                JsSdk.fire({
         *                    function:'J.fireBack',
         *                    param:{
         *                        evalId:evalId,
         *                        result:b
         *                    },
         *                    winName:page.winName,
         *                    frameName:pahe.frameName
         *                });
         *           });  
         *      }
         *  },20);
         * })()
         */
        scripts = getScript(innerparam);
       
        var execScript = {
            name: obj.page.winName,
            script: scripts
        };
        if (obj.page.frameName != undefined) execScript.frameName = obj.page.frameName;
        api.execScript(execScript);
        // if (back) return _fireDefferd[evalId].promise();
    };

// })();
