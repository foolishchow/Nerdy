(function() {

    var parsePageParam = function(option) {
        var param = option.pageParam;
        param.__parent = {
            winName: api.winName,
            frameName: api.frameName
        };
    };

    var view = {};
    view.open = function(option) {
        parsePageParam(option);
        var prefix = Jutil.isApp()?AI.app_url :'..';
        var win = {
            name: option.name + '_wrap',
            url: prefix + '/platform/nav/' + option.nav + '.html',
            slidBackEnabled: option.slidBackEnabled,
            animation: Jhelper.animate(option.animation),
            bounces: false,
        };
        option.bgColor && (win.bgColor = option.bgColor);
        
        delete option.animation;
        delete option.slidBackEnabled;
        win.pageParam = option;
        api.openWin(win);
    };

    view.frameGroup = function(opt) {
        var name = opt.name;
        var obj = Object.create({});
        obj._index = opt.index;
        obj.changed = function() {};
        Object.defineProperty(obj, 'index', {
            get: function() {
                return this._index;
            },
            set: function(i) {
                var index, scroll = false,
                    reload = false;
                if (typeof i == 'object') {
                    index = i.index;
                    (i.scroll != undefined) && (scroll = i.scroll);
                    (i.reload != undefined) && (reload = i.reload);
                } else {
                    index = i;
                }
                this._index = i;
                api.setFrameGroupIndex({
                    name: opt.name,
                    index: index,
                    reload: reload,
                    scroll: scroll
                });
            }
        });
        api.openFrameGroup(opt, function(ret) {
            J.fire({
                funcName: 'J.nav._onTabShow',
                page: {
                    winName: api.winName,
                    frameName: ret.name
                }
            });
            if (obj._frameName) {
                J.fire({
                    funcName: 'J.nav._onTabHide',
                    page: {
                        winName: api.winName,
                        frameName: obj._frameName
                    }
                });
            }
            obj._frameName = ret.name;

            obj.changed(ret.index, ret.name);
        });
        return obj;
    };

    view.frame = function (router) {
        var tabs = Jutil.cloneObject(router.tabs),
            pageParam = Jutil.cloneObject({});
        // pageParam.__nav = this.navConfig();
        var index = 0;
        for (var i = 0; i < tabs.length; i++) {
            tabs[i] = $.extend({}, {
                pageParam: Jutil.cloneObject(pageParam),
                name: "tabs" + Jutil.random(4)
            }, tabs[i]);
            if (tabs[i].selected == true || tabs[i].selected == 'true') index = i;
        }
        // this.view.active_tab_index = index;
        var group = {
            name: router.name = undefined ? Jutil.random(4, 'frameGroup') : router.name,
            background: '#fff',
            scrollEnabled: router.scroll,
            rect: router.rect,
            index: index,
            frames: tabs
        };
        return view.frameGroup(group);
    };

    view.openFrame = function(router){
        console.info(router);
        api.openFrame(router)
    };

    J.view = view;
    Global.Jview = view;
})();
(function() {
    var history = [];

    J.location = {};
    Global.Jlocation = J.location;

    Object.defineProperty(J.location, 'href', {
        get: function() {
            return J.context;
        },
        set: function(href) {
             var search = href.replace(/^(.*?)\?/,''),
                routerName = href.replace(/\?(.*?)$/,''),
                router = Jutil.router(routerName);
            if(search != ''){
                var param = {};
                search.split('&').forEach(function(line){
                    var arr = line.split('=');
                    if(arr.length == 2){
                        param[arr[0]] = arr[1];
                    }
                });
                router = $.extend(router,{pageParam:param});
                // console.info(router);
            }
            Jview.open(router);
        }
    });

    Object.defineProperty(J.location, 'history', {
        get: function() {
            return history;
        },
        set: function() {

        }
    });

    J.location.back = function(num) {
        var winName = J.location.prev(num).winName;
        api.closeToWin({
            name: winName
        })
    };

    J.location.prev = function(num) {
        if (num == undefined) num = 1;
        num = parseInt(num) + 1;
        return history[history.length - num];
    };
    J(function() {
        if (api.pageParam && api.pageParam.__history) {
            history = api.pageParam.__history;
        } else {
            history = [];
        }
        history.push({
            winName: api.winName,
            frameName: api.frameName
        });
    });
})();
