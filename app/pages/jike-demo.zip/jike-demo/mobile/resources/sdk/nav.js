(function() {
    var navHeight = 0,
        barHeight = 0,
        navPage = {};

    var nav = {};
    nav.autoUpdateButton = true;
    nav.autoUpdateTitle = true;
    Object.defineProperty(nav, 'height', {
        get: function() {
            return navHeight;
        },
        set: function() {}
    });

    Object.defineProperty(nav, 'bar', {
        get: function() {
            return barHeight;
        },
        set: function() {}
    });

    Object.defineProperty(nav, 'title', {
        get: function() {},
        set: function(title) {
            J.fire({
                funcName: 'nav.updateTitle',
                param: {
                    title: title
                },
                page: navPage
            })
        }
    });

    var getInhertConfig = function() {
        if ($("nav-button").length == 0) return;
        var text = $("nav-button").text().replace(/^\n*/gi,'');
        var func = 'return ${config};';
        // if($("nav-button").attr('type')) func = 'return (function(){ ${config};})();'
        func = J.template(func, { config: text });
        try {
            var a = new Function(func);
            var c = a();
            return c;
        } catch (e) {
            alert(e);
            return;
        }
    };

    nav.button = function(obj) {
        if (obj == undefined) {
            obj = getInhertConfig();
        }
        if (obj == undefined) return;
        JsSdk.fire({
            funcName:'nav.configButton',
            param:{
                config:obj,
                page:J.context
            },
            page:navPage
        });
    };

    nav._onTabShow = function(){
        // console.info(api.winName +"->"+api.frameName +":show");
    };
    nav.onTabShow = function(callBack){
        nav._onTabShow = callBack;
    };
    nav._onTabHide = function(){
        // console.info(api.winName +"->"+api.frameName +":hide");
    };
    nav.onTabHide = function(callBack){
        nav._onTabHide = callBack;
    };
    J.nav = nav;
    Global.Jnav = nav;

    var updateTitle = function() {
        var param = api.pageParam;
        if (param == undefined) return;
        if (nav.autoUpdateTitle == false) return;
        if (param.updateTitle == undefined || param.updateTitle == true) {
            if (api.frameName) nav.title = document.title;
        }
    };
    var updateButton = function() {
        if (nav.autoUpdateButton == false) return;
        nav.button();
    };
    J(function() {
        var param = api.pageParam;
        if (!api.frameName) return;
        if (param.__nav) {
            navHeight = param.__nav.total;
            barHeight = param.__nav.top;
            navPage = param.__nav.page;
            J.context = {
                type: param.__nav.pageType
            }
            if (J.context.type == 'frameGroupPage') {
                // nav.autoUpdateButton = false;
                nav.autoUpdateTitle = false;
            }
            updateTitle();
            updateButton();
        };


    });
})();
