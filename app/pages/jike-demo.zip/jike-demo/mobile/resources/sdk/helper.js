(function() {
    var h = {};
    var ANIMATE = {
        fade: {
            type: "fade",
            subType: "from_right",
            duration: 200
        },
        down: {
            type: "movein",
            subType: "from_top",
            duration: 200
        },
        up: {
            type: "movein",
            subType: "from_bottom",
            duration: 200
        },
        left: {
            type: "movein",
            subType: "from_right",
            duration: 200
        },
        right: {
            type: "movein",
            subType: "from_left",
            duration: 200
        }
    };

    h.isFunction = function(a) {
        return a instanceof Function;
    };
    h.isString = function(s) {
        return (typeof s).toLowerCase() == "string";
    };
    h.isObject = function(s) {
        return (typeof s).toLowerCase() == "object";
    };

    h.animate = function(animateString) {
        if (animateString == undefined) return ANIMATE['right'];
        if (h.isString(animateString)) {
            animateString = animateString.toLowerCase();
            return ANIMATE[animateString];
        }
        return animateString;
    };

    h.CALLBACK_UNITIES = {};
    h.callback = function(callback) {
        if (h.isString(callback)) return callback;
        if (h.isFunction(callback)) {
            var cacheName = Jutil.random(4, "helper_cb_cache");
            helper.CALLBACK_UNITIES[cacheName] = callback;
            return "Jhelper.CALLBACK_UNITIES." + cacheName;
        }
    };
    h.callBack = h.callback;

    h.htmlDecode = function(str) {
        if (str == null) return "<div></div>";
        var s = "";
        if (str.length == 0) return "";
        s = str.replace(/&gt;/g, "&");
        s = s.replace(/&lt;/g, "<");
        s = s.replace(/&gt;/g, ">");
        s = s.replace(/&nbsp;/g, " ");
        s = s.replace(/&#39;/g, "\'");
        s = s.replace(/&quot;/g, "\"");
        s = s.replace(/<br>/g, "\n");
        s = s.replace(/\\r\\n/g, '<br/>');
        s = s.replace(/\\n/g, '<br/>');
        s = s.replace(/\\t/g, '');
        return s;
    };

    J.helper = h;
    Global.Jhelper = h;
})();
