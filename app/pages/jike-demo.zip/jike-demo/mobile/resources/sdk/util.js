var util = {};
/**
 * [JsSdk.util.random 生产随机数]
 * @param  {[interger]} loopNum [循环次数]
 * @param  {[string]} preffix [前缀]
 * @return {[type]}         [description]
 */
util.random = function(loopNum, preffix) {
    if (loopNum == undefined) loopNum = 3;
    var ran = preffix != undefined ? preffix : "";
    for (var i = 0; i < loopNum; i++) {
        ran += Math.round(Math.random() * i * 10)
    }
    return ran;
};

util.cloneObject = function(Obj) {
    return JSON.parse(JSON.stringify(Obj));
};


util.router = function(routeName) {
    var prefix = util.isApp() ? AI.app_url + '/modules/' : '';
    var param = util.cloneObject(Router[routeName]);
    if (param.type == 'frameGroup') {
        param.tabs.forEach(function(tab) {
            tab.url = prefix + tab.url + '.html';
        })
    } else {
        param.url = prefix + param.url + '.html';
    }
    param.pageParam.__history = J.location.history;
    return param;
};

util.isApp = function() {
    return navigator.userAgent.match(/ai-app-cloud/) ? true : false;
};

util.message = function(code) {
    if (MESSAGE[code] == undefined) return '';
    var message = MESSAGE[code];
    var arr = [],
        i = 1;
    while (i < arguments.length) {
        arr.push(arguments[i]);
        i++;
    }
    if (arr.length > 0) {
        message = message.replace(/\{(.*?)\}/gi, function(whole) {
            if (arr.length > 0) {
                return arr.shift();
            } else {
                return whole;
            }
        });
    }
    return message;
};


(function() {
    var inited = false,
        UIScrollPicture = null;
    var swraper = function() {
        if (!inited) {
            UIScrollPicture = api.require('UIScrollPicture');
            inited = true;
        }
        return UIScrollPicture;
    };

    /**
     * [JsSdk.util.swraper.open 打开轮播组件]
     * @param  {[type]} obj
     *         object : {
     *             target : ''  // String||domObject 附着于该目标上
     *             configs:[
     *                  {
     *                      src:''  //图片地址
     *                      ...     //其余参数
     *                  }
     *             ],
     *             click:function(index,configsItem){}
     *         }
     * @useage
     *       JsSdk.util.swraper.open({
     *           target:'#main',
     *           configs:[
     *               {
     *                   src:"aaa.jpg",
     *                   href:'bbb.html',
     *                   attr:{
     *                       .....
     *                   }
     *               }
     *           ],
     *           click:function(index,data){
     *               // data =>  {
     *               //     src:"aaa.jpg",
     *               //     href:'bbb.html',
     *               //     attr:{
     *               //         ...
     *               //     }
     *               // }
     *           }
     *       });
     */
    swraper.open = function(obj) {
        if (!inited) swraper();

        var paths = [],
            clicks = obj.click,
            configs = obj.configs;
        obj.configs.forEach(function(config) {
            paths.push(config.src);
        });

        UIScrollPicture.open({
            rect: {
                x: Math.ceil(obj.target.offset().left),
                y: Math.ceil(obj.target.offset().top),
                w: Math.ceil(obj.target.width()),
                h: Math.ceil(obj.target.height())
            },
            data: {
                paths: paths
            },
            styles: {
                indicator: {
                    align: 'center',
                    color: '#DA70D6',
                    activeColor: '#ffffff'
                }
            },
            contentMode: 'scaleToFill',
            interval: 3,
            loop: true,
            fixedOn: api.frameName,
            fixed: false
        }, function(ret, err) {
            if (ret) {
                if (ret.status == true && ret.eventType == "click") {
                    try {
                        var index = ret.index;
                        clicks(index, configs[index]);
                    } catch (e) {
                        // console.info("error");
                    }
                }
            }
        });
    };
    /**
     * [JsSdk.util.swraper.close 关闭轮播组件引用]
     * @useage
     *     //重新open之前，要关闭
     *     JsSdk.onPageClose(function() {
     *           JsSdk.util.swraper.close();
     *     });
     */
    swraper.close = function() {
        if (!inited) return;
        UIScrollPicture.close();
    };


    util.swraper = swraper;

})();



JsSdk.util = util;
Global.Jutil = util;
