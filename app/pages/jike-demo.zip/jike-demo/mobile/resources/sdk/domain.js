/**
 * [Object.clone]
 * @return {[type]} [description]
 */
(function(){
    function clone(obj) {
        // Handle the 3 simple types, and null or undefined
        if (null == obj || "object" != typeof obj) return obj;

        // Handle Date
        if (obj instanceof Date) {
            var copy = new Date();
            copy.setTime(obj.getTime());
            return copy;
        }

        // Handle Array
        if (obj instanceof Array) {
            var copy = [];
            for (var i = 0, len = obj.length; i < len; ++i) {
                copy[i] = clone(obj[i]);
            }
            return copy;
        }

        // Handle Object
        if (obj instanceof Object) {

            var copy = obj.domainType ? new Cart[obj.domainType+"Domain"]() : {};
            for (var attr in obj) {
                if (obj.hasOwnProperty(attr)) copy[attr] = clone(obj[attr]);
            }
            return copy;
        }

        throw new Error("Unable to copy obj! It's type isn't supported.");
    }

    Object.clone = function(obj){
        return clone(obj); 
    }
})();
(function(){
    var staticProp = ["domainName","clear"];
    var DomainDefiner = function(name){
        var domain = function(){
            for(var key in this){
                // 将原型链上的属性拉取到自身 并解决引用 指向同一对象的问题
                if( $.inArray(key,staticProp) == -1 && !( this[key] instanceof Function) ) this[key] = Object.clone(this[key]);
            }
        };
        Object.defineProperty(domain.prototype,'domainName',{
            value        : name,
            writable     : false, 
            enumerable   : true, 
            configurable : true
        });
        Object.defineProperty(domain.prototype,'clear',{
            value        : function(){
                for(var key in this){
                    if( $.inArray(key,staticProp) == -1 && !( this[key] instanceof Function) ) this[key] = Object.clone(this["__proto__"][key]);
                }
            },
            writable     : false, 
            enumerable   : true, 
            configurable : true
        });
        Object.defineProperty(domain.prototype,'isDefault',{
            value        : function(name){
                
                // for(var key in this){
                //     if( $.inArray(key,staticProp) == -1 && !( this[key] instanceof Function) ) this[key] = Object.clone(this["__proto__"][key]);
                // }
            },
            writable     : false, 
            enumerable   : true, 
            configurable : true
        });
        $.extend(domain,{
            define:function(keys){
                /*,defaultValue,writable,enumerable,configurable*/
                if( (typeof keys).toLowerCase() == 'string') keys = [keys];
                keys.forEach(function(keyArr){
                    Object.defineProperty(domain.prototype,keyArr[0],{
                        value        : keyArr[1] != undefined ? keyArr[1] : null,
                        writable     : keyArr[2] != undefined ? keyArr[2] : true, 
                        enumerable   : keyArr[3] != undefined ? keyArr[3] : true, 
                        configurable : keyArr[4] != undefined ? keyArr[4] : true
                    });
                });
            }
        });
        return domain;
    };

    $.extend($,{
        Domain:function(name){
            return new DomainDefiner(name);
        }
    });
})();