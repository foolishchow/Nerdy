if (navigator.userAgent.match(/ai-app-cloud/)) {
    JsSdk.ajax = function(options) {
        (options == undefined) && (options = {});
        //app
        options = $.extend({ method: 'post' }, options);
        var d = $.Deferred();
        var url = options.url;
        options.url = AI.InterFaceIp + AI.InterfaceUrl + options.url + '';
        options.headers = options.headers == undefined ? {} : options.headers;
        options.headers["content-type"] = 'application/json;charset=UTF-8';
        options.data = {body:JSON.stringify(options.data)};
        api.ajax(options, function(ret, err) {
            if (err) {
                d.reject(err)
            }
            if (ret) {
                if(ret.errcode != '000'){
                    toast(ret.errmsg);
                    d.reject(new Error(ret.errmsg));

                }else{
                    d.resolve(ret.data);
                }
            }
        })
        return d.promise();

    }
} else {
    JsSdk.ajax = function(options) {
        options == undefined && (options = {});
        //wap
        options = $.extend({ type: 'post', dataType: 'json' }, options);
        options.beforeSend = function(request) {
            request.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        };
        options.data = JSON.stringify(options.data);
        options.url = '/' + AI.InterfaceUrl + options.url;
        var d = $.Deferred();
        $.ajax(options)
        .then(function(data){
            if(data.errcode != '000'){
                toast(data.errmsg);
                d.reject(new Error(data.errmsg));

            }else{
                d.resolve(data.data);
            }
        })
        .fail(function(err){
            d.reject(err)
        });
        return d.promise();
    }
}
