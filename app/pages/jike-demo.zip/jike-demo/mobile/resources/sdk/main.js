(function() {
    if(navigator.userAgent.match(/ai-app-cloud/)){
        window.Global = window;
        Global.root = '';
    }
    var page = {},
        readyList = [],
        readyStatus = false;

    /**
     * [JsSdk JsSdk 加载成功回调]
     * @param {[function]} func [回调函数]
     */
    if (Global.JsSdk == undefined) {
        Global.JsSdk = function(func) {
            if (readyStatus) {
                func();
                return;
            }
            readyList.push(func);
        };
    }

    var JsSdk = Global.JsSdk;

    /**
     * [JsSdk.ready JsSdk 加载成功回调]
     * @param  {[type]} func [回调函数]
     */
    JsSdk.ready = function(func) {
        JsSdk(func);
    };
    /**
     * [JsSdk.context 获取/设置页面属性 ]
     * @type   attribute
     * @param  {[object]} obj [设置的属性/不传就是获取]
     * @return {[Object]}     [当前页面属性]
     *  // obj 
     *  {
     *       type     :'frame'/'win',
     *       frameName:'frameName'/undefined,
     *       winName  :'winName',
     *       __parent:{
     *           winName:'parentWinName',
     *           frameName:'parentFrameName'/undefined,
     *       },
     *       __nav:{
     *           height: num,  //nav的总高度
     *           barHeight: num //状态栏高度
     *       }
     *   }
     *
     *  
     */
    Object.defineProperty(JsSdk, 'context', {
        get: function() {
            return page;
        },
        set: function(obj) {
            if (obj != undefined) page = $.extend(page, obj, true);
            return page;
        }
    });
    // JsSdk.context = function(obj) {
    //     if (obj != undefined) page = $.extend( page, obj,true);
    //     return page;
    // };


    var parseWinType = function() {
        var context = {
            type: 'win',
            winName: api.winName
        }
        if (api.frameName) {
            context.type = 'frame';
            context.frameName = api.frameName;
        }
        if (api.pageParam == undefined) return;
        var param = api.pageParam;
        J.context = context;
    };

    var parseUI = function() {
        var param = api.pageParam;
        // if (param != undefined && param.updateTitle == false) return;
        // if (api.frameName) {
        //     JsSdk.nav.title(document.title);
        // }
    };

    window.apiready = function() {
        parseWinType();
        parseUI();
        readyStatus = true;
        readyList.forEach(function(func) {
            func();
        });
    };
    // Global.JsSdk = JsSdk;
    Global.J = JsSdk;
    // window.Global = window;
    //event
    /**
     * [JsSdk.on/JsSdk.bind 事件监听]
     *     api.addEventListener({name:'name1',function(){}}) => JsSdk.on('name1',function(){})
     *     
     * @param  {[string]} name [description]
     * @param  {[FUNCTION]} func [description]
     */
    JsSdk.on = function(name, func) {
        return api.addEventListener({
            'name': name
        }, func);
    };

    JsSdk.bind = JsSdk.on;

    /**
     * [JsSdk.unbind 解除事件监听]
     * @param  {[string]} name [解除的监听事件名称]
     */
    JsSdk.unbind = function(name) {
        api.removeEventListener({ "name": name });
    };
    /**
     * [JsSdk.once 绑定事件监听  触发一次后解除 只会触发一次]
     * @param  {[string]} name [事件名称]
     * @param  {function} func [回调方法]
     */
    JsSdk.once = function(name, func) {
        return api.addEventListener({
            'name': name
        }, function() {
            func();
            api.removeEventListener({ "name": name });
        });
    };


    J.template = function(source, data) {
        return source.replace(/\$\{(.*?)\}/gi, function(whole, $1) {
            var key = $1.replace(/\s+|\s+$/gi, '');
            if (data[key]) {
                return data[key];
            } else {
                return whole;
            }
        });
    };


    var _parent = {};

    var parent = function(obj) {
        if (obj != undefined) _parent = $.extend({}, _parent, obj);
        return _parent;
    };

    J(function() {
        if (api.pageParam && api.pageParam.__parent) parent(api.pageParam.__parent);
        J.context = {
            winName:api.winName,
            frameName:api.frameName
        };
    });
})();
