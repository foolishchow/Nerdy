(function() {
    window.alert = function(o) {
        if(navigator.userAgent.match(/ai-app-cloud/)){
            J(function() {
                api.alert({ msg: JSON.stringify(o) })
            });
        }else{
            if((typeof o).toLowerCase() == 'string' ){
                Vue.$messagebox.alert(o, '提示');
            }else{
                Vue.$messagebox.alert(JSON.stringify(o), '提示');
            }
        }
    };
    window.toast = window.info = window.msg = function(o) {
        if(navigator.userAgent.match(/ai-app-cloud/)){
            J(function() {
                api.toast({ msg: o })
            });
        }else{
            if((typeof o).toLowerCase() == 'string' ){
                Vue.$toast(o);
            }else{
                Vue.$toast(JSON.stringify(o));
            }
        }
    }
})();
(function(){
    Date.prototype.Format = function(fmt) {
        fmt = fmt ? fmt : "yyyy-MM-dd HH:mm:ss"; //HH:mm:ss
        var o = {
            "M+": this.getMonth() + 1,
            /*月份*/
            "d+": this.getDate(),
            /*日*/
            "H+": this.getHours(),
            /*小时*/
            "h+": this.getHours() % 12,
            /*小时*/
            "m+": this.getMinutes(),
            /*分*/
            "s+": this.getSeconds(),
            /*秒*/
            "q+": Math.floor((this.getMonth() + 3) / 3),
            /*季度*/
            "S": this.getMilliseconds() /*毫秒*/
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        if (/(Y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            }
        }
        return fmt;
    };
    Date.prototype.secondBefore = function(num){
        var time = (this.getTime() / 1000 - num - 1 ) * 1000;
        this.setTime(time)
        return this;
    };
    Date.prototype.secondAfter = function(num){
        var time = (this.getTime() / 1000 + parseInt(num) ) * 1000;
        this.setTime(time);
        return this;
    };
    Date.prototype.mimuteBefore = function(num){
        var time = this.getTime()  - num * 1000 * 60 ;
        this.setTime(time)
        return this;
    };
    Date.prototype.mimuteAfter = function(num){
        var time = this.getTime()  + parseInt(num) * 60 * 1000 ;
        this.setTime(time);
        return this;
    };
    Date.prototype.hourBefore = function(num){
        var time = this.getTime()  - num * 1000 * 60 * 60 ;
        this.setTime(time)
        return this;
    };
    Date.prototype.hourAfter = function(num){
        var time = this.getTime()  + parseInt(num) * 60 * 60 * 1000 ;
        this.setTime(time);
        return this;
    };
    Date.prototype.dayBefore = function(num){
        var time = this.getTime()  - num * 1000 * 60 * 60 * 24;
        this.setTime(time)
        return this;
    };
    Date.prototype.datAfter = function(num){
        var time = this.getTime()  + parseInt(num) * 60 * 60 * 1000 * 24;
        this.setTime(time);
        return this;
    };
    
})();
(function() {
    Array.prototype.hasString = function(str) {
        var hasString = false;
        this.forEach(function(item) {
            (item == str) && (hasString = true);
        });
        return hasString;
    };
    Array.prototype.removeString = function(str) {
        if (!this.hasString(str)) return;
        var index = -1;
        for (var i = 0; i < this.length; i++) {
            if (this[i] == str) {
                index = i;
                break;
            }
        }
        this.splice(index, 1);
    };
})();
(function() {
    if (typeof String.prototype.startsWith != 'function') {
        String.prototype.startsWith = function(prefix) {
            return this.slice(0, prefix.length) === prefix;
        };
    }
    if (typeof String.prototype.endsWith != 'function') {
        String.prototype.endsWith = function(suffix) {
            return this.indexOf(suffix, this.length - suffix.length) !== -1;
        };
    }
})();