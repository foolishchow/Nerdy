Vue.component('ai-swiper', Vue.extend({
    props: ['model'],
    template:
    '<div class="swipe">'+
        '<ai-swipe v-if="!isApp" :show-indicators="true">'+
            '<ai-swipe-item class="item"  v-for="v in model">'+
                '<img :src="v.src" alt="">'+
            '</ai-swipe-item>'+
        '</ai-swipe>'+
    '</div>' ,
    data:function () {
        return {
            isApp:Jutil.isApp()
        }
    },
    
    mounted:function () {

        var vm = this;
        if(this.isApp){
            J(function () {
                JsSdk.util.swraper.open({
                    target: $(vm.$el),
                    configs: vm.model,
                    // configs: cong,
                    click: function(index, dat) {
                        /*JsSdk.newWin({
                         name: "p",
                         url: dat.href
                         });*/
                    }
                });
            })
        }
    }
}));

Vue.component('ai-product-swiper', Vue.extend({
    props: ['model'],
    template:
    '<div class="ai-product-swipe">'+
        '<ai-swipe v-if="!isApp" :show-indicators="true">'+
            '<ai-swipe-item class="item"  v-for="v in model.tag">'+
                '<img :src="v.src" alt="">'+
            '</ai-swipe-item>'+
        '</ai-swipe>'+
    '</div>' ,
    data:function () {
        return {
            isApp:Jutil.isApp()
        }
    },
    
    mounted:function () {
        var vm = this;
        if(this.isApp){
            J(function () {
                JsSdk.util.swraper.open({
                    target: $(vm.$el),
                    configs: vm.model.tag,
                    // configs: cong,
                    click: function(index, dat) {
                        /*JsSdk.newWin({
                         name: "p",
                         url: dat.href
                         });*/
                    }
                });
            })
        }
    }
}));




