var out = process.stdout;
var gulp = require("gulp");
    require('./bin/app'),
    require('./bin/wap'),
    require('./bin/build-app'),
    require('./bin/build-wap'),
    ip = require('./bin/helper/ip'),
    log = require('single-line-log').stdout;

// var i = 1;
// setInterval(()=>{
//     log(`this is ${i} time `);
//     i++;
// },2000);
// process.stdout.on('data',()=>{
//     console.info('----------------');
//     console.info(arguments);
//     console.info('----------------');
// })
gulp.task('ip',()=>{
    ip();
});
gulp.task("app",['ip','app:default']);
gulp.task("default",['ip','app:default','wap:default']);

gulp.task("wap",['ip','wap:default']);


gulp.task("all",['ip','app:default','wap:all']);