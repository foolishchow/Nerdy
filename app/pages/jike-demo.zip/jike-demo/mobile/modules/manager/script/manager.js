J(function(){
    new Vue({
        el:Global.root+'[vue-id="manager"]',
        methods:{
            goUserList:function(){
                J.location.href="userlist"
            },
            goDepartList:function(){
                J.location.href="departlist"
            }
        }
    })
});