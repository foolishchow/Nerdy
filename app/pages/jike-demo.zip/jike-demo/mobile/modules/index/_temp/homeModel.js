Global.data = {
  "api": "",
  "code": "1",
  "version":"",
  "data": {
    "modelList": [
        {
          "modelType": "swipe",
          "modelTpl": "swipe_tpl",
            "uuid": "770",
            "tag": [
              {
                "type": "image",
                "color": "",
                "desc": "",
                "title": "下载",
                "link": "",
                "uuid": "770",
                "src": "http://image1.suning.cn/uimg/cms/img/147185746211558824.jpg"
              },
              {
                "type": "image",
                "color": "",
                "desc": "",
                "title": "下载",
                "link": "",
                "uuid": "770",
                "src": "http://image1.suning.cn/uimg/cms/img/147185746211558824.jpg"
              }
            ]
          },
         {
          "modelType": "icons",
          "modelTpl": "icons_tpl",
          "uuid": "770",
           "tag": [
             {
               "type": "image",
               "color": "",
               "desc": "",
               "title": "",
               "link": "",
               "uuid": "770",
               "src": "http://image3.suning.cn/uimg/cms/img/147061919297516376.png"
             },
             {
               "type": "image",
               "color": "",
               "desc": "",
               "title": "",
               "link": "",
               "uuid": "770",
               "src": "http://image3.suning.cn/uimg/cms/img/147312866702421071.png"
             },
             {
               "type": "image",
               "color": "",
               "desc": "",
               "title": "",
               "link": "",
               "uuid": "770",
               "src": "http://image3.suning.cn/uimg/cms/img/147789989972960898.png"
             },
             {
               "type": "image",
               "color": "",
               "desc": "",
               "title": "",
               "link": "",
               "uuid": "770",
               "src": "http://image3.suning.cn/uimg/cms/img/147765584463288142.png"
             },
             {
               "type": "image",
               "color": "",
               "desc": "",
               "title": "",
               "link": "",
               "uuid": "770",
               "src": "http://image3.suning.cn/uimg/cms/img/147790006620384651.png"
             }
           ]

        },
      {
        "modelType": "space",
        "modelTpl": "space_tpl",
        "uuid": "770"
      },
        {
          "modelType": "S1_img",
          "modelTpl": "S1_img_tpl",
          "uuid": "770",
          "tag": [
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/146768146100089561.jpg"
            }
          ]
        },
        {
          "modelType": "L1_M2_img",
          "modelTpl": "L1_M2_img_tpl",
          "uuid": "770",
          "tag": [
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148163094393172061.jpg"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148154977474426350.png"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148137103521703806.jpg"
            }
          ]
        },
      {
        "modelType": "space",
        "modelTpl": "space_tpl",
        "uuid": "770"
      },
        {
          "modelType": "L3_img",
          "modelTpl": "L3_img_tpl",
          "uuid": "770",
          "tag": [
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148162472363516549.jpg"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148167645635261655.jpg"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148155896724037390.jpg"
            }
          ]
        },
        {
          "modelType": "M2_img",
          "modelTpl": "M2_img_tpl",
          "uuid": "770",
          "tag": [
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148163521022245648.jpg"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/147009989972475076.jpg"
            }

          ]
        },
        {
          "modelType": "L1_M2_img",
          "modelTpl": "L1_M2_img_tpl",
          "uuid": "770",
          "tag": [
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148159511508112774.png"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148169831454383683.png"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148163193716059991.png"
            }
          ]
        },
      {
        "modelType": "space",
        "modelTpl": "space_tpl",
        "uuid": "770"
      },
      {
          "modelType": "L1_M2_img",
          "modelTpl": "L1_M2_img_tpl",
          "uuid": "770",
          "tag": [
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148162916650417152.jpg"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148145047965301818.jpg"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148163718067477117.jpg"
            }
          ]
        },
      {
        "modelType": "space",
        "modelTpl": "space_tpl",
        "uuid": "770"
      },
      {
          "modelType": "L1_M2_img",
          "modelTpl": "L1_M2_img_tpl",
          "uuid": "770",
          "tag": [
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148067785881207805.jpg"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148154910605540313.jpg"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148163572509978013.png"
            }
          ]
        },
      {
        "modelType": "space",
        "modelTpl": "space_tpl",
        "uuid": "770"
      },
      {
          "modelType": "L1_M2_img",
          "modelTpl": "L1_M2_img_tpl",
          "uuid": "770",
          "tag": [
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148159656719504370.jpg"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148125439859407756.jpg"
            },
            {
              "type": "image",
              "color": "",
              "desc": "",
              "title": "",
              "link": "",
              "uuid": "770",
              "src": "http://image5.suning.cn/uimg/cms/img/148162246955165912.jpg"
            }
          ]
        },
      {
        "modelType": "space",
        "modelTpl": "space_tpl",
        "uuid": "770"
      }

    ]
  }
}