/**
 * Created by xiangpaopao on 16/12/6.
 */
Global.homeService = Global.homeService || {};
Global.homeService.init = function() {
    return J.ajax({
        url: InterFace.root.rootData,
    });
}

Global.homeViewer = Global.homeViewer || {};

Global.homeViewer.init = function() {
    new Vue({
        el: '#homeMainEl',
        data: {
            model: {
                icons: [],
                products: [],
                swipe: [],
            },
            rangeValue: '1'
        },

        created: function() {
            var vm = this;

            Global.homeService.init()
                .always(function() {

                }).then(function(data) {
                    vm.model.products = data.goods_list;
                    vm.model.icons = data.root_menu_list;
                    vm.model.swipe = data.root_image_list;
                }).fail(function(err) {
                    // alert(err);
                });

        },

        methods: {
            goProductDetail: function() {
                J.location.href = 'productdetail?id=iaaaaaaa'
            },
            goProductOrder: function() {
                J.location.href = 'order?id=iaaaaaaa'
            },
            goLogin: function() {
                J.location.href = 'login'
            },
            goReg: function() {
                J.location.href = 'reg'
            },
            goCloud: function() {
                J.location.href = 'wideband'
            },
            goRoute: function(key) {
                J.location.href = key
            }
        }
    })
};


J(function() {
    Global.homeViewer.init();
    // alert(Jutil.message('confirmDelate', '商品', '云产品'))
});
