/**
 * Created by xiangpaopao on 16/12/6.
 */


new Vue({
    el: Global.root + "[vue-id='taskdetail']",
    data: {
        taskList: [{
            id: '0',
            name: '关于本年度统计报告的整理',
            status: '0',
            transactor: '王小二',
            detail: '关于本年度统计报告的整理工作的执行，由李磊整理本年度工作梗概，夏雨整理并编写年度统计报告，王小二校正并排版，后交于王娜娜整理打印。',
            progress: [{
                date: '2016-12-20',
                transactor: '李磊',
                status: 1
            }, {
                date: '2016-12-25',
                transactor: '夏雨',
                status: 1
            }, {
                transactor: '王小二',
                status: '0'
            }]
        }, {
            id: '1',
            name: '2017年度工作计划',
            status: '0',
            transactor: '王娜娜',
            detail: '2017年已经到来，新的一年的工作计划需要迅速安排，李伟负责起草年度工作计划草稿，王小二校正并排版，后交于王娜娜整理打印。',
            progress: [{
                date: '2016-12-20',
                transactor: '李伟',
                status: 1
            }, {
                date: '2016-12-25',
                transactor: '王小二',
                status: 1
            }, {
                transactor: '王娜娜',
                status: '0'
            }]
        }, {
            id: '2',
            name: '2016年度报销窗口关闭工作安排',
            status: 1,
            transactor: '李伟',
            detail: '2016年度工作即将结束，报销窗口也即将关闭，王娜娜整理为报销的单据，交于李伟集体报销。',
            progress: [{
                date: '2016-12-20',
                transactor: '李磊',
                status: 1
            }, {
                date: '2016-12-25',
                transactor: '夏雨',
                status: 1
            }, {
                transactor: '王小二',
                date: '2016-12-28',
                status: 1
            }]
        }],
        viewModel:{
            showProgress:false,
            selectUser:false,
                selectIndex:0
        },
        model:{
                userList:[
                    {
                        name:'林三',
                        depart:'人事部',
                        id:'0'
                    },
                    {
                        name:'李四',
                        depart:'人事部',
                        id:'1'
                    },
                    {
                        name:'王五',
                        depart:'人事部',
                        id:'2'
                    },
                    {
                        name:'王小二',
                        depart:'人事部',
                        id:'3'
                    },
                    {
                        name:'刘娜娜',
                        depart:'行政部',
                        id:'4'
                    },
                    {
                        name:'刘某',
                        depart:'行政部',
                        id:'5'
                    },
                    {
                        name:'夏雨',
                        depart:'人事部',
                        id:'6'
                    }
                ]
            }
    },


    created: function() {
        var vm = this;

    },

    computed: {
        current: function() {
            return this.taskList[api.pageParam.id]
        },
        showProgressStatus: function() {
            return this.viewModel.showProgress ?  'xiangshangjiantou':'xiangxiajiantou';
        },
         selectedUser:function(){
                return this.viewModel.selectIndex == 0 ? '请选择': this.viewModel.selectIndex;
            }
    },
    methods: {
        addTask:function(){
                toast('操作成功！');
                api.closeWin();
            }
    },
    watch:{
        "viewModel.selectIndex":function(val){
                this.viewModel.selectUser = false;
            }
    }
})
