/**
 * Created by xiangpaopao on 16/12/6.
 */


new Vue({
    el: Global.root+"[vue-id='myorder']",
    data: {
           orderList:[]

    },


    created: function() {
        var vm = this;
        this.taskList=[
            {   
                id:'0',
                name:'关于本年度统计报告的整理',
                status:'0',
                transactor:'王小二',
                detail:'关于本年度统计报告的整理工作的执行，由李磊整理本年度工作梗概，夏雨整理并编写年度统计报告，王小二校正并排版，后交于王娜娜整理打印。'
            },
            {
                id:'1',
                name:'2017年度工作计划',
                status:'0',
                transactor:'王娜娜',
                detail:'2017年已经到来，新的一年的工作计划需要迅速安排，李伟负责起草年度工作计划草稿，王小二校正并排版，后交于王娜娜整理打印。'
            },
            {
                id:'2',
                name:'2016年度报销窗口关闭工作安排',
                status:1,
                transactor:'李伟',
                detail:'2016年度工作即将结束，报销窗口也即将关闭，王娜娜整理为报销的单据，交于李伟集体报销。'
            }
        ]

    },

    computed:{

    },
    methods: {
        gotoDetail:function (id) {
            J.location.href = 'taskdetail?id='+id;
        }

    }
})

