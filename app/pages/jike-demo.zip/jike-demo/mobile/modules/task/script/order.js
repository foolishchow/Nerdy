/**
 * Created by xiangpaopao on 16/12/6.
 */

// Vue.use(VueLazyload)

Global.reviewService = Global.reviewService || {};

/**
 * 获取客户地址信息列表
 * @param cust_id
 */
Global.reviewService.getAddressList = function(cust_id) {
    return J.ajax({
        url: InterFace.address.getAddressList,
        data: {
            "cust_id": cust_id
        }
    })
}

Global.homeViewer = Global.homeViewer || {};
Global.homeViewer.init = function() {
    new Vue({
        el: Global.root + "[vue-id='order']",
        data: {
            model: {
                user: {
                    name: '',
                    tel: '',
                    address: '',
                    userType: '0' //账号类型,用于控制权限
                },
                director: {
                    selectedGroup: '',
                    selectedAddress: '',
                    groupList: [],
                    addressList: [],

                },


                productList: [],
                totalPrice: '222.22',

            },
            viewModel: {
                addressVisible: true,
                groupName: '',
                groupPopupVisible: false,
                addressPopupVisible: false,
                sccuessPanel: false,
                loading: false,
                loadStatus: 'loading'
            }

        },


        created: function() {
            var vm = this;

            this.getUserInfo();
            this.getPros();

        },

        computed: {},
        methods: {
            getUserInfo: function() {
                var vm = this;
                Global.reviewService.getAddressList(1).then(function(data) {
                    console.log(data);
                    vm.model.user.name = data.address_list[0].receiver_name;
                    vm.model.user.tel = data.address_list[0].mobile_phone;
                    vm.model.user.address = data.address_list[0].post_addr;
                    vm.model.director.addressList = data.address_list;
                });
            },
            getPros: function() {
                this.model.productList = JSON.parse(sessionStorage.getItem('_tempCartPros'));
            },

            getGroup: function() {
                this.viewModel.groupPopupVisible = true;
                //$.ajax....
                this.model.director.groupList = [{
                    id: '11',
                    name: '亚信',
                    contact: '周先生',
                    phone: '13888888888'
                }, {
                    id: '12',
                    name: '亚信',
                    contact: '周先生',
                    phone: '13888888888'
                }, {
                    id: '13',
                    name: '亚信',
                    contact: '周先生',
                    phone: '13888888888'
                }, {
                    id: '14',
                    name: '亚信',
                    contact: '周先生',
                    phone: '13888888888'
                }, {
                    id: '15',
                    name: '亚信',
                    contact: '周先生',
                    phone: '13888888888'
                }, {
                    id: '16',
                    name: '亚信',
                    contact: '周先生',
                    phone: '13888888888'
                }, {
                    id: '17',
                    name: '亚信',
                    contact: '周先生',
                    phone: '13888888888'
                }]

            },
            getAddress: function() {
                this.viewModel.groupPopupVisible = false;
                this.viewModel.addressPopupVisible = true;


                //$.ajax....
                this.model.director.addressList = [{
                    id: '11',
                    name: '张三',
                    address: '南京市鼓楼区1111号',
                    phone: '13888888888'
                }, {
                    id: '12',
                    name: '张三二',
                    address: '南京市鼓楼区1111号',
                    phone: '13888888888'
                }]

            },
            setAddress: function() {
                this.viewModel.addressPopupVisible = false;
                this.viewModel.sccuessPanel = true;


            },
            buy: function() {
                sessionStorage.removeItem('_tempCartPros');
            },
            loadMore: function() {
                var vm = this;
                this.viewModel.loading = true;
                console.info("-----");
                setTimeout(function() {
                    if (vm.model.director.groupList.length > 50) {
                        vm.viewModel.loadStatus = "loaded";
                        return;
                    }
                    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].forEach(function() {
                        vm.model.director.groupList.push({
                            id: vm.model.director.groupList.length + 1,
                            name: '亚信',
                            contact: '周先生',
                            phone: '13888888888'
                        })
                    });
                    vm.viewModel.loading = false;
                }, 3000)
            }

        }
    })
}

J(function() {
    Global.homeViewer.init();
});
