J(function(){
    new Vue({
        el:Global.root+'[vue-id="detail"]',
        data:{
            model:{
                userList:[
                    {
                        name:'林三',
                        depart:'人事部',
                        id:'0'
                    },
                    {
                        name:'李四',
                        depart:'人事部',
                        id:'1'
                    },
                    {
                        name:'王五',
                        depart:'人事部',
                        id:'2'
                    },
                    {
                        name:'王小二',
                        depart:'人事部',
                        id:'3'
                    },
                    {
                        name:'刘娜娜',
                        depart:'行政部',
                        id:'4'
                    },
                    {
                        name:'刘某',
                        depart:'行政部',
                        id:'5'
                    },
                    {
                        name:'夏雨',
                        depart:'人事部',
                        id:'6'
                    }
                ]
            },
            viewModel:{
                selectUser:false,
                selectIndex:0,
                loadStatus:'pause',
                page:1,
                pagesize:10
            }
        },
        methods:{
            addTask:function(){
                toast('发布任务成功！');
                api.closeWin();
            },
            loadmore:function(){
                this.viewModel.loadStatus = 'pause';
                J.get({
                    url:InterFace.user.list,
                    data:{
                        page:vm.viewModel.page,
                        pagesize:vm.viewModel.pagesize
                    }
                }).then(function(data){
                    vm.model.userList = vm.model.userList.concat(data.rows);
                    if( data.rows.length == vm.viewModel.pagesize ){
                        vm.viewModel.page++;
                        vm.viewModel.loadStatus = 'loading';
                    }else{
                        vm.viewModel.loadStatus = 'loaded';
                    }
                })
            }
        },
        computed:{
            selectedUser:function(){
                return this.viewModel.selectIndex == 0 ? '请选择': this.viewModel.selectIndex;
            }
        },
        watch:{
            "viewModel.selectIndex":function(val){
                this.viewModel.selectUser = false;
            }
        }
    })
});