/**
 * Created by xiangpaopao on 16/12/6.
 */

// Vue.use(VueLazyload)

new Vue({
    el: Global.root+"[vue-id='detail']",
    data: {
        order:{},
        user:{},
        info:{},
        isCustomProduct:true

    },


    created: function() {
        var vm = this;
        this.order={
                orderNumber:'346213545',
                status:'0',
                totalPrice:'222.22',
                orderDate:'2016-11-29 13:00:00',
                productList:[
                    {
                        proid:'12134',
                        name:'我晕我晕我晕我晕我晕我晕我晕我晕我晕我晕我晕我晕我晕',
                        img:'http://image4.suning.cn/uimg/b2c/newcatentries/0000000000-000000000143849480_1_200x200.jpg',
                        desc:'规格:集团沃云',
                        price:323.1,
                        num:1
                    },
                    {
                        proid:'12134',
                        name:'我晕我晕我晕我晕我晕我晕我晕我晕我晕我晕我晕我晕我晕',
                        img:'http://image4.suning.cn/uimg/b2c/newcatentries/0000000000-000000000143849480_1_200x200.jpg',
                        desc:'规格:集团沃云',
                        price:323.1,
                        num:1
                    }
                ],
            };

        this.user={
            name : '张三',
            tel : '159******22',
            address : '南京市鼓楼区下挂街道古平岗11111号织梦元33栋亚信科技收到方法'
        }

        this.info = {
            user:'战三',
            phone:'1388888888',
            note:'备注信息备注信息备注信息',
        }



    },

    computed:{

    },
    methods: {


    }
})

