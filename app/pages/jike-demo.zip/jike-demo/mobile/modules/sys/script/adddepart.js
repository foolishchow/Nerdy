J(function(){
    Global.vue = new Vue({
        el:Global.root+'[vue-id="adddepart"]',
        data:{
            depart:{
                status:true
            }
        },
        computed:{
            _status:function(){
                return this.depart.status? '启用':'停用';
            }
        },
        methods:{
            adddepart:function(){
                toast('新增部门成功！');
                api.closeWin();
            }
        }
    });
    // console.info(Global.vue.close())
});