J(function(){
    Global.vue = new Vue({
        el:Global.root+'[vue-id="departlist"]',
        data:{
            list:[
                {
                    name:'人事部',
                    num:10
                } ,
                {
                    name:'人事部',
                    num:10
                } ,
                {
                    name:'人事部',
                    num:10
                } ,
                {
                    name:'人事部',
                    num:10
                }   
            ]
        },
        computed:{
            _status:function(){
                return this.user.status? '在职':'离职';
            }
        },
        methods:{
            adddepart:function(){
                J.location.href="adddepart";
            }
        }
    });

    Jnav.button([{
        text:'新增',
        callBack:'vue.adddepart'
    }]);
    // console.info(Global.vue.close())
});