/**
 * Created by xiangpaopao on 16/12/6.
 */



Global.reviewService = Global.reviewService || {};

Global.reviewService.checkCart = function (data) {
    return J.ajax({
        url: InterFace.cart.checkCart,
        data: data
    })
}

/**
 * 获取购物车商品列表
 * @param cust_id
 */
Global.reviewService.getCartList = function () {
    return J.ajax({
        url: InterFace.cart.cartList,
        data: {
            "cust_id": 1
        }
    })
}

/**
 * 删除购物车中的商品
 * @param data
 */
Global.reviewService.delCart = function (data) {
    return J.ajax({
        url: InterFace.cart.delCart,
        data: data
    })
}

/**
 * 加入购物车
 * @param cust_id
 * @param city_code
 * @param goods_id
 * @param goods_number
 * @param product_id
 */
Global.reviewService.addCart = function (product_id, city_code, goods_id, goods_number) {
    return J.ajax({
        url: InterFace.cart.addCart,
        data: {
            "cust_id": 1,
            "city_code": city_code,
            "goods_id": goods_id,
            "goods_number":goods_number,
            "product_id":product_id
        }
    })
}

/**
 * 更新购物车中商品个数
 * @param cust_id
 * @param city_code
 * @param goods_id
 * @param goods_number
 * @param product_id
 */
Global.reviewService.updCart = function (product_id, city_code, goods_id, goods_number) {
    return J.ajax({
        url: InterFace.cart.updateCart,
        data: {
            "cust_id": 1,
            "city_code": city_code,
            "goods_id": goods_id,
            "goods_number":goods_number,
            "product_id":product_id
        }
    })
}

Global.homeViewer = Global.homeViewer || {};
Global.homeViewer.init = function() {
    new Vue({
        el: '#cartMainEl',
        data: {
            productList: [],
            checkPros: [],
            checkAll: false,
            totalNum: 0,
            totalPrice: 0,
            isEdit: false,

        },

        watch: {
            checkPros: function () {
                this.getInfos();
            },
            productList: {
                handler: function () {
                    this.getInfos();
                },
                deep: true
            },

        },

        created: function () {
            var vm = this;

            Global.reviewService.getCartList().then(function (data) {
                console.log(data);
                vm.productList = data.cart_list;
            }).fail(function () {

            });
        },


        methods: {
            getInfos: function () {
                var vm = this;
                vm.totalPrice = 0;
                vm.totalNum = 0;
                vm.checkPros.forEach(function (item, index) {
                    vm.productList.forEach(function (pro, i) {
                        if (String(pro.product_id) == item) {
                            vm.totalPrice += parseFloat(pro.goods_price) * parseInt(pro.goods_number);
                            vm.totalNum += parseInt(pro.goods_number);
                        }
                    })
                });

                // 循环检查checkPros中的item在productList中是否存在，不存在，则删除
                vm.checkPros.forEach(function (item, index) {
                    var isExist = false;
                    vm.productList.forEach(function (pro, i) {
                       if (String(pro.product_id) == item) {
                           isExist = true;
                       }
                    });

                    if (!isExist) {
                        vm.checkPros.splice(index, 1);
                    }
                });

                // 全选按钮检查
                if (vm.checkPros.length == vm.productList.length && 0 !== vm.checkPros.length) {
                    vm.checkAll = true;
                }
                else {
                    vm.checkAll = false;
                }
            },

            numberChange: function (proid,cityCode,goodsId,num) {
                var vm = this;
                if ($.inArray(proid, vm.checkPros) == -1) {
                    vm.checkPros.push(proid);
                }

                Global.reviewService.updCart(proid,cityCode,goodsId,num).then(function (data) {
                    // console.log(data);
                })
            },

            toggleEdit: function () {
                this.isEdit = !this.isEdit;
            },

            buy: function () {
                var vm = this;
                if (0 == vm.checkPros.length) {
                    vm.$toast(Jutil.message('chooseGoods'));
                    return;
                }

                var param = [];
                vm.checkPros.forEach(function (item, index) {
                    vm.productList.forEach(function (pro, i) {
                        if (String(pro.product_id) == item) {
                            var option = {
                                "cust_id" : pro.cust_id,
                                "product_id": pro.product_id,
                                "city_code": pro.city_code,
                                "act_type": pro.act_type
                            }
                            param.push(option);
                        }
                    })
                });

                Global.reviewService.checkCart(param).then(function (data) {
                    // console.log(data);
                    if (data.result_code == 300005) {
                        vm.$toast(Jutil.message(data.result_code));
                        vm.productList = [];
                    }
                    else {
                        if (data.cart_list != undefined) {
                            // 将productList中不存在的商品移除
                            vm.$toast(Jutil.message(data.result_code));
                            vm.productList.forEach(function(pro, i) {
                                var isExist = false;
                                data.cart_list.forEach(function (p, index) {
                                    if (p.product_id == pro.product_id) {
                                        isExist = true;
                                    }
                                })

                                if (!isExist) {
                                    vm.productList.splice(i, 1);
                                }
                            });
                        }

                        // 将选中的商品传参到订购页面
                        var tempCartPros = [];
                        vm.checkPros.forEach(function (item, index) {
                            vm.productList.forEach(function(pro, i) {
                                if (String(pro.product_id == item)) {
                                    var option = {
                                        "cust_id" : pro.cust_id,
                                        "product_id": pro.product_id,
                                        "city_code": pro.city_code,
                                        "act_type": pro.act_type,

                                        "product_img": pro.product_img,
                                        "goods_price": pro.goods_price,
                                        "goods_number": pro.goods_number,
                                        "product_name": pro.product_name,
                                        "goods_brief": pro.goods_brief
                                    }
                                    tempCartPros.push(option);
                                }
                            });
                        });
                        sessionStorage.setItem('_tempCartPros', JSON.stringify(tempCartPros));
                        J.location.href = "order?from=cart";
                    }
                }).fail(function () {

                });

                // sessionStorage.setItem('_tempCartPros')
                // JSON.parse(sessionStorage.getItem('_tempCartPros'))
                // sessionStorage.removeItem()
            },
            del: function () {
                var vm = this;
                var param = [];
                vm.checkPros.forEach(function (item, index) {
                    vm.productList.forEach(function (pro, i) {
                        if (String(pro.product_id) == item) {
                            vm.productList.splice(i, 1)
                            var option = {
                                "cust_id" : pro.cust_id,
                                "product_id": pro.product_id,
                                "city_code": pro.city_code,
                                "act_type": pro.act_type
                            }
                            param.push(option);
                        }
                    })
                });

                Global.reviewService.delCart(param).then(function (data) {
                    // console.log(data);
                });
            },

            checkAllHander: function () {
                var vm = this;
                if (vm.checkAll && (vm.productList.length != vm.checkPros.length)) {
                    vm.checkPros = [];
                    vm.productList.forEach(function (pro, i) {
                        vm.checkPros.push(pro.product_id)
                    })
                } else if (!vm.checkAll) {
                    vm.checkPros = [];
                }
            }

        }
    })
};

J(function(){
    Global.homeViewer.init();
});

