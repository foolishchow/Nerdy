/**
 * Created by xiangpaopao on 16/12/6.
 */

// Vue.use(VueLazyload)

Global.addressService = Global.addressService || {};

//获取地址列表
Global.addressService.getAddressList = function(cust_id){
    return J.ajax({
                url: InterFace.address.getAddressList,
                data: {
                    "cust_id": cust_id
                }
           });
}


//新增地址
Global.addressService.addAddress = function(obj){
    return  J.ajax({
                url: InterFace.address.addAddress,
                data: {
                    "cust_id": obj.cust_id,
                    "receiver_name" :obj.receiver_name,
                    "mobile_phone" :obj.mobile_phone,
                    "post_addr" :obj.post_addr,
                    "province_code" :obj.province_code,
                    "city_code" :obj.city_code,
                    "district_code" :obj.district_code
                }
           });
}


//删除地址
Global.addressService.delAddress = function(post_id){
    return  J.ajax({
                url: InterFace.address.delAddress,
                data: {
                    "post_id": post_id
                }
           });
}

new Vue({
    el: Global.root+"[vue-id='address']",
    data: {
        model:{
           addressList:[],
           receiver_name:'',
           mobile_phone:'',
           post_addr:'',
           province_code:'',
           city_code:'',
           district_code:'',

        },
        viewModel:{
            popupVisible:false
        },


    },


    created: function() {
        var vm = this;
        Global.addressService.getAddressList(1)
        .then(function(data) {
            vm.model.addressList = data.address_list
        }).fail(function(err) {
            alert(err);
        });

    },

    computed:{

    },
    methods: {
        selectDefault:function (index) {
            this.model.addressList.forEach(function (item,i) {
                    item.isDefault = (i == index);
            })
        },
        delAddress:function (index,post_id) {
            alert(post_id);
            var vm = this;
            this.$messagebox.confirm('确定执行此操作?', '提示').then(function () {

                
                Global.addressService.delAddress(post_id).then(function(data) {
                    if(data.flag=='1'){
                        toast("删除成功");
                        vm.model.addressList.splice(index,1);
                    }
                }).fail(function(err) {
                    alert(err);
                });

                
            },function () {
            });

            //
        },
        editAddress:function (index) {
            this.viewModel.popupVisible = true;

        },
        addAddress:function () {
            this.viewModel.popupVisible = true;
        },
        saveAddress:function () {
            

            var obj ={
                       cust_id:"1",
                       receiver_name:this.model.receiver_name,
                        mobile_phone:this.model.mobile_phone,
                        post_addr:this.model.post_addr,
                        province_code:this.model.province_code,
                        city_code:this.model.city_code,
                        district_code:this.model.district_code
                    };

            Global.addressService.addAddress(obj).then(function(data) {
                    if(data.flag=='1'){
                        toast("添加成功");
                        this.viewModel.popupVisible = false;
                    }
            }).fail(function(err) {
                alert(err);
            });



        }


    }
})

