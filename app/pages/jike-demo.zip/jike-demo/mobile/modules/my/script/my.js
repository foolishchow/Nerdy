/**
 * Created by xiangpaopao on 16/12/6.
 */

// Vue.use(VueLazyload)

new Vue({
    el: Global.root+"[vue-id='my']",
    data: {
        model:{
            user:{
                face:'/modules/my/image/u-face.png',
                name:'某某',
                position:'经理'
            }
        },
        viewModel:{
            detailTabIndex:'1'
        }

    },


    created: function() {
        var vm = this;

    },

    computed:{

    },
    methods: {
        gotoAddress:function () {
            J.location.href = 'address'
        },
        gotoMyTask:function () {
            J.location.href = 'mytask'
        },
        newTask:function(){
            J.location.href = 'newtask'
        },
        goManager:function(){
            J.location.href = 'manager'
        },
        gotoTaskList:function () {
            J.location.href = 'tasklist'
        }
    }
})

