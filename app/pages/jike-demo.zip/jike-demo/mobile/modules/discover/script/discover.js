/**
 * Created by xiangpaopao on 16/12/6.
 */


new Vue({
    el: '#discoverMainEl',
    data: {
        modelList:[],

    },

    created: function() {
        var vm = this;
        // this.formModelList.forEach(function (item,index) {
        //     if(item.type == 'customForm'){
        //         item.model = vm.customForms[item.fullId]
        //     }
        // })
    },

    methods: {


    }
})

