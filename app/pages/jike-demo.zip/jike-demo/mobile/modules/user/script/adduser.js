J(function(){
    Global.vue = new Vue({
        el:Global.root+'[vue-id="adduser"]',
        data:{
            user:{
                status:true
            }
        },
        computed:{
            _status:function(){
                return this.user.status? '在职':'离职';
            }
        },
        methods:{
            adduser:function(){
                toast('新增用户成功')
                api.closeWin();
            }
        }
    });

    // console.info(Global.vue.close())
});