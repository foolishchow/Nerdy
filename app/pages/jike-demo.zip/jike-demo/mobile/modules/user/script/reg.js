/**
 * Created by xiangpaopao on 16/12/6.
 */

// Vue.use(VueLazyload)

new Vue({
    el: Global.root+"[vue-id='reg']",
    data: {
        popupVisible:false,
        selectedJob:'',
        jobs:[]

    },


    created: function() {
        var vm = this;
        this.jobs=[
            {
                'value':'1',
                'name':'IT'
            },
            {
                'value':'2',
                'name':'建筑'
            },
            {
                'value':'3',
                'name':'金融'
            },
            {
                'value':'4',
                'name':'制造'
            },
            {
                'value':'5',
                'name':'服务'
            },
        ]
    },

    computed:{

    },
    methods: {


    }
})

