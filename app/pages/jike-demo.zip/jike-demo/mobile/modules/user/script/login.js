/**
 * Created by xiangpaopao on 16/12/6.
 */

// Vue.use(VueLazyload)

new Vue({
    el: Global.root+"[vue-id='login']",
    data: {
        user:{
            account:'',
            password:''
        }

    },


    created: function() {
        var vm = this;

    },

    computed:{

    },
    methods: {
        login:function () {

        },
        goReg:function () {
            J.location.href = 'reg'
        },
        forget:function () {

        }
    }
})

