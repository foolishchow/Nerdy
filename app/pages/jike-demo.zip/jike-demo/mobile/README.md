apicould开发手册
-----------
>快速导航

- [测试环境部署][install]
- [新建项目][neproject]
- [项目开发结构][develop]
- [自定义sdk文档][doc]
- [acg使用方法][start]
- [打包运行][package]
- [sublime text 相关][sublime]
[neproject]: ./newProject "新建项目"
[develop]: ./develop "项目开发结构"
[doc]: ./JsSdk "自定义sdk文档"
[start]: ./start/acg.html "acg使用方法"
[package]: ./package/ "运行"
[sublime]: ./sublime/ "sublime"
[install]: ./install "install"
最新安装包
--------------
> 安卓

- 二维码
    <img src="./download.png">

- 下载地址
[下载地址][download]

[download]: http://downloadpkg.apicloud.com/app/download?path=http://7xql2i.com1.z0.glb.clouddn.com/896d00ac214abd1ebcb6297e61605bfe_d "下载地址"

> ios

- 二维码
    <img src="./download-ios.png">
- 下载地址
[下载地址][download-ios]

[download-ios]: itms-services://?action=download-manifest&url=https://downloadpkg.apicloud.com:443/zip/60/ed/60ed01ae3e4554ab9966ff3a9953004d.plist "下载地址"
ios蓝牙测试
---------------

- 二维码
    <img src="./buletooth.png">
- 下载地址
[下载地址][download-buletooth]

[download-buletooth]: itms-services://?action=download-manifest&url=https://downloadpkg.apicloud.com:443/zip/2c/c1/2cc1b73cbe042ae4100a235a9ce9ee94.plist "下载地址"

更新
-------------
>2016-09-28

- #### 组件的位置已经开始转移
    大部分的组建已经移动到 sdjk/components下面了,开发修改更加便捷清晰自己亦可以用`acg -c `和 `acg -d` 来生成一个组建目录，生成后重新启动`gulp` 就可以使用自己的全局组建了

- #### 记得查文档
    每个人本地跑起来都会生成[文档服务器][doc],方法调用可以直接查看复制，发现没有注释的方法，自己也可以增加，下次就可以直接复制了

- #### 新增加载失败样式[api][loadfail]
    页面全局加载是吧的时候可以使用，设置回调重新加载
[loadfail]:./JsSdk#jssdk-util-loadfail "加载失败"

- #### acg生成器的使用方法[acg][start]
    不会使用的可以参照该文档

>2016-09-23

- #### ac-generator 更新
```shell
cnpm update ac-generator -g
cnpm install ac-generator
```


>2016-09-23

- #### 1.gulp 会默认提示本机ip
    ```shell
╔═════════════════════════╗
║   your current id is:   ║
║   192.168.0.158         ║
╚═════════════════════════╝
    ```


>2016-09-22

- #### 1. 更新后 重新安装node依赖
    ```shell
    npm install/cnpm install
    gulp
    ```
- #### 2. aiNative.js 现在已经合并了service_config.js
    修改后service_config.js会自动更新到aiNative.js

- #### 3. aiNative.js
    现在由/common/script/lib/sdk/ainative/*.js 以及 service_config.js 动态合并生成
    就是说 修改aiNative.js不会有任何效果,请直接修改对应的ainative/*.js下的文件

- #### 4. windows 系统现在可以打包了 各系统下统一命令为：
    ```shell
    npm run pre  //打包pre
    npm run prd  //打包prd
    npm run clear //清除打包目录
    ```
- #### 5.gulp启动后  会开启文档服务
    在`localhost:9400`即可以看到文档，aiNative的注释也会实时生成文档

