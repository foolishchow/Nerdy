(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(require('vue')) :
    typeof define === 'function' && define.amd ? define(['vue'], factory) :
    (global.MINT = factory(global.Vue));
}(this, (function (Vue$1) { 'use strict';

Vue$1 = 'default' in Vue$1 ? Vue$1['default'] : Vue$1;

/**
 * mt-header
 * @module components/header
 * @desc 顶部导航
 * @param {boolean} [fixed=false] - 固定顶部
 * @param {string} [title] - 标题
 * @param {slot} [left] - 显示在左侧区域
 * @param {slot} [right] - 显示在右侧区域
 *
 * @example
 * <mt-header title="我是标题" fixed>
 *   <mt-button slot="left" icon="back" @click="handleBack">返回</mt-button>
 *   <mt-button slot="right" icon="more"></mt-button>
 * </mt-header>
 */
var Header$1 = { template: "<header class=\"mint-header\" :class=\"{ 'is-fixed': fixed }\"><div class=\"mint-header-button is-left\"><slot name=\"left\"></slot></div><h1 class=\"mint-header-title\" v-text=\"title\"></h1><div class=\"mint-header-button is-right\"><slot name=\"right\"></slot></div></header>",
  name: 'ai-header',

  props: {
    fixed: Boolean,
    title: String
  }
};

/**
 * mt-header
 * @module components/button
 * @desc 按钮
 * @param {string} [type=default] - 显示类型，接受 default, primary, danger
 * @param {boolean} [disabled=false] - 禁用
 * @param {boolean} [plain=false] - 幽灵按钮
 * @param {string} [size=normal] - 尺寸，接受 normal, small, large
 * @param {string} [native-type] - 原生 type 属性
 * @param {string} [icon] - 图标，提供 more, back，或者自定义的图标（传入不带前缀的图标类名，最后拼接成 .mintui-xxx）
 * @param {slot} - 显示文本
 * @param {slot} [icon] 显示图标
 *
 * @example
 * <mt-button size="large" icon="back" type="primary">按钮</mt-button>
 */
var Button$1 = { template: "<button :type=\"nativeType\" class=\"mint-button\" :class=\"['mint-button--' + type, 'mint-button--' + size, { 'is-disabled': disabled, 'is-plain': plain }]\" @click=\"handleClick\" :disabled=\"disabled\"><span class=\"mint-button-icon\" v-if=\"icon || $slots.icon\"><slot name=\"icon\"><i v-if=\"icon\" class=\"aicon\" :class=\"'aicon-' + icon\"></i></slot></span><label class=\"mint-button-text\"><slot></slot></label></button>",
  name: 'ai-button',

  methods: {
    handleClick: function handleClick(evt) {
      this.$emit('click', evt);
    }
  },

  props: {
    icon: String,
    disabled: Boolean,
    nativeType: String,
    plain: Boolean,
    type: {
      type: String,
      default: 'default',
      validator: function validator(value) {
        return [
          'default',
          'danger',
          'primary'
        ].indexOf(value) > -1;
      }
    },
    size: {
      type: String,
      default: 'normal',
      validator: function validator(value) {
        return [
          'small',
          'normal',
          'large'
        ].indexOf(value) > -1;
      }
    }
  }
};

/**
 * mt-cell
 * @module components/cell
 * @desc 单元格
 * @param {string|Object} [to] - 跳转链接，使用 vue-router 的情况下 to 会传递给 router.push，否则作为 a 标签的 href 属性处理
 * @param {Function} [click]  点击事件
 * @param {string} [icon] - 图标，提供 more, back，或者自定义的图标（传入不带前缀的图标类名，最后拼接成 .mintui-xxx）
 * @param {string} [icon-right] - 图标，提供 more, back，或者自定义的图标（传入不带前缀的图标类名，最后拼接成 .mintui-xxx）
 * @param {string} [title] - 标题
 * @param {string} [label] - 备注信息
 * @param {boolean} [is-link=false] - 可点击的链接
 * @param {boolean} [border] - 上描边
 * @param {boolean} [borderBottom] - 上描边
 * @param {string} [value] - 右侧显示文字
 * @param {slot} - 同 value, 会覆盖 value 属性
 * @param {slot} [title] - 同 title, 会覆盖 title 属性
 * @param {slot} [icon] - 同 icon, 会覆盖 icon 属性，例如可以传入图片
 * @param {string} size - 大小
 * @example
 * <mt-cell title="标题文字" icon="back" is-link value="描述文字"></mt-cell>
 * <mt-cell title="标题文字" icon="back">
 *   <div slot="value">描述文字啊哈</div>
 * </mt-cell>
 */
var XCell$1 = { template: "<a class=\"mint-cell\" :class=\"{'is-border':border,'is-border-bottom':borderBottom}\" :href=\"href\"><span class=\"mint-cell-mask\" v-if=\"isLink\"></span><div class=\"mint-cell-left\"><slot name=\"left\"></slot></div><div class=\"mint-cell-wrapper\" :class=\"'is-'+size\"><div class=\"mint-cell-title\"><slot name=\"icon\"><i v-if=\"icon\" class=\"aicon\" :class=\"'aicon-' + icon\"></i></slot><slot name=\"title\"><span class=\"mint-cell-text\" v-text=\"title\"></span> <span v-if=\"label\" class=\"mint-cell-label\" v-text=\"label\"></span></slot></div><div class=\"mint-cell-value\" :class=\"{ 'is-link' : isLink }\"><slot><span v-text=\"value\"></span></slot></div><slot name=\"iconRight\"><i v-if=\"iconRight\" class=\"aicon\" :class=\"'aicon-' + iconRight\"></i></slot></div><div class=\"mint-cell-right\"><slot name=\"right\"></slot></div><i v-if=\"isLink\" class=\"mint-cell-allow-right\"></i></a>",
  name: 'ai-cell',

  props: {
    to: [String, Object],
    icon: String,
    iconRight:String,
    title: String,
    label: String,
    isLink: Boolean,
    border:Boolean,
    borderBottom:Boolean,
    value: {},
    click:[Function],
    size:{
      type:String,
      default:''
    }
  },

  computed: {
    href: function href() {
      var this$1 = this;

      if (this.to && !this.added && this.$router) {
        var resolved = this.$router.match(this.to);
        if (!resolved.matched.length) { return this.to; }

        this.$nextTick(function () {
          this$1.added = true;
          this$1.$el.addEventListener('click', this$1.handleClick);
        });
        return resolved.path;
      }
      return this.to;
    }
  },

  methods: {
    handleClick: function handleClick($event) {
      $event.preventDefault();
      this.$router.push(this.href);
    }
  }
};

var bindEvent = (function() {
  if(document.addEventListener) {
    return function(element, event, handler) {
      if (element && event && handler) {
        element.addEventListener(event, handler, false);
      }
    };
  } else {
    return function(element, event, handler) {
      if (element && event && handler) {
        element.attachEvent('on' + event, handler);
      }
    };
  }
})();

var unbindEvent = (function() {
  if(document.removeEventListener) {
    return function(element, event, handler) {
      if (element && event) {
        element.removeEventListener(event, handler, false);
      }
    };
  } else {
    return function(element, event, handler) {
      if (element && event) {
        element.detachEvent('on' + event, handler);
      }
    };
  }
})();

var bindOnce = function(el, event, fn) {
  var listener = function() {
    if (fn) {
      fn.apply(this, arguments);
    }
    unbindEvent(el, event, listener);
  };
  bindEvent(el, event, listener);
};

var event = {
  on: bindEvent,
  off: unbindEvent,
  once: bindOnce
};

var once = event.once;

/**
 * v-clickoutside
 * @desc 点击元素外面才会触发的事件
 * @example
 * ```vue
 * <div v-element-clickoutside="handleClose">
 * ```
 */
var clickoutsideContext = '@@clickoutsideContext';

var Clickoutside = {
  bind: function bind(el, binding, vnode) {
    var documentHandler = function(e) {
      if (vnode.context && !el.contains(e.target)) {
        vnode.context[el[clickoutsideContext].methodName]();
      }
    };
    el[clickoutsideContext] = {
      documentHandler: documentHandler,
      methodName: binding.expression,
      arg: binding.arg || 'click'
    };
    document.addEventListener(el[clickoutsideContext].arg, documentHandler);
  },

  update: function update(el, binding) {
    el[clickoutsideContext].methodName = binding.expression;
  },

  unbind: function unbind(el) {
    document.removeEventListener(
      el[clickoutsideContext].arg,
      el[clickoutsideContext].documentHandler);
  },

  install: function install(Vue) {
    Vue.directive('clickoutside', {
      bind: this.bind,
      unbind: this.unbind
    });
  }
};

/**
 * mt-cell-swipe
 * @desc 类似 iOS 滑动 Cell 的效果
 * @module components/cell-swipe
 *
 * @example
 * <mt-cell-swipe
 *   :left=[
 *     {
 *       content: 'text',
 *       style: {color: 'white', backgroundColor: 'red'},
 *       handler(e) => console.log(123)
 *     }
 *   ]
 *   :right=[{ content: 'allowed HTML' }]>
 *   swipe me
 * </mt-cell-swipe>
 */
var CellSwipe$1 = { template: "<x-cell v-clickoutside:touchstart=\"swipeMove\" @click.native=\"swipeMove()\" @touchstart.native=\"startDrag\" @touchmove.native=\"onDrag\" @touchend.native=\"endDrag\" class=\"mint-cell-swipe\" :title=\"title\" :icon=\"icon\" :label=\"label\" :to=\"to\" :is-link=\"isLink\" ref=\"cell\" :value=\"value\"><div slot=\"right\" class=\"mint-cell-swipe-buttongroup\" ref=\"right\"><a class=\"mint-cell-swipe-button\" v-for=\"btn in right\" :style=\"btn.style\" @click.stop=\"btn.handler && btn.handler(), swipeMove()\" v-html=\"btn.content\"></a></div><div slot=\"left\" class=\"mint-cell-swipe-buttongroup\" ref=\"left\"><a class=\"mint-cell-swipe-button\" v-for=\"btn in left\" :style=\"btn.style\" @click.stop=\"btn.handler && btn.handler(), swipeMove()\" v-html=\"btn.content\"></a></div><slot></slot><span v-if=\"$slots.title\" slot=\"title\"><slot name=\"title\"></slot></span><span v-if=\"$slots.icon\" slot=\"icon\"><slot name=\"icon\"></slot></span></x-cell>",
  name: 'ai-cell-swipe',

  components: { XCell: XCell$1 },

  directives: { Clickoutside: Clickoutside },

  props: {
    to: String,
    left: Array,
    right: Array,
    icon: String,
    title: String,
    label: String,
    isLink: Boolean,
    value: {}
  },

  data: function data() {
    return {
      start: { x: 0, y: 0 }
    };
  },

  mounted: function mounted() {
    this.wrap = this.$refs.cell.$el.querySelector('.mint-cell-wrapper');
    this.leftElm = this.$refs.left;
    this.rightElm = this.$refs.right;
    this.leftWrapElm = this.leftElm.parentNode;
    this.rightWrapElm = this.rightElm.parentNode;
    this.leftWidth = this.leftElm.getBoundingClientRect().width;
    this.rightWidth = this.rightElm.getBoundingClientRect().width;

    this.leftDefaultTransform = this.translate3d(-this.leftWidth - 1);
    this.rightDefaultTransform = this.translate3d(this.rightWidth);

    this.rightWrapElm.style.webkitTransform = this.rightDefaultTransform;
    this.leftWrapElm.style.webkitTransform = this.leftDefaultTransform;
  },

  methods: {
    translate3d: function translate3d(offset) {
      return ("translate3d(" + offset + "px, 0, 0)");
    },

    swipeMove: function swipeMove(offset) {
      if ( offset === void 0 ) offset = 0;

      this.wrap.style.webkitTransform = this.translate3d(offset);
      this.rightWrapElm.style.webkitTransform = this.translate3d(this.rightWidth + offset);
      this.leftWrapElm.style.webkitTransform = this.translate3d(-this.leftWidth + offset);
      this.swiping = true;
    },

    swipeLeaveTransition: function swipeLeaveTransition(direction) {
      var this$1 = this;

      setTimeout(function () {
        this$1.swipeLeave = true;

        // left
        if (direction > 0 && -this$1.offsetLeft > this$1.rightWidth * 0.4) {
          this$1.swipeMove(-this$1.rightWidth);
          this$1.swiping = false;
          this$1.opened = true;
          return;
        // right
        } else if (direction < 0 && this$1.offsetLeft > this$1.leftWidth * 0.4) {
          this$1.swipeMove(this$1.leftWidth);
          this$1.swiping = false;
          this$1.opened = true;
          return;
        }

        this$1.swipeMove(0);
        once(this$1.wrap, 'webkitTransitionEnd', function (_) {
          this$1.wrap.style.webkitTransform = '';
          this$1.rightWrapElm.style.webkitTransform = this$1.rightDefaultTransform;
          this$1.leftWrapElm.style.webkitTransform = this$1.leftDefaultTransform;
          this$1.swipeLeave = false;
          this$1.swiping = false;
        });
      }, 0);
    },

    startDrag: function startDrag(evt) {
      evt = evt.changedTouches ? evt.changedTouches[0] : evt;
      this.dragging = true;
      this.start.x = evt.pageX;
      this.start.y = evt.pageY;
    },

    onDrag: function onDrag(evt) {
      if (this.opened) {
        !this.swiping && this.swipeMove(0);
        this.opened = false;
        return;
      }
      if (!this.dragging) { return; }
      var swiping;
      var e = evt.changedTouches ? evt.changedTouches[0] : evt;
      var offsetTop = e.pageY - this.start.y;
      var offsetLeft = this.offsetLeft = e.pageX - this.start.x;

      if ((offsetLeft < 0 && -offsetLeft > this.rightWidth) ||
        (offsetLeft > 0 && offsetLeft > this.leftWidth) ||
        (offsetLeft > 0 && !this.leftWidth) ||
        (offsetLeft < 0 && !this.rightWidth)) {
        return;
      }

      var y = Math.abs(offsetTop);
      var x = Math.abs(offsetLeft);

      swiping = !(x < 5 || (x >= 5 && y >= x * 1.73));
      if (!swiping) { return; }
      evt.preventDefault();

      this.swipeMove(offsetLeft);
    },

    endDrag: function endDrag() {
      if (!this.swiping) { return; }
      this.swipeLeaveTransition(this.offsetLeft > 0 ? -1 : 1);
    }
  }
};

// export default require('./src/cell-swipe.vue');

var cellSpacing = { template: "<div class=\"mint-cell-spacing\" :class=\"'is-' + theme\"></div>",
    name:'ai-cell-spacing',
    props: {
        size:String,
        color:String,
        theme:String
    }
};

/**
 * mt-field
 * @desc 编辑器，依赖 cell
 * @module components/field
 *
 * @param {string} [type=text] - field 类型，接受 text, textarea 等
 * @param {string} [label] - 标签
 * @param {string} [rows] - textarea 的 rows
 * @param {string} [placeholder] - placeholder
 * @param {string} [disabled] - disabled
 * @param {string} [readonly] - readonly
 * @param {string} [state] - 表单校验状态样式，接受 error, warning, success
 *
 * @example
 * <mt-field v-model="value" label="用户名"></mt-field>
 * <mt-field v-model="value" label="密码" placeholder="请输入密码"></mt-field>
 * <mt-field v-model="value" label="自我介绍" placeholder="自我介绍" type="textarea" rows="4"></mt-field>
 * <mt-field v-model="value" label="邮箱" placeholder="成功状态" state="success"></mt-field>
 */
var Field$1 = { template: "<x-cell class=\"mint-field\" :title=\"label\" v-clickoutside=\"doCloseActive\" :class=\"[{ 'is-textarea': type === 'textarea', 'is-nolabel': !label }]\"><textarea @change=\"$emit('change', currentValue)\" ref=\"textarea\" class=\"mint-field-core\" :placeholder=\"placeholder\" v-if=\"type === 'textarea'\" :rows=\"rows\" :disabled=\"disabled\" :readonly=\"readonly\" v-model=\"currentValue\">\n  </textarea><input @change=\"$emit('change', currentValue)\" ref=\"input\" class=\"mint-field-core\" :placeholder=\"placeholder\" :number=\"type === 'number'\" v-else :type=\"type\" @focus=\"active = true\" :disabled=\"disabled\" :readonly=\"readonly\" :value=\"currentValue\" @input=\"handleInput\"><div @click=\"handleClear\" class=\"mint-field-clear\" v-if=\"!disableClear\" v-show=\"currentValue && type !== 'textarea' && active\"><i class=\"aicon aicon-field-error\"></i></div><span v-if=\"arrow\" class=\"arrow\"><i class=\"aicon aicon-xiangyoujiantou\"></i> </span><span class=\"mint-field-state\" v-if=\"state\" :class=\"['is-' + state]\"><i class=\"aicon\" :class=\"['aicon-field-' + state]\"></i></span><div class=\"mint-field-other\"><slot></slot></div></x-cell>",
  name: 'ai-field',

  data: function data() {
    return {
      active: false,
      currentValue: this.value
    };
  },

  directives: {
    Clickoutside: Clickoutside
  },

  props: {
    type: {
      type: String,
      default: 'text'
    },
    rows: String,
    label: String,
    placeholder: String,
    readonly: Boolean,
    disabled: Boolean,
    arrow: Boolean,
    disableClear: Boolean,
    state: {
      type: String,
      default: 'default'
    },
    value: {},
    attr: Object
  },

  components: { XCell: XCell$1 },

  methods: {
    doCloseActive: function doCloseActive() {
      this.active = false;
    },

    handleInput: function handleInput(evt) {
      this.currentValue = evt.target.value;
    },

    handleClear: function handleClear() {
      if (this.disabled || this.readonly) { return; }
      this.currentValue = '';
    }
  },

  watch: {
    value: function value(val) {
      this.currentValue = val;
    },

    currentValue: function currentValue(val) {
      this.$emit('input', val);
    },

    attr: {
      immediate: true,
      handler: function handler(attrs) {
        var this$1 = this;

        this.$nextTick(function () {
          var target = [this$1.$refs.input, this$1.$refs.textarea];
          target.forEach(function (el) {
            if (!el || !attrs) { return; }
            Object.keys(attrs).map(function (name) { return el.setAttribute(name, attrs[name]); });
          });
        });
      }
    }
  }
};

/**
 * mt-badge
 * @module components/badge
 * @desc 徽章
 * @param {string} [type=primary] 组件样式，可选 primary, error, success, warning
 * @param {string} [color] - 传入颜色值
 * @param {string} [size=normal] - 尺寸，接受 normal, small, large
 *
 * @example
 * <mt-badge color="error">错误</mt-badge>
 * <mt-badge color="#333">30</mt-badge>
 */
var Badge$1 = { template: "<span class=\"mint-badge\" :style=\"{ backgroundColor: color }\" :class=\"['is-' + type, 'is-size-' + size]\"><slot></slot></span>",
  name: 'ai-badge',

  props: {
    color: String,
    type: {
      type: String,
      default: 'primary'
    },
    size: {
      type: String,
      default: 'normal'
    }
  }
};

/**
 * mt-switch
 * @module components/switch
 * @desc 切换按钮
 * @param {boolean} [value] - 绑定值，支持双向绑定
 * @param {slot} - 显示内容
 *
 * @example
 * <mt-switch v-model="value"></mt-switch>
 */
var TabContainer = { template: "<label class=\"mint-switch\"><input class=\"mint-switch-input\" @change=\"$emit('change', currentValue)\" type=\"checkbox\" v-model=\"currentValue\"> <span class=\"mint-switch-core\"></span><div class=\"mint-switch-label\"><slot></slot></div></label>",
  name: 'ai-switch',

  props: {
    value: Boolean
  },

  data: function data() {
    return {
      currentValue: this.value
    };
  },

  watch: {
    value: function value(val) {
      this.currentValue = val;
    },

    currentValue: function currentValue(val) {
      this.$emit('input', val);
    }
  }
};

var common = { template: "",
  computed: {
    spinnerColor: function spinnerColor() {
      return this.color || this.$parent.color || '#ccc';
    },

    spinnerSize: function spinnerSize() {
      return (this.size || this.$parent.size || 1.12) +'rem';
    }
  },

  props: {
    size: Number,
    color: String
  }
};

var SpinnerSnake = { template: "<div class=\"mint-spinner-snake\" :style=\"{\n  'border-top-color': spinnerColor,\n  'border-left-color': spinnerColor,\n  'border-bottom-color': spinnerColor,\n  'height': spinnerSize,\n  'width': spinnerSize\n  }\"></div>",
  name: 'snake',

  mixins: [common]
};

var SpinnerDoubleBounce = { template: "<div class=\"mint-spinner-double-bounce\" :style=\"{\n    width: spinnerSize,\n    height: spinnerSize\n  }\"><div class=\"mint-spinner-double-bounce-bounce1\" :style=\"{ backgroundColor: spinnerColor }\"></div><div class=\"mint-spinner-double-bounce-bounce2\" :style=\"{ backgroundColor: spinnerColor }\"></div></div>",
  name: 'double-bounce',

  mixins: [common]
};

var SpinnerTripleBounce = { template: "<div class=\"mint-spinner-triple-bounce\"><div class=\"mint-spinner-triple-bounce-bounce1\" :style=\"bounceStyle\"></div><div class=\"mint-spinner-triple-bounce-bounce2\" :style=\"bounceStyle\"></div><div class=\"mint-spinner-triple-bounce-bounce3\" :style=\"bounceStyle\"></div></div>",
  name: 'triple-bounce',

  mixins: [common],

  computed: {
    spinnerSize: function spinnerSize() {
      return ((this.size || this.$parent.size || 1.12) / 3) + 'rem';
    },

    bounceStyle: function bounceStyle() {
      return {
        width: this.spinnerSize,
        height: this.spinnerSize,
        backgroundColor: this.spinnerColor
      };
    }
  }
};

var spinner$1 = { template: "<div :class=\"['mint-spinner-fading-circle circle-color-' + _uid]\" :style=\"{\n    width: spinnerSize,\n    height: spinnerSize\n  }\"><div v-for=\"n in 12\" :class=\"['is-circle' + (n + 1)]\" class=\"mint-spinner-fading-circle-circle\"></div></div>",
  name: 'fading-circle',

  mixins: [common],

  created: function created() {
    this.styleNode = document.createElement('style');
    var css = ".circle-color-" + (this._uid) + " > div::before { background-color: " + (this.spinnerColor) + "; }";

    this.styleNode.type = 'text/css';
    this.styleNode.rel = 'stylesheet';
    this.styleNode.title = 'fading circle style';
    document.getElementsByTagName('head')[0].appendChild(this.styleNode);
    this.styleNode.appendChild(document.createTextNode(css));
  },

  destroyed: function destroyed() {
    if (this.styleNode) {
      this.styleNode.parentNode.removeChild(this.styleNode);
    }
  }
};

var SPINNERS = [
  'snake',
  'double-bounce',
  'triple-bounce',
  'fading-circle'
];
var parseSpinner = function(index) {
  if ({}.toString.call(index) === '[object Number]') {
    if (SPINNERS.length <= index) {
      console.warn(("'" + index + "' spinner not found, use the default spinner."));
      index = 0;
    }
    return SPINNERS[index];
  }

  if (SPINNERS.indexOf(index) === -1) {
    console.warn(("'" + index + "' spinner not found, use the default spinner."));
    index = SPINNERS[0];
  }
  return index;
};

/**
 * mt-spinner
 * @module components/spinner
 * @desc 加载动画
 * @param {(string|number)} [type=snake] - 显示类型，传入类型名或者类型 id，可选 `snake`, `dobule-bounce`, `triple-bounce`, `fading-circle`
 * @param {number} size - 尺寸
 * @param {string} color - 颜色
 *
 * @example
 * <mt-spinner type="snake"></mt-spinner>
 *
 * <!-- double-bounce -->
 * <mt-spinner :type="1"></mt-spinner>
 *
 * <!-- default snake -->
 * <mt-spinner :size="30" color="#999"></mt-spinner>
 */
var Spinner$1 = { template: "<span><component :is=\"spinner\"></component></span>",
  name: 'ai-spinner',

  computed: {
    spinner: function spinner() {
      return ("spinner-" + (parseSpinner(this.type)));
    }
  },

  components: {
    SpinnerSnake: SpinnerSnake,
    SpinnerDoubleBounce: SpinnerDoubleBounce,
    SpinnerTripleBounce: SpinnerTripleBounce,
    SpinnerFadingCircle: spinner$1
  },

  props: {
    type: {
      default: 0
    },
    size: {
      type: Number,
      default: 1.12
    },
    color: {
      type: String,
      default: '#ccc'
    }
  }
};

Spinner$1.install = function(Vue) {
  Vue.component(Spinner$1.name, Spinner$1);
};

/**
 * mt-tab-item
 * @module components/tab-item
 * @desc 搭配 tabbar 或 navbar 使用
 * @param {*} id - 选中后的返回值，任意类型
 * @param {slot} [icon] - icon 图标
 * @param {slot} - 文字
 *
 * @example
 * <mt-tab-item>
 *   <img slot="icon" src="http://placehold.it/100x100">
 *   订单
 * </mt-tab-item>
 */
var TabItem$1 = { template: "<a class=\"mint-tab-item\" @click=\"$parent.$emit('input', id)\" :class=\"{ 'is-selected': $parent.value === id }\"><div class=\"mint-tab-item-icon\"><slot name=\"icon\"></slot></div><div class=\"mint-tab-item-label\"><slot></slot></div></a>",
  name: 'ai-tab-item',

  props: ['id']
  
};

/**
 * mt-tab-container-item
 * @desc 搭配 tab-container 使用
 * @module components/tab-container-item
 *
 * @param {number|string} [id] - 该项的 id
 *
 * @example
 * <mt-tab-container v-model="selected">
 *   <mt-tab-container-item id="1"> 内容A </mt-tab-container-item>
 *   <mt-tab-container-item id="2"> 内容B </mt-tab-container-item>
 *   <mt-tab-container-item id="3"> 内容C </mt-tab-container-item>
 * </mt-tab-container>
 */
var TabContainerItem$1 = { template: "<div v-show=\"$parent.swiping || id === $parent.currentActive\" class=\"mint-tab-container-item\"><slot></slot></div>",
  name: 'ai-tab-container-item',

  props: ['id']
};

var index = function (arr, predicate, ctx) {
	if (typeof Array.prototype.findIndex === 'function') {
		return arr.findIndex(predicate, ctx);
	}

	if (typeof predicate !== 'function') {
		throw new TypeError('predicate must be a function');
	}

	var list = Object(arr);
	var len = list.length;

	if (len === 0) {
		return -1;
	}

	for (var i = 0; i < len; i++) {
		if (predicate.call(ctx, list[i], i, list)) {
			return i;
		}
	}

	return -1;
};

/**
 * mt-tab-container
 * @desc 面板，搭配 tab-container-item 使用
 * @module components/tab-container
 *
 * @param {number|string} [value] - 当前激活的 tabId
 *
 * @example
 * <mt-tab-container v-model="selected">
 *   <mt-tab-container-item id="1"> 内容A </mt-tab-container-item>
 *   <mt-tab-container-item id="2"> 内容B </mt-tab-container-item>
 *   <mt-tab-container-item id="3"> 内容C </mt-tab-container-item>
 * </mt-tab-container>
 */
var TabContainer$2 = { template: "<div @touchstart=\"startDrag\" @mousedown=\"startDrag\" @touchmove=\"onDrag\" @mousemove=\"onDrag\" @mouseleave=\"endDrag\" @touchend=\"endDrag\" class=\"mint-tab-container\"><div ref=\"wrap\" class=\"mint-tab-container-wrap\"><slot></slot></div></div>",
  name: 'ai-tab-container',

  props: {
    value: {},
    swipeable: Boolean
  },

  data: function data() {
    return {
      start: { x: 0, y: 0 },
      swiping: false,
      activeItems: [],
      pageWidth: 0,
      currentActive: this.value
    };
  },

  watch: {
    value: function value(val) {
      this.currentActive = val;
    },

    currentActive: function currentActive(val, oldValue) {
      this.$emit('input', val);
      if (!this.swipeable) { return; }
      var lastIndex = index(this.$children,
        function (item) { return item.id === oldValue; });
      this.swipeLeaveTransition(lastIndex);
    }
  },

  mounted: function mounted() {
    if (!this.swipeable) { return; }

    this.wrap = this.$refs.wrap;
    this.pageWidth = this.wrap.clientWidth;
    this.limitWidth = this.pageWidth / 4;
  },

  methods: {
    swipeLeaveTransition: function swipeLeaveTransition(lastIndex) {
      var this$1 = this;
      if ( lastIndex === void 0 ) lastIndex = 0;

      if (typeof this.index !== 'number') {
        this.index = index(this.$children,
          function (item) { return item.id === this$1.currentActive; });
        this.swipeMove(-lastIndex * this.pageWidth);
      }

      setTimeout(function () {
        this$1.wrap.classList.add('swipe-transition');
        this$1.swipeMove(-this$1.index * this$1.pageWidth);

        once(this$1.wrap, 'webkitTransitionEnd', function (_) {
          this$1.wrap.classList.remove('swipe-transition');
          this$1.wrap.style.webkitTransform = '';
          this$1.swiping = false;
          this$1.index = null;
        });
      }, 0);
    },

    swipeMove: function swipeMove(offset) {
      this.wrap.style.webkitTransform = "translate3d(" + offset + "px, 0, 0)";
      this.swiping = true;
    },

    startDrag: function startDrag(evt) {
      evt = evt.changedTouches ? evt.changedTouches[0] : evt;
      this.dragging = true;
      this.start.x = evt.pageX;
      this.start.y = evt.pageY;
    },

    onDrag: function onDrag(evt) {
      var this$1 = this;

      if (!this.dragging) { return; }
      var swiping;
      var e = evt.changedTouches ? evt.changedTouches[0] : evt;
      var offsetTop = e.pageY - this.start.y;
      var offsetLeft = e.pageX - this.start.x;
      var y = Math.abs(offsetTop);
      var x = Math.abs(offsetLeft);

      swiping = !(x < 5 || (x >= 5 && y >= x * 1.73));
      if (!swiping) { return; }
      evt.preventDefault();

      var len = this.$children.length - 1;
      var index$$1 = index(this.$children,
        function (item) { return item.id === this$1.currentActive; });
      var currentPageOffset = index$$1 * this.pageWidth;
      var offset = offsetLeft - currentPageOffset;
      var absOffset = Math.abs(offset);

      if (absOffset > len * this.pageWidth ||
          (offset > 0 && offset < this.pageWidth)) {
        this.swiping = false;
        return;
      }

      this.offsetLeft = offsetLeft;
      this.index = index$$1;
      this.swipeMove(offset);
    },

    endDrag: function endDrag() {
      if (!this.swiping) { return; }

      var direction = this.offsetLeft > 0 ? -1 : 1;
      var isChange = Math.abs(this.offsetLeft) > this.limitWidth;

      if (isChange) {
        this.index += direction;
        var child = this.$children[this.index];
        if (child) {
          this.currentActive = child.id;
          return;
        }
      }

      this.swipeLeaveTransition();
    }
  }
};

/**
 * mt-navbar
 * @module components/navbar
 * @desc 顶部 tab，依赖 tab-item
 *
 * @param {boolean} [fixed=false] - 固定底部
 * @param {*} selected - 返回 item component 传入的 value
 *
 * @example
 * <mt-navbar :selected.sync="selected">
 *   <mt-tab-item value="订单">
 *     <span slot="label">订单</span>
 *   </mt-tab-item>
 * </mt-navbar>
 *
 * <mt-navbar :selected.sync="selected" fixed>
 *   <mt-tab-item :value="['传入数组', '也是可以的']">
 *     <span slot="label">订单</span>
 *   </mt-tab-item>
 * </mt-navbar>
 *
 */
var Navbar$1 = { template: "<div class=\"mint-navbar\" :class=\"{'is-fixed': fixed,'is-top':padding}\"><slot></slot></div>",
  name: 'ai-navbar',

  props: {
    fixed: Boolean,
    value: {},
    padding:Boolean
  }
};

/**
 * mt-tabbar
 * @module components/tabbar
 * @desc 底部 tab，依赖 tab-item
 * @param {boolean} [fixed=false] - 固定底部
 * @param {*} value - 返回 item component 传入的 id
 *
 * @example
 * <mt-tabbar v-model="selected">
 *   <mt-tab-item id="订单">
 *     <img slot="icon" src="http://placehold.it/100x100">
 *     <span slot="label">订单</span>
 *   </mt-tab-item>
 * </mt-tabbar>
 *
 * <mt-tabbar v-model="selected" fixed>
 *   <mt-tab-item :id="['传入数组', '也是可以的']">
 *     <img slot="icon" src="http://placehold.it/100x100">
 *     <span slot="label">订单</span>
 *   </mt-tab-item>
 * </mt-tabbar>
 */
var Tabbar$1 = { template: "<div class=\"mint-tabbar\" :class=\"{ 'is-fixed': fixed }\"><slot></slot></div>",
  name: 'ai-tabbar',

  props: {
    fixed: Boolean,
    value: {}
  }
};

/**
 * mt-search
 * @module components/search
 * @desc 搜索框
 * @param {string} value - 绑定值
 * @param {string} [cancel-text=取消] - 取消按钮文字
 * @param {string} [placeholder=取消] - 搜索框占位内容
 * @param {boolean} [autofocus=false] - 自动 focus
 * @param {boolean} [show=false] - 始终显示列表
 * @param {string[]} [result] - 结果列表
 * @param {slot} 结果列表
 *
 * @example
 * <mt-search :value.sync="value" :result.sync="result"></mt-search>
 * <mt-search :value.sync="value">
 *   <mt-cell v-for="item in result" :title="item"></mt-cell>
 * </mt-search>
 */
var Search$1 = { template: "<div class=\"mint-search\"><div class=\"mint-searchbar\"><div class=\"mint-searchbar-inner\"><i class=\"aicon aicon-search\" v-show=\"visible\"></i> <input ref=\"input\" @click=\"visible = true\" type=\"search\" v-model=\"currentValue\" :placeholder=\"visible ? placeholder : ''\" class=\"mint-searchbar-core\"></div><a class=\"mint-searchbar-cancel\" @click=\"visible = false, currentValue = ''\" v-show=\"visible\" v-text=\"cancelText\"></a><label @click=\"visible = true, $refs.input.focus()\" class=\"mint-searchbar-placeholder\" v-show=\"!visible\"><i class=\"aicon aicon-search\"></i> <span class=\"mint-searchbar-text\" v-text=\"placeholder\"></span></label></div><div class=\"mint-search-list\" v-show=\"show || currentValue\"><div class=\"mint-search-list-warp\"><slot><x-cell v-for=\"(item, index) in result\" :key=\"index\" :title=\"item\"></x-cell></slot></div></div></div>",
  name: 'ai-search',

  data: function data() {
    return {
      visible: false,
      currentValue: this.value
    };
  },

  components: { XCell: XCell$1 },

  watch: {
    currentValue: function currentValue(val) {
      this.$emit('input', val);
    },

    value: function value(val) {
      this.currentValue = val;
    }
  },

  props: {
    value: String,
    autofocus: Boolean,
    show: Boolean,
    cancelText: {
      default: '取消'
    },
    placeholder: {
      default: '搜索'
    },
    result: Array
  },

  mounted: function mounted() {
    this.autofocus && this.$refs.input.focus();
  }
};

var CheckboxGroup$1 = { template: "<div class=\"ai-checkbox-group\"><slot></slot></div>",
  name: 'ai-checkbox-group',

  props: {
    value: {}
  },

  watch: {
    value: function value(value$1) {

      this.$emit('change', value$1);
      //this.dispatch('form-item', 'el.form.change', [value]);


    }
  }
};

//  import Emitter from 'main/mixins/emitter';
  var Checkbox$1 = { template: "<div class=\"mint-checkbox mint-cell\" :class=\"[{'is-border':border}]\"><div class=\"mint-cell-wrapper\"><label class=\"mint-cell-title mint-checkbox-title\"><span class=\"mint-checkbox-i\"><span :class=\"{ 'is-disabled': disabled, 'is-checked': checked, 'is-indeterminate': indeterminate, 'is-focus': focus }\"></span> <input v-if=\"trueLabel || falseLabel\" class=\"mint-checkbox-input\" :true-value=\"trueLabel\" :false-value=\"falseLabel\" v-model=\"_value\" type=\"checkbox\" @focus=\"focus = true\" @blur=\"focus = false\" :disabled=\"disabled\" ref=\"checkbox\"> <input v-else class=\"mint-checkbox-input\" :value=\"label\" v-model=\"_value\" @focus=\"focus = true\" @blur=\"focus = false\" type=\"checkbox\" :disabled=\"disabled\"> <span class=\"mint-checkbox-core\"></span> </span><span class=\"mint-checkbox-label\" v-if=\"$slots.default || label\"><slot></slot><template v-if=\"!$slots.default\">{{label}}</template></span></label></div></div>",
    name: 'ai-checkbox',

//    mixins: [Emitter],

    props: {
      value: {},
      label: {
        type: String
      },
      indeterminate: Boolean,
      disabled: Boolean,
      border: Boolean,
      trueLabel: [String, Number],
      falseLabel: [String, Number]
    },

    computed: {
      _value: {
        get: function get() {
          return this.value !== undefined ? this.value : this.$parent.value;
        },
        set: function set(newValue) {

          if (this.value !== undefined) {
            this.$emit('input', newValue);
          } else {
            this.$parent.$emit('input', newValue);
          }
        }
      },
      checked: function checked() {
        var type = Object.prototype.toString.call(this._value);

        if (type === '[object Boolean]') {
          return this._value;
        } else if (type === '[object Array]') {
          return this._value.indexOf(this.label) > -1;
        } else if (type === '[object String]' || type === '[object Number]') {
          return this._value === this.trueLabel;
        }
      }
    },


    data: function data() {
      return {
        focus: false
      };
    },

    watch: {
      checked: function checked(sure) {
        this.$emit('change', sure);
      }
    }
  };

var RadioGroup$1 = { template: "<div class=\"ai-radio-group\"><slot></slot></div>",
    name: 'ai-radio-group',

    componentName: 'radio-group',

//    mixins: [emitter],

    props: {
      value: [String, Number],
      size: String
    },
    watch: {
      value: function value(value$1) {
        this.$emit('change', value$1);
//        this.dispatch('form-item', 'el.form.change', [this.value]);
      }
    }
  };

var Radio$1 = { template: "<div class=\"mint-radio mint-cell\" :class=\"[{'is-border':border}]\"><div class=\"mint-cell-wrapper\"><label class=\"mint-cell-title mint-radio-title\"><span class=\"mint-radio-i\"><input class=\"mint-radio-input\" :value=\"label\" type=\"radio\" v-model=\"_value\" @focus=\"focus = true\" @blur=\"focus = false\" :name=\"name\" :disabled=\"disabled\"> <span class=\"mint-radio-core\" :class=\"{ 'is-disabled': disabled, 'is-checked': _value === label, 'is-focus': focus }\"></span> </span><span class=\"mint-radio-label\"><slot></slot><template v-if=\"!$slots.default\">{{label}}</template></span></label></div></div>",
  name: 'ai-radio',

  props: {
    value: [String, Number],
    label: {
      type: [String, Number],
      required: true
    },
    border: Boolean,
    disabled: Boolean,
    name: String
  },
  data: function data() {
    return {
      focus: false
    };
  },
  computed: {
    _value: {
      get: function get() {
        return this.value !== undefined ? this.value : this.$parent.value;
      },
      set: function set(newValue) {
        if (this.value !== undefined) {
          this.$emit('input', newValue);
        } else {
          this.$parent.$emit('input', newValue);
        }
      }
    }
  }
};

var RadioButton$1 = { template: "<label class=\"radio-button\" :class=\"[ size ? 'radio-button-' + size : '', { 'is-active': value === label } ]\"><input class=\"radio-button-radio\" :value=\"label\" type=\"radio\" v-model=\"value\" :name=\"name\" :disabled=\"disabled\"> <span class=\"radio-button-inner\"><slot></slot><template v-if=\"!$slots.default\">{{label}}</template></span></label>",
  name: 'ai-radio-button',

  componentName: 'radio-button',

  props: {
    label: {
      type: [String, Number],
      required: true
    },
    disabled: Boolean,
    name: String
  },
  data: function data() {
    return {
      size: this.$parent.size
    };
  },
  computed: {
    value: {
      get: function get() {
        return this.$parent.value;
      },
      set: function set(newValue) {
        this.$parent.$emit('input', newValue);
      }
    }
  }
};

//  import ElInput from 'packages/input/index.js';
//  import { once, on } from 'wind-dom/src/event';
  var InputNumber$1 = { template: "<div class=\"ai-input-number clearfix\" :class=\"[ { 'is-disabled': disabled } ]\"><span class=\"ai-input-number__decrease\" :class=\"{'is-disabled': minDisabled}\" @click.stop.prevent=\"decrease\">- </span><input type=\"text\" v-model=\"currentValue\" :disabled=\"disabled\" :class=\"{ 'is-active': inputActive }\"> <span class=\"ai-input-number__increase\" :class=\"{'is-disabled': maxDisabled}\" @click.stop.prevent=\"increase\">+</span></div>",
    name: 'ai-input-number',
    props: {
      value: {
        default: 1
      },
      step: {
        type: Number,
        default: 1
      },
      max: {
        type: Number,
        default: Infinity
      },
      min: {
        type: Number,
        default: 0
      },
      disabled: Boolean,
      size: String
    },
//    directives: {
//      repeatClick: {
//        bind(el, binding, vnode) {
//          let interval = null;
//          let startTime;
//
//          const handler = () => {
//            vnode.context[binding.expression]();
//          };
//
//          const clear = function() {
//            if (new Date() - startTime < 100) {
//              handler();
//            }
//            clearInterval(interval);
//            interval = null;
//          };
//
////          on(el, 'mousedown', function() {
////            startTime = new Date();
////            once(document, 'mouseup', clear);
////            interval = setInterval(function() {
////              handler();
////            }, 100);
////          });
//        }
//      }
//    },
//    components: {
//      ElInput
//    },
    data: function data() {
      return {
        currentValue: parseInt(this.value),
        inputActive: false
      };
    },
    watch: {
      value: function value(val) {
        this.currentValue = val;
      },


      currentValue: function currentValue(newVal, oldVal) {
        var this$1 = this;

        if (!isNaN(newVal) && newVal <= this.max && newVal >= this.min) {
          this.$emit('change', newVal);
          this.$emit('input', newVal);
        } else {
          this.$nextTick(function () {
            this$1.currentValue = oldVal;
          });
        }
      }
    },
    computed: {
      minDisabled: function minDisabled() {
        return this.currentValue - this.step < this.min;
      },
      maxDisabled: function maxDisabled() {
        return this.currentValue + this.step > this.max;
      }
    },
    methods: {
      accSub: function accSub(arg1, arg2) {
        var r1, r2, m, n;
        try {
          r1 = arg1.toString().split('.')[1].length;
        } catch (e) {
          r1 = 0;
        }
        try {
          r2 = arg2.toString().split('.')[1].length;
        } catch (e) {
          r2 = 0;
        }
        m = Math.pow(10, Math.max(r1, r2));
        n = (r1 >= r2) ? r1 : r2;
        return parseFloat(((arg1 * m - arg2 * m) / m).toFixed(n));
      },
      accAdd: function accAdd(arg1, arg2) {
        var r1, r2, m, c;
        try {
          r1 = arg1.toString().split('.')[1].length;
        } catch (e) {
          r1 = 0;
        }
        try {
          r2 = arg2.toString().split('.')[1].length;
        } catch (e) {
          r2 = 0;
        }
        c = Math.abs(r1 - r2);
        m = Math.pow(10, Math.max(r1, r2));
        if (c > 0) {
          var cm = Math.pow(10, c);
          if (r1 > r2) {
            arg1 = Number(arg1.toString().replace('.', ''));
            arg2 = Number(arg2.toString().replace('.', '')) * cm;
          } else {
            arg1 = Number(arg1.toString().replace('.', '')) * cm;
            arg2 = Number(arg2.toString().replace('.', ''));
          }
        } else {
          arg1 = Number(arg1.toString().replace('.', ''));
          arg2 = Number(arg2.toString().replace('.', ''));
        }
        return (arg1 + arg2) / m;
      },
      increase: function increase() {

        if (this.currentValue + this.step > this.max || this.disabled) { return; }
        this.currentValue = this.accAdd(this.step, this.currentValue);
        if (this.maxDisabled) {
          this.inputActive = false;
        }
      },
      decrease: function decrease() {
        if (this.currentValue - this.step < this.min || this.disabled) { return; }
        this.currentValue = this.accSub(this.currentValue, this.step);
        if (this.minDisabled) {
          this.inputActive = false;
        }
      },
      activeInput: function activeInput(disabled) {
        if (!this.disabled && !disabled) {
          this.inputActive = true;
        }
      },
      inactiveInput: function inactiveInput(disabled) {
        if (!this.disabled && !disabled) {
          this.inputActive = false;
        }
      }
    }
  };

var Loadmore$1 = { template: "<div class=\"mint-loadmore\"><div class=\"mint-loadmore-content\" :class=\"{ 'is-dropped': topDropped || bottomDropped}\" :style=\"{ 'transform': 'translate3d(0, ' + translate + 'px, 0)' }\"><slot name=\"top\"><div class=\"mint-loadmore-top\" v-if=\"topMethod\"><spinner v-if=\"topStatus === 'loading'\" class=\"mint-loadmore-spinner\" :size=\"20\" type=\"fading-circle\"></spinner><span class=\"mint-loadmore-text\">{{ topText }}</span></div></slot><slot></slot><slot name=\"bottom\"><div class=\"mint-loadmore-bottom\" v-if=\"bottomMethod\"><spinner v-if=\"bottomStatus === 'loading'\" class=\"mint-loadmore-spinner\" :size=\"20\" type=\"fading-circle\"></spinner><span class=\"mint-loadmore-text\">{{ bottomText }}</span></div></slot></div></div>",
  name: 'ai-loadmore',
  components: {
    'spinner': spinner$1
  },

  props: {
    maxDistance: {
      type: Number,
      default: 0
    },
    autoFill: {
      type: Boolean,
      default: true
    },
    distanceIndex: {
      type: Number,
      default: 2
    },
    topPullText: {
      type: String,
      default: '下拉刷新'
    },
    topDropText: {
      type: String,
      default: '释放更新'
    },
    topLoadingText: {
      type: String,
      default: '加载中...'
    },
    topDistance: {
      type: Number,
      default: 70
    },
    topMethod: {
      type: Function
    },
    bottomPullText: {
      type: String,
      default: '上拉刷新'
    },
    bottomDropText: {
      type: String,
      default: '释放更新'
    },
    bottomLoadingText: {
      type: String,
      default: '加载中...'
    },
    bottomDistance: {
      type: Number,
      default: 70
    },
    bottomMethod: {
      type: Function
    },
    bottomAllLoaded: {
      type: Boolean,
      default: false
    }
  },

  data: function data() {
    return {
      translate: 0,
      scrollEventTarget: null,
      containerFilled: false,
      topText: '',
      topDropped: false,
      bottomText: '',
      bottomDropped: false,
      bottomReached: false,
      direction: '',
      startY: 0,
      startScrollTop: 0,
      currentY: 0,
      topStatus: '',
      bottomStatus: ''
    };
  },

  watch: {
    topStatus: function topStatus(val) {
      this.$emit('top-status-change', val);
      switch (val) {
        case 'pull':
          this.topText = this.topPullText;
          break;
        case 'drop':
          this.topText = this.topDropText;
          break;
        case 'loading':
          this.topText = this.topLoadingText;
          break;
      }
    },

    bottomStatus: function bottomStatus(val) {
      this.$emit('bottom-status-change', val);
      switch (val) {
        case 'pull':
          this.bottomText = this.bottomPullText;
          break;
        case 'drop':
          this.bottomText = this.bottomDropText;
          break;
        case 'loading':
          this.bottomText = this.bottomLoadingText;
          break;
      }
    }
  },

  methods: {
    onTopLoaded: function onTopLoaded() {
      var this$1 = this;

      this.translate = 0;
      setTimeout(function () {
        this$1.topStatus = 'pull';
      }, 200);
    },

    onBottomLoaded: function onBottomLoaded() {
      var this$1 = this;

      this.bottomStatus = 'pull';
      this.bottomDropped = false;
      this.$nextTick(function () {
        if (this$1.scrollEventTarget === window) {
          document.body.scrollTop += 50;
        } else {
          this$1.scrollEventTarget.scrollTop += 50;
        }
        this$1.translate = 0;
      });
      if (!this.bottomAllLoaded && !this.containerFilled) {
        this.fillContainer();
      }
    },

    getScrollEventTarget: function getScrollEventTarget(element) {
      var currentNode = element;
      while (currentNode && currentNode.tagName !== 'HTML' &&
        currentNode.tagName !== 'BODY' && currentNode.nodeType === 1) {
        var overflowY = document.defaultView.getComputedStyle(currentNode).overflowY;
        if (overflowY === 'scroll' || overflowY === 'auto') {
          return currentNode;
        }
        currentNode = currentNode.parentNode;
      }
      return window;
    },

    getScrollTop: function getScrollTop(element) {
      if (element === window) {
        return Math.max(window.pageYOffset || 0, document.documentElement.scrollTop);
      } else {
        return element.scrollTop;
      }
    },

    bindTouchEvents: function bindTouchEvents() {
      this.$el.addEventListener('touchstart', this.handleTouchStart);
      this.$el.addEventListener('touchmove', this.handleTouchMove);
      this.$el.addEventListener('touchend', this.handleTouchEnd);
    },

    init: function init() {
      this.topStatus = 'pull';
      this.bottomStatus = 'pull';
      this.topText = this.topPullText;
      this.scrollEventTarget = this.getScrollEventTarget(this.$el);
      if (typeof this.bottomMethod === 'function') {
        this.fillContainer();
        this.bindTouchEvents();
      }
      if (typeof this.topMethod === 'function') {
        this.bindTouchEvents();
      }
    },

    fillContainer: function fillContainer() {
      var this$1 = this;

      if (this.autoFill) {
        this.$nextTick(function () {
          if (this$1.scrollEventTarget === window) {
            this$1.containerFilled = this$1.$el.getBoundingClientRect().bottom >=
              document.documentElement.getBoundingClientRect().bottom;
          } else {
            this$1.containerFilled = this$1.$el.getBoundingClientRect().bottom >=
              this$1.scrollEventTarget.getBoundingClientRect().bottom;
          }
          if (!this$1.containerFilled) {
            this$1.bottomStatus = 'loading';
            this$1.bottomMethod();
          }
        });
      }
    },

    checkBottomReached: function checkBottomReached() {
      if (this.scrollEventTarget === window) {
        return document.body.scrollTop + document.documentElement.clientHeight >= document.body.scrollHeight;
      } else {
        return this.$el.getBoundingClientRect().bottom <= this.scrollEventTarget.getBoundingClientRect().bottom + 1;
      }
    },

    handleTouchStart: function handleTouchStart(event) {
      this.startY = event.touches[0].clientY;
      this.startScrollTop = this.getScrollTop(this.scrollEventTarget);
      this.bottomReached = false;
      if (this.topStatus !== 'loading') {
        this.topStatus = 'pull';
        this.topDropped = false;
      }
      if (this.bottomStatus !== 'loading') {
        this.bottomStatus = 'pull';
        this.bottomDropped = false;
      }
    },

    handleTouchMove: function handleTouchMove(event) {
      if (this.startY < this.$el.getBoundingClientRect().top && this.startY > this.$el.getBoundingClientRect().bottom) {
        return;
      }
      this.currentY = event.touches[0].clientY;
      var distance = (this.currentY - this.startY) / this.distanceIndex;
      this.direction = distance > 0 ? 'down' : 'up';
      if (typeof this.topMethod === 'function' && this.direction === 'down' &&
        this.getScrollTop(this.scrollEventTarget) === 0 && this.topStatus !== 'loading') {
        event.preventDefault();
        event.stopPropagation();
        if (this.maxDistance > 0) {
          this.translate = distance <= this.maxDistance ? distance - this.startScrollTop : this.translate;
        } else {
          this.translate = distance - this.startScrollTop;
        }
        if (this.translate < 0) {
          this.translate = 0;
        }
        this.topStatus = this.translate >= this.topDistance ? 'drop' : 'pull';
      }

      if (this.direction === 'up') {
        this.bottomReached = this.bottomReached || this.checkBottomReached();
      }
      if (typeof this.bottomMethod === 'function' && this.direction === 'up' &&
        this.bottomReached && this.bottomStatus !== 'loading' && !this.bottomAllLoaded) {
        event.preventDefault();
        event.stopPropagation();
        if (this.maxDistance > 0) {
          this.translate = Math.abs(distance) <= this.maxDistance
            ? this.getScrollTop(this.scrollEventTarget) - this.startScrollTop + distance : this.translate;
        } else {
          this.translate = this.getScrollTop(this.scrollEventTarget) - this.startScrollTop + distance;
        }
        if (this.translate > 0) {
          this.translate = 0;
        }
        this.bottomStatus = -this.translate >= this.bottomDistance ? 'drop' : 'pull';
      }
    },

    handleTouchEnd: function handleTouchEnd() {
      if (this.direction === 'down' && this.getScrollTop(this.scrollEventTarget) === 0 && this.translate > 0) {
        this.topDropped = true;
        if (this.topStatus === 'drop') {
          this.translate = '50';
          this.topStatus = 'loading';
          this.topMethod();
        } else {
          this.translate = '0';
          this.topStatus = 'pull';
        }
      }
      if (this.direction === 'up' && this.bottomReached && this.translate < 0) {
        this.bottomDropped = true;
        this.bottomReached = false;
        if (this.bottomStatus === 'drop') {
          this.translate = '-50';
          this.bottomStatus = 'loading';
          this.bottomMethod();
        } else {
          this.translate = '0';
          this.bottomStatus = 'pull';
        }
      }
      this.direction = '';
    }
  },

  mounted: function mounted() {
    this.init();
  }
};

var commonjsGlobal = typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};



function unwrapExports (x) {
	return x && x.__esModule ? x['default'] : x;
}

function createCommonjsModule(fn, module) {
	return module = { exports: {} }, fn(module, module.exports), module.exports;
}

var index$1 = createCommonjsModule(function (module, exports) {
!function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t(Vue$1):"function"==typeof undefined&&undefined.amd?undefined("VuePopup",["vue"],t):"object"==typeof exports?exports.VuePopup=t(Vue$1):e.VuePopup=t(e.vue);}(commonjsGlobal,function(e){return function(e){function t(n){if(o[n]){ return o[n].exports; }var i=o[n]={i:n,l:!1,exports:{}};return e[n].call(i.exports,i,i.exports,t),i.l=!0,i.exports}var o={};return t.m=e,t.c=o,t.i=function(e){return e},t.d=function(e,t,o){Object.defineProperty(e,t,{configurable:!1,enumerable:!0,get:o});},t.n=function(e){var o=e&&e.__esModule?function(){return e["default"]}:function(){return e};return t.d(o,"a",o),o},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="/lib/",t(t.s=6)}([function(e,t,o){"use strict";function n(e){return e&&e.__esModule?e:{"default":e}}t.__esModule=!0,t.PopupManager=void 0;var i=o(5),l=n(i),s=o(3),d=o(2),a=n(d);o(4);var r=1,u=[],c=function(e){if(u.indexOf(e)===-1){var t=function(e){var t=e.__vue__;if(!t){var o=e.previousSibling;o.__vue__&&(t=o.__vue__);}return t};l["default"].transition(e,{afterEnter:function(e){var o=t(e);o&&o.doAfterOpen&&o.doAfterOpen();},afterLeave:function(e){var o=t(e);o&&o.doAfterClose&&o.doAfterClose();}});}},f=void 0,p=function(){if(void 0!==f){ return f; }var e=document.createElement("div");e.style.visibility="hidden",e.style.width="100px",e.style.position="absolute",e.style.top="-9999px",document.body.appendChild(e);var t=e.offsetWidth;e.style.overflow="scroll";var o=document.createElement("div");o.style.width="100%",e.appendChild(o);var n=o.offsetWidth;return e.parentNode.removeChild(e),t-n},h=function m(e){return 3===e.nodeType&&(e=e.nextElementSibling||e.nextSibling,m(e)),e};t["default"]={props:{value:{type:Boolean,"default":!1},transition:{type:String,"default":""},openDelay:{},closeDelay:{},zIndex:{},modal:{type:Boolean,"default":!1},modalFade:{type:Boolean,"default":!0},modalClass:{},lockScroll:{type:Boolean,"default":!0},closeOnPressEscape:{type:Boolean,"default":!1},closeOnClickModal:{type:Boolean,"default":!1}},created:function(){this.transition&&c(this.transition);},beforeMount:function(){this._popupId="popup-"+r++,a["default"].register(this._popupId,this);},beforeDestroy:function(){a["default"].deregister(this._popupId),a["default"].closeModal(this._popupId),this.modal&&null!==this.bodyOverflow&&"hidden"!==this.bodyOverflow&&(document.body.style.overflow=this.bodyOverflow,document.body.style.paddingRight=this.bodyPaddingRight),this.bodyOverflow=null,this.bodyPaddingRight=null;},data:function(){return{opened:!1,bodyOverflow:null,bodyPaddingRight:null,rendered:!1}},watch:{value:function(e){var t=this;if(e){if(this._opening){ return; }this.rendered?this.open():(this.rendered=!0,l["default"].nextTick(function(){t.open();}));}else { this.close(); }}},methods:{open:function(e){var t=this;this.rendered||(this.rendered=!0,this.$emit("input",!0));var o=(0,s.merge)({},this,e);this._closeTimer&&(clearTimeout(this._closeTimer),this._closeTimer=null),clearTimeout(this._openTimer);var n=Number(o.openDelay);n>0?this._openTimer=setTimeout(function(){t._openTimer=null,t.doOpen(o);},n):this.doOpen(o);},doOpen:function(e){if((!this.willOpen||this.willOpen())&&!this.opened){this._opening=!0,this.visible=!0,this.$emit("input",!0);var t=h(this.$el),o=e.modal,n=e.zIndex;if(n&&(a["default"].zIndex=n),o&&(this._closing&&(a["default"].closeModal(this._popupId),this._closing=!1),a["default"].openModal(this._popupId,a["default"].nextZIndex(),t,e.modalClass,e.modalFade),e.lockScroll)){this.bodyOverflow||(this.bodyPaddingRight=document.body.style.paddingRight,this.bodyOverflow=document.body.style.overflow),f=p();var i=document.documentElement.clientHeight<document.body.scrollHeight;f>0&&i&&(document.body.style.paddingRight=f+"px"),document.body.style.overflow="hidden";}"static"===getComputedStyle(t).position&&(t.style.position="absolute"),o?t.style.zIndex=a["default"].nextZIndex():n&&(t.style.zIndex=n),this.opened=!0,this.onOpen&&this.onOpen(),this.transition||this.doAfterOpen();}},doAfterOpen:function(){this._opening=!1;},close:function(){var e=this;if(!this.willClose||this.willClose()){null!==this._openTimer&&(clearTimeout(this._openTimer),this._openTimer=null),clearTimeout(this._closeTimer);var t=Number(this.closeDelay);t>0?this._closeTimer=setTimeout(function(){e._closeTimer=null,e.doClose();},t):this.doClose();}},doClose:function(){var e=this;this.visible=!1,this.$emit("input",!1),this._closing=!0,this.onClose&&this.onClose(),this.lockScroll&&setTimeout(function(){e.modal&&"hidden"!==e.bodyOverflow&&(document.body.style.overflow=e.bodyOverflow,document.body.style.paddingRight=e.bodyPaddingRight),e.bodyOverflow=null,e.bodyPaddingRight=null;},200),this.opened=!1,this.transition||this.doAfterClose();},doAfterClose:function(){a["default"].closeModal(this._popupId),this._closing=!1;}}},t.PopupManager=a["default"];},function(e,t){var o=function(e){return(e||"").replace(/^[\s\uFEFF]+|[\s\uFEFF]+$/g,"")},n=function(e,t){if(!e||!t){ return!1; }if(t.indexOf(" ")!=-1){ throw new Error("className should not contain space."); }return e.classList?e.classList.contains(t):(" "+e.className+" ").indexOf(" "+t+" ")>-1},i=function(e,t){if(e){for(var o=e.className,i=(t||"").split(" "),l=0,s=i.length;l<s;l++){var d=i[l];d&&(e.classList?e.classList.add(d):n(e,d)||(o+=" "+d));}e.classList||(e.className=o);}},l=function(e,t){if(e&&t){for(var i=t.split(" "),l=" "+e.className+" ",s=0,d=i.length;s<d;s++){var a=i[s];a&&(e.classList?e.classList.remove(a):n(e,a)&&(l=l.replace(" "+a+" "," ")));}e.classList||(e.className=o(l));}};e.exports={hasClass:n,addClass:i,removeClass:l};},function(e,t,o){"use strict";t.__esModule=!0;var n=o(1),i=!1,l=function(){var e=d.modalDom;return e?i=!0:(i=!1,e=document.createElement("div"),d.modalDom=e,e.addEventListener("touchmove",function(e){e.preventDefault(),e.stopPropagation();}),e.addEventListener("click",function(){d.doOnModalClick&&d.doOnModalClick();})),e},s={},d={zIndex:2e3,modalFade:!0,getInstance:function(e){return s[e]},register:function(e,t){e&&t&&(s[e]=t);},deregister:function(e){e&&(s[e]=null,delete s[e]);},nextZIndex:function(){return d.zIndex++},modalStack:[],doOnModalClick:function(){var e=d.modalStack[d.modalStack.length-1];if(e){var t=d.getInstance(e.id);t&&t.closeOnClickModal&&t.close();}},openModal:function(e,t,o,s,d){if(e&&void 0!==t){this.modalFade=d;for(var a=this.modalStack,r=0,u=a.length;r<u;r++){var c=a[r];if(c.id===e){ return }}var f=l();if((0,n.addClass)(f,"v-modal"),this.modalFade&&!i&&(0,n.addClass)(f,"v-modal-enter"),s){var p=s.trim().split(/\s+/);p.forEach(function(e){return(0,n.addClass)(f,e)});}setTimeout(function(){(0,n.removeClass)(f,"v-modal-enter");},200),o&&o.parentNode&&11!==o.parentNode.nodeType?o.parentNode.appendChild(f):document.body.appendChild(f),t&&(f.style.zIndex=t),f.style.display="",this.modalStack.push({id:e,zIndex:t,modalClass:s});}},closeModal:function(e){var t=this.modalStack,o=l();if(t.length>0){var i=t[t.length-1];if(i.id===e){if(i.modalClass){var s=i.modalClass.trim().split(/\s+/);s.forEach(function(e){return(0,n.removeClass)(o,e)});}t.pop(),t.length>0&&(o.style.zIndex=t[t.length-1].zIndex);}else { for(var a=t.length-1;a>=0;a--){ if(t[a].id===e){t.splice(a,1);break} } }}0===t.length&&(this.modalFade&&(0,n.addClass)(o,"v-modal-leave"),setTimeout(function(){0===t.length&&(o.parentNode&&o.parentNode.removeChild(o),o.style.display="none",d.modalDom=void 0),(0,n.removeClass)(o,"v-modal-leave");},200));}};window.addEventListener("keydown",function(e){if(27===e.keyCode&&d.modalStack.length>0){var t=d.modalStack[d.modalStack.length-1];if(!t){ return; }var o=d.getInstance(t.id);o.closeOnPressEscape&&o.close();}}),t["default"]=d;},function(e,t){"use strict";function o(e){
var arguments$1 = arguments;
for(var t=1,o=arguments.length;t<o;t++){var n=arguments$1[t];for(var i in n){ if(n.hasOwnProperty(i)){var l=n[i];void 0!==l&&(e[i]=l);} }}return e}t.__esModule=!0,t.merge=o;},function(e,t){},function(t,o){t.exports=e;},function(e,t,o){e.exports=o(0);}])});
});

var Popup = unwrapExports(index$1);

var Actionsheet$1 = { template: "<transition name=\"actionsheet-float\"><div v-show=\"currentValue\" class=\"mint-actionsheet\"><ul class=\"mint-actionsheet-list\" :style=\"{ 'margin-bottom': cancelText ? '5px' : '0' }\"><li v-for=\"item in actions\" class=\"mint-actionsheet-listitem\" @click.stop=\"itemClick(item)\">{{ item.name }}</li></ul><a class=\"mint-actionsheet-button\" @click.stop=\"currentValue = false\" v-if=\"cancelText\">{{ cancelText }}</a></div></transition>",
  name: 'ai-actionsheet',

  mixins: [Popup],

  props: {
    modal: {
      default: true
    },

    modalFade: {
      default: false
    },

    lockScroll: {
      default: false
    },

    closeOnClickModal: {
      default: true
    },

    cancelText: {
      type: String,
      default: '取消'
    },

    actions: {
      type: Array,
      default: function () { return []; }
    }
  },

  data: function data() {
    return {
      currentValue: false
    };
  },

  watch: {
    currentValue: function currentValue(val) {
      this.$emit('input', val);
    },

    value: function value(val) {
      this.currentValue = val;
    }
  },

  methods: {
    itemClick: function itemClick(item) {
      console.log(item);
      if (item.method && typeof item.method === 'function') {

        item.method();
      }
      this.currentValue = false;
    }
  },

  mounted: function mounted() {
    if (this.value) {
      this.rendered = true;
      this.currentValue = true;
      this.open();
    }
  }
};

var popup$1 = { template: "<transition :name=\"currentTransition\"><div v-show=\"currentValue\" class=\"mint-popup\" :class=\"[position ? 'mint-popup-' + position : '']\"><slot></slot></div></transition>",
  name: 'ai-popup',

  mixins: [Popup],

  props: {
    modal: {
      default: true
    },

    modalFade: {
      default: false
    },

    lockScroll: {
      default: false
    },

    closeOnClickModal: {
      default: true
    },

    popupTransition: {
      type: String,
      default: 'popup-slide'
    },

    position: {
      type: String,
      default: ''
    }
  },

  data: function data() {
    return {
      currentValue: false,
      currentTransition: this.popupTransition
    };
  },

  watch: {
    currentValue: function currentValue(val) {
      this.$emit('input', val);
    },

    value: function value(val) {
      this.currentValue = val;
    }
  },

  beforeMount: function beforeMount() {
    if (this.popupTransition !== 'popup-fade') {
      this.currentTransition = "popup-slide-" + (this.position);
    }
  },

  mounted: function mounted() {
    if (this.value) {
      this.rendered = true;
      this.currentValue = true;
      this.open();
    }
  }
};

var trim = function (string) {
  return (string || '').replace(/^[\s\uFEFF]+|[\s\uFEFF]+$/g, '');
};

var hasClass = function (el, cls) {
  if (!el || !cls) { return false; }
  if (cls.indexOf(' ') != -1) { throw new Error('className should not contain space.'); }
  if (el.classList) {
    return el.classList.contains(cls);
  } else {
    return (' ' + el.className + ' ').indexOf(' ' + cls + ' ') > -1;
  }
};

var addClass = function (el, cls) {
  if (!el) { return; }
  var curClass = el.className;
  var classes = (cls || '').split(' ');

  for (var i = 0, j = classes.length; i < j; i++) {
    var clsName = classes[i];
    if (!clsName) { continue; }

    if (el.classList) {
      el.classList.add(clsName);
    } else {
      if (!hasClass(el, clsName)) {
        curClass += ' ' + clsName;
      }
    }
  }
  if (!el.classList) {
    el.className = curClass;
  }
};

var removeClass = function (el, cls) {
  if (!el || !cls) { return; }
  var classes = cls.split(' ');
  var curClass = ' ' + el.className + ' ';

  for (var i = 0, j = classes.length; i < j; i++) {
    var clsName = classes[i];
    if (!clsName) { continue; }

    if (el.classList) {
      el.classList.remove(clsName);
    } else {
      if (hasClass(el, clsName)) {
        curClass = curClass.replace(' ' + clsName + ' ', ' ');
      }
    }
  }
  if (!el.classList) {
    el.className = trim(curClass);
  }
};

var _class = {
  hasClass: hasClass,
  addClass: addClass,
  removeClass: removeClass
};

var removeClass = _class.removeClass;
var addClass = _class.addClass;

var Swipe$1 = { template: "<div class=\"mint-swipe\"><div class=\"mint-swipe-items-wrap\" ref=\"wrap\"><slot></slot></div><div class=\"mint-swipe-indicators\" v-show=\"showIndicators\"><div class=\"mint-swipe-indicator\" v-for=\"(page, $index) in pages\" :class=\"{ 'is-active': $index === index }\"></div></div></div>",
  name: 'ai-swipe',

  created: function created() {
    this.dragState = {};
  },

  data: function data() {
    return {
      ready: false,
      dragging: false,
      userScrolling: false,
      animating: false,
      index: 0,
      pages: [],
      timer: null,
      reInitTimer: null,
      noDrag: false
    };
  },

  props: {
    speed: {
      type: Number,
      default: 300
    },

    defaultIndex: {
      type: Number,
      default: 0
    },

    auto: {
      type: Number,
      default: 3000
    },

    continuous: {
      type: Boolean,
      default: true
    },

    showIndicators: {
      type: Boolean,
      default: true
    },

    noDragWhenSingle: {
      type: Boolean,
      default: true
    },

    prevent: {
      type: Boolean,
      default: false
    }
  },

  methods: {
    swipeItemCreated: function swipeItemCreated() {
      var this$1 = this;

      if (!this.ready) { return; }

      clearTimeout(this.reInitTimer);
      this.reInitTimer = setTimeout(function () {
        this$1.reInitPages();
      }, 100);
    },

    swipeItemDestroyed: function swipeItemDestroyed() {
      var this$1 = this;

      if (!this.ready) { return; }

      clearTimeout(this.reInitTimer);
      this.reInitTimer = setTimeout(function () {
        this$1.reInitPages();
      }, 100);
    },

    translate: function translate(element, offset, speed, callback) {
      var arguments$1 = arguments;
      var this$1 = this;

      if (speed) {
        this.animating = true;
        element.style.webkitTransition = '-webkit-transform ' + speed + 'ms ease-in-out';
        setTimeout(function () {
          element.style.webkitTransform = "translate3d(" + offset + "px, 0, 0)";
        }, 50);

        var called = false;

        var transitionEndCallback = function () {
          if (called) { return; }
          called = true;
          this$1.animating = false;
          element.style.webkitTransition = '';
          element.style.webkitTransform = '';
          if (callback) {
            callback.apply(this$1, arguments$1);
          }
        };

        once(element, 'webkitTransitionEnd', transitionEndCallback);
        setTimeout(transitionEndCallback, speed + 100); // webkitTransitionEnd maybe not fire on lower version android.
      } else {
        element.style.webkitTransition = '';
        element.style.webkitTransform = "translate3d(" + offset + "px, 0, 0)";
      }
    },

    reInitPages: function reInitPages() {
      var children = this.$children;
      this.noDrag = children.length === 1 && this.noDragWhenSingle;

      var pages = [];
      var intDefaultIndex = Math.floor(this.defaultIndex);
      var defaultIndex = (intDefaultIndex >= 0 && intDefaultIndex < children.length) ? intDefaultIndex : 0;
      this.index = defaultIndex;

      children.forEach(function(child, index) {
        pages.push(child.$el);

        removeClass(child.$el, 'is-active');

        if (index === defaultIndex) {
          addClass(child.$el, 'is-active');
        }
      });

      this.pages = pages;
    },

    doAnimate: function doAnimate(towards, options) {
      var this$1 = this;

      if (this.$children.length === 0) { return; }
      if (!options && this.$children.length < 2) { return; }

      var prevPage, nextPage, currentPage, pageWidth, offsetLeft;
      var speed = this.speed || 300;
      var index = this.index;
      var pages = this.pages;
      var pageCount = pages.length;

      if (!options) {
        pageWidth = this.$el.clientWidth;
        currentPage = pages[index];
        prevPage = pages[index - 1];
        nextPage = pages[index + 1];
        if (this.continuous && pages.length > 1) {
          if (!prevPage) {
            prevPage = pages[pages.length - 1];
          }
          if (!nextPage) {
            nextPage = pages[0];
          }
        }
        if (prevPage) {
          prevPage.style.display = 'block';
          this.translate(prevPage, -pageWidth);
        }
        if (nextPage) {
          nextPage.style.display = 'block';
          this.translate(nextPage, pageWidth);
        }
      } else {
        prevPage = options.prevPage;
        currentPage = options.currentPage;
        nextPage = options.nextPage;
        pageWidth = options.pageWidth;
        offsetLeft = options.offsetLeft;
      }

      var newIndex;

      var oldPage = this.$children[index].$el;

      if (towards === 'prev') {
        if (index > 0) {
          newIndex = index - 1;
        }
        if (this.continuous && index === 0) {
          newIndex = pageCount - 1;
        }
      } else if (towards === 'next') {
        if (index < pageCount - 1) {
          newIndex = index + 1;
        }
        if (this.continuous && index === pageCount - 1) {
          newIndex = 0;
        }
      }

      var callback = function () {
        if (newIndex !== undefined) {
          var newPage = this$1.$children[newIndex].$el;
          removeClass(oldPage, 'is-active');
          addClass(newPage, 'is-active');

          this$1.index = newIndex;
        }

        if (prevPage) {
          prevPage.style.display = '';
        }

        if (nextPage) {
          nextPage.style.display = '';
        }
      };

      setTimeout(function () {
        if (towards === 'next') {
          this$1.translate(currentPage, -pageWidth, speed, callback);
          if (nextPage) {
            this$1.translate(nextPage, 0, speed);
          }
        } else if (towards === 'prev') {
          this$1.translate(currentPage, pageWidth, speed, callback);
          if (prevPage) {
            this$1.translate(prevPage, 0, speed);
          }
        } else {
          this$1.translate(currentPage, 0, speed, callback);
          if (typeof offsetLeft !== 'undefined') {
            if (prevPage && offsetLeft > 0) {
              this$1.translate(prevPage, pageWidth * -1, speed);
            }
            if (nextPage && offsetLeft < 0) {
              this$1.translate(nextPage, pageWidth, speed);
            }
          } else {
            if (prevPage) {
              this$1.translate(prevPage, pageWidth * -1, speed);
            }
            if (nextPage) {
              this$1.translate(nextPage, pageWidth, speed);
            }
          }
        }
      }, 10);
    },

    next: function next() {
      this.doAnimate('next');
    },

    prev: function prev() {
      this.doAnimate('prev');
    },

    doOnTouchStart: function doOnTouchStart(event) {
      if (this.noDrag) { return; }

      var element = this.$el;
      var dragState = this.dragState;
      var touch = event.touches[0];

      dragState.startTime = new Date();
      dragState.startLeft = touch.pageX;
      dragState.startTop = touch.pageY;
      dragState.startTopAbsolute = touch.clientY;

      dragState.pageWidth = element.offsetWidth;
      dragState.pageHeight = element.offsetHeight;

      var prevPage = this.$children[this.index - 1];
      var dragPage = this.$children[this.index];
      var nextPage = this.$children[this.index + 1];

      if (this.continuous && this.pages.length > 1) {
        if (!prevPage) {
          prevPage = this.$children[this.$children.length - 1];
        }
        if (!nextPage) {
          nextPage = this.$children[0];
        }
      }

      dragState.prevPage = prevPage ? prevPage.$el : null;
      dragState.dragPage = dragPage ? dragPage.$el : null;
      dragState.nextPage = nextPage ? nextPage.$el : null;

      if (dragState.prevPage) {
        dragState.prevPage.style.display = 'block';
      }

      if (dragState.nextPage) {
        dragState.nextPage.style.display = 'block';
      }
    },

    doOnTouchMove: function doOnTouchMove(event) {
      if (this.noDrag) { return; }

      var dragState = this.dragState;
      var touch = event.touches[0];

      dragState.currentLeft = touch.pageX;
      dragState.currentTop = touch.pageY;
      dragState.currentTopAbsolute = touch.clientY;

      var offsetLeft = dragState.currentLeft - dragState.startLeft;
      var offsetTop = dragState.currentTopAbsolute - dragState.startTopAbsolute;

      var distanceX = Math.abs(offsetLeft);
      var distanceY = Math.abs(offsetTop);
      if (distanceX < 5 || (distanceX >= 5 && distanceY >= 1.73 * distanceX)) {
        this.userScrolling = true;
        return;
      } else {
        this.userScrolling = false;
        event.preventDefault();
      }
      offsetLeft = Math.min(Math.max(-dragState.pageWidth + 1, offsetLeft), dragState.pageWidth - 1);

      var towards = offsetLeft < 0 ? 'next' : 'prev';

      if (dragState.prevPage && towards === 'prev') {
        this.translate(dragState.prevPage, offsetLeft - dragState.pageWidth);
      }
      this.translate(dragState.dragPage, offsetLeft);
      if (dragState.nextPage && towards === 'next') {
        this.translate(dragState.nextPage, offsetLeft + dragState.pageWidth);
      }
    },

    doOnTouchEnd: function doOnTouchEnd() {
      if (this.noDrag) { return; }

      var dragState = this.dragState;

      var dragDuration = new Date() - dragState.startTime;
      var towards = null;

      var offsetLeft = dragState.currentLeft - dragState.startLeft;
      var offsetTop = dragState.currentTop - dragState.startTop;
      var pageWidth = dragState.pageWidth;
      var index = this.index;
      var pageCount = this.pages.length;

      if (dragDuration < 300) {
        var fireTap = Math.abs(offsetLeft) < 5 && Math.abs(offsetTop) < 5;
        if (isNaN(offsetLeft) || isNaN(offsetTop)) {
          fireTap = true;
        }
        if (fireTap) {
          this.$children[this.index].$emit('tap');
        }
      }

      if (dragDuration < 300 && dragState.currentLeft === undefined) { return; }

      if (dragDuration < 300 || Math.abs(offsetLeft) > pageWidth / 2) {
        towards = offsetLeft < 0 ? 'next' : 'prev';
      }

      if (!this.continuous) {
        if ((index === 0 && towards === 'prev') || (index === pageCount - 1 && towards === 'next')) {
          towards = null;
        }
      }

      if (this.$children.length < 2) {
        towards = null;
      }

      this.doAnimate(towards, {
        offsetLeft: offsetLeft,
        pageWidth: dragState.pageWidth,
        prevPage: dragState.prevPage,
        currentPage: dragState.dragPage,
        nextPage: dragState.nextPage
      });

      this.dragState = {};
    }
  },

  destroyed: function destroyed() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this.reInitTimer) {
      clearTimeout(this.reInitTimer);
      this.reInitTimer = null;
    }
  },

  mounted: function mounted() {
    var this$1 = this;

    this.ready = true;

    if (this.auto > 0) {
      this.timer = setInterval(function () {
        if (!this$1.dragging && !this$1.animating) {
          this$1.next();
        }
      }, this.auto);
    }

    this.reInitPages();

    var element = this.$el;

    element.addEventListener('touchstart', function (event) {
      if (this$1.prevent) {
        event.preventDefault();
      }
      if (this$1.animating) { return; }
      this$1.dragging = true;
      this$1.userScrolling = false;
      this$1.doOnTouchStart(event);
    });

    element.addEventListener('touchmove', function (event) {
      if (!this$1.dragging) { return; }
      this$1.doOnTouchMove(event);
    });

    element.addEventListener('touchend', function (event) {
      if (this$1.userScrolling) {
        this$1.dragging = false;
        this$1.dragState = {};
        return;
      }
      if (!this$1.dragging) { return; }
      this$1.doOnTouchEnd(event);
      this$1.dragging = false;
    });
  }
};

var SwipeItem$1 = { template: "<div class=\"mint-swipe-item\"><slot></slot></div>",
  name: 'ai-swipe-item',

  mounted: function mounted() {
    this.$parent && this.$parent.swipeItemCreated(this);
  },

  destroyed: function destroyed() {
    this.$parent && this.$parent.swipeItemDestroyed(this);
  }
};

var isDragging = false;
var supportTouch = 'ontouchstart' in window;

var draggable = function(element, options) {
  var moveFn = function(event) {
    if (options.drag) {
      options.drag(supportTouch ? event.changedTouches[0] || event.touches[0] : event);
    }
  };

  var endFn = function(event) {
    if (!supportTouch) {
      document.removeEventListener('mousemove', moveFn);
      document.removeEventListener('mouseup', endFn);
    }
    document.onselectstart = null;
    document.ondragstart = null;

    isDragging = false;

    if (options.end) {
      options.end(supportTouch ? event.changedTouches[0] || event.touches[0] : event);
    }
  };

  element.addEventListener(supportTouch ? 'touchstart' : 'mousedown', function(event) {
    if (isDragging) { return; }
    event.preventDefault();
    document.onselectstart = function() { return false; };
    document.ondragstart = function() { return false; };

    if (!supportTouch) {
      document.addEventListener('mousemove', moveFn);
      document.addEventListener('mouseup', endFn);
    }
    isDragging = true;

    if (options.start) {
      options.start(supportTouch ? event.changedTouches[0] || event.touches[0] : event);
    }
  });

  if (supportTouch) {
    element.addEventListener('touchmove', moveFn);
    element.addEventListener('touchend', endFn);
    element.addEventListener('touchcancel', endFn);
  }
};

var MintRange = { template: "<div class=\"mt-range\" :class=\"{ 'mt-range--disabled': disabled }\"><slot name=\"start\"></slot><div class=\"mt-range-content\" ref=\"content\"><div class=\"mt-range-runway\" :style=\"{ 'border-top-width': barHeight + 'px' }\"></div><div class=\"mt-range-progress\" :style=\"{ width: progress + '%', height: barHeight + 'px' }\"></div><div class=\"mt-range-thumb\" ref=\"thumb\" :style=\"{ left: progress + '%' }\"></div></div><slot name=\"end\"></slot></div>",
  name: 'ai-range',

  props: {
    min: {
      type: Number,
      default: 0
    },
    max: {
      type: Number,
      default: 100
    },
    step: {
      type: Number,
      default: 1
    },
    disabled: {
      type: Boolean,
      default: false
    },
    value: {
      type: Number
    },
    barHeight: {
      type: Number,
      default: 1
    }
  },

  computed: {
    progress: function progress() {
      var value = this.value;
      if (typeof value === 'undefined' || value === null) { return 0; }
      return Math.floor((value - this.min) / (this.max - this.min) * 100);
    }
  },

  mounted: function mounted() {
    var this$1 = this;

    var thumb = this.$refs.thumb;
    var content = this.$refs.content;

    var getThumbPosition = function () {
      var contentBox = content.getBoundingClientRect();
      var thumbBox = thumb.getBoundingClientRect();

      return {
        left: thumbBox.left - contentBox.left,
        top: thumbBox.top - contentBox.top
      };
    };

    var dragState = {};
    draggable(thumb, {
      start: function () {
        if (this$1.disabled) { return; }
        var position = getThumbPosition();
        dragState = {
          thumbStartLeft: position.left,
          thumbStartTop: position.top
        };
      },
      drag: function (event) {
        if (this$1.disabled) { return; }
        var contentBox = content.getBoundingClientRect();
        var deltaX = event.pageX - contentBox.left - dragState.thumbStartLeft;
        var stepCount = Math.ceil((this$1.max - this$1.min) / this$1.step);
        var newPosition = (dragState.thumbStartLeft + deltaX) - (dragState.thumbStartLeft + deltaX) % (contentBox.width / stepCount);

        var newProgress = newPosition / contentBox.width;

        if (newProgress < 0) {
          newProgress = 0;
        } else if (newProgress > 1) {
          newProgress = 1;
        }

        this$1.$emit('input', Math.round(this$1.min + newProgress * (this$1.max - this$1.min)));
      },
      end: function () {
        if (this$1.disabled) { return; }
        this$1.$emit('change', this$1.value);
        dragState = {};
      }
    });
  }
};

// const MintRange = require('./src/index.vue');

MintRange.install = function(Vue) {
  Vue.component(MintRange.name, MintRange);
};

var isDragging$1 = false;
var supportTouch$1 = 'ontouchstart' in window;

var draggable$1 = function(element, options) {
  var moveFn = function(event) {
    if (options.drag) {
      options.drag(supportTouch$1 ? event.changedTouches[0] || event.touches[0] : event);
    }
  };

  var endFn = function(event) {
    if (!supportTouch$1) {
      document.removeEventListener('mousemove', moveFn);
      document.removeEventListener('mouseup', endFn);
    }
    document.onselectstart = null;
    document.ondragstart = null;

    isDragging$1 = false;

    if (options.end) {
      options.end(supportTouch$1 ? event.changedTouches[0] || event.touches[0] : event);
    }
  };

  element.addEventListener(supportTouch$1 ? 'touchstart' : 'mousedown', function(event) {
    if (isDragging$1) { return; }
    document.onselectstart = function() { return false; };
    document.ondragstart = function() { return false; };

    if (!supportTouch$1) {
      document.addEventListener('mousemove', moveFn);
      document.addEventListener('mouseup', endFn);
    }
    isDragging$1 = true;

    if (options.start) {
      event.preventDefault();
      options.start(supportTouch$1 ? event.changedTouches[0] || event.touches[0] : event);
    }
  });

  if (supportTouch$1) {
    element.addEventListener('touchmove', moveFn);
    element.addEventListener('touchend', endFn);
    element.addEventListener('touchcancel', endFn);
  }
};

var docStyle = document.documentElement.style;
var engine;
var translate3d$1 = false;

if (window.opera && Object.prototype.toString.call(opera) === '[object Opera]') {
  engine = 'presto';
} else if ('MozAppearance' in docStyle) {
  engine = 'gecko';
} else if ('WebkitAppearance' in docStyle) {
  engine = 'webkit';
} else if (typeof navigator.cpuClass === 'string') {
  engine = 'trident';
}

var cssPrefix = {trident: '-ms-', gecko: '-moz-', webkit: '-webkit-', presto: '-o-'}[engine];

var vendorPrefix = {trident: 'ms', gecko: 'Moz', webkit: 'Webkit', presto: 'O'}[engine];

var helperElem = document.createElement('div');
var perspectiveProperty = vendorPrefix + 'Perspective';
var transformProperty = vendorPrefix + 'Transform';
var transformStyleName = cssPrefix + 'transform';
var transitionProperty = vendorPrefix + 'Transition';
var transitionStyleName = cssPrefix + 'transition';
var transitionEndProperty = vendorPrefix.toLowerCase() + 'TransitionEnd';

if (helperElem.style[perspectiveProperty] !== undefined) {
  translate3d$1 = true;
}

var getTranslate = function(element) {
  var result = {left: 0, top: 0};
  if (element === null || element.style === null) { return result; }

  var transform = element.style[transformProperty];
  var matches = /translate\(\s*(-?\d+(\.?\d+?)?)px,\s*(-?\d+(\.\d+)?)px\)\s*translateZ\(0px\)/g.exec(transform);
  if (matches) {
    result.left = +matches[1];
    result.top = +matches[3];
  }

  return result;
};

var translateElement = function(element, x, y) {
  if (x === null && y === null) { return; }

  if (element === null || element === undefined || element.style === null) { return; }

  if (!element.style[transformProperty] && x === 0 && y === 0) { return; }

  if (x === null || y === null) {
    var translate = getTranslate(element);
    if (x === null) {
      x = translate.left;
    }
    if (y === null) {
      y = translate.top;
    }
  }

  cancelTranslateElement(element);

  if (translate3d$1) {
    element.style[transformProperty] += ' translate(' + (x ? (x + 'px') : '0px') + ',' + (y ? (y + 'px') : '0px') + ') translateZ(0px)';
  } else {
    element.style[transformProperty] += ' translate(' + (x ? (x + 'px') : '0px') + ',' + (y ? (y + 'px') : '0px') + ')';
  }
};

var cancelTranslateElement = function(element) {
  if (element === null || element.style === null) { return; }
  var transformValue = element.style[transformProperty];
  if (transformValue) {
    transformValue = transformValue.replace(/translate\(\s*(-?\d+(\.?\d+?)?)px,\s*(-?\d+(\.\d+)?)px\)\s*translateZ\(0px\)/g, '');
    element.style[transformProperty] = transformValue;
  }
};

var translateUtil = {
  transformProperty: transformProperty,
  transformStyleName: transformStyleName,
  transitionProperty: transitionProperty,
  transitionStyleName: transitionStyleName,
  transitionEndProperty: transitionEndProperty,
  getElementTranslate: getTranslate,
  translateElement: translateElement,
  cancelTranslateElement: cancelTranslateElement
};

function broadcast(componentName, eventName, params) {
  this.$children.forEach(function (child) {
    var name = child.$options.componentName;

    if (name === componentName) {
      child.$emit.apply(child, [eventName].concat(params));
    } else {
      broadcast.apply(child, [componentName, eventName].concat(params));
    }
  });
}
var emitter = {
  methods: {
    dispatch: function dispatch(componentName, eventName, params) {
      var parent = this.$parent;
      var name = parent.$options.componentName;

      while (parent && (!name || name !== componentName)) {
        parent = parent.$parent;

        if (parent) {
          name = parent.$options.componentName;
        }
      }
      if (parent) {
        parent.$emit.apply(parent, [eventName].concat(params));
      }
    },
    broadcast: function broadcast(componentName, eventName, params) {
      broadcast.call(this, componentName, eventName, params);
    }
  }
};

/*
 * raf.js
 * https://github.com/ngryman/raf.js
 *
 * original requestAnimationFrame polyfill by Erik Möller
 * inspired from paul_irish gist and post
 *
 * Copyright (c) 2013 ngryman
 * Licensed under the MIT license.
 */

(function(window) {
	var lastTime = 0,
		vendors = ['webkit', 'moz'],
		requestAnimationFrame = window.requestAnimationFrame,
		cancelAnimationFrame = window.cancelAnimationFrame,
		i = vendors.length;

	// try to un-prefix existing raf
	while (--i >= 0 && !requestAnimationFrame) {
		requestAnimationFrame = window[vendors[i] + 'RequestAnimationFrame'];
		cancelAnimationFrame = window[vendors[i] + 'CancelAnimationFrame'];
	}

	// polyfill with setTimeout fallback
	// heavily inspired from @darius gist mod: https://gist.github.com/paulirish/1579671#comment-837945
	if (!requestAnimationFrame || !cancelAnimationFrame) {
		requestAnimationFrame = function(callback) {
			var now = +new Date(), nextTime = Math.max(lastTime + 16, now);
			return setTimeout(function() {
				callback(lastTime = nextTime);
			}, nextTime - now);
		};

		cancelAnimationFrame = clearTimeout;
	}

	// export to window
	window.requestAnimationFrame = requestAnimationFrame;
	window.cancelAnimationFrame = cancelAnimationFrame;
}(window));

var rotateElement = function(element, angle) {
  if (!element) { return; }
  var transformProperty = translateUtil.transformProperty;

  element.style[transformProperty] = element.style[transformProperty].replace(/rotateX\(.+?deg\)/gi, '') + " rotateX(" + angle + "deg)";
};

var ITEM_HEIGHT = 36;
var VISIBLE_ITEMS_ANGLE_MAP = {
  3: -45,
  5: -20,
  7: -15
};

var PickerSlot = { template: "<div class=\"picker-slot\" :class=\"classNames\" :style=\"flexStyle\"><div v-if=\"!divider\" ref=\"wrapper\" class=\"picker-slot-wrapper\" :class=\"{ dragging: dragging }\" :style=\"{ height: contentHeight + 'px' }\"><div class=\"picker-item\" v-for=\"itemValue in mutatingValues\" :class=\"{ 'picker-selected': itemValue === currentValue }\">{{ typeof itemValue === 'object' && itemValue[valueKey] ? itemValue[valueKey] : itemValue }}</div></div><div v-if=\"divider\">{{ content }}</div></div>",
  name: 'picker-slot',

  props: {
    values: {
      type: Array,
      default: function default$1() {
        return [];
      }
    },
    value: {},
    visibleItemCount: {
      type: Number,
      default: 5
    },
    valueKey: String,
    rotateEffect: {
      type: Boolean,
      default: false
    },
    divider: {
      type: Boolean,
      default: false
    },
    textAlign: {
      type: String,
      default: 'center'
    },
    flex: {},
    className: {},
    content: {}
  },

  data: function data() {
    return {
      currentValue: this.value,
      mutatingValues: this.values,
      dragging: false,
      animationFrameId: null
    };
  },

  mixins: [emitter],

  computed: {
    flexStyle: function flexStyle() {
      return {
        'flex': this.flex,
        '-webkit-box-flex': this.flex,
        '-moz-box-flex': this.flex,
        '-ms-flex': this.flex
      };
    },
    classNames: function classNames() {
      var PREFIX = 'picker-slot-';
      var resultArray = [];

      if (this.rotateEffect) {
        resultArray.push(PREFIX + 'absolute');
      }

      var textAlign = this.textAlign || 'center';
      resultArray.push(PREFIX + textAlign);

      if (this.divider) {
        resultArray.push(PREFIX + 'divider');
      }

      if (this.className) {
        resultArray.push(this.className);
      }

      return resultArray.join(' ');
    },
    contentHeight: function contentHeight() {
      return ITEM_HEIGHT * this.visibleItemCount;
    },
    valueIndex: function valueIndex() {
      return this.mutatingValues.indexOf(this.currentValue);
    },
    dragRange: function dragRange() {
      var values = this.mutatingValues;
      var visibleItemCount = this.visibleItemCount;

      return [ -ITEM_HEIGHT * (values.length - Math.ceil(visibleItemCount / 2)), ITEM_HEIGHT * Math.floor(visibleItemCount / 2) ];
    }
  },

  methods: {
    value2Translate: function value2Translate(value) {
      var values = this.mutatingValues;
      var valueIndex = values.indexOf(value);
      var offset = Math.floor(this.visibleItemCount / 2);

      if (valueIndex !== -1) {
        return (valueIndex - offset) * -ITEM_HEIGHT;
      }
    },

    translate2Value: function translate2Value(translate) {
      translate = Math.round(translate / ITEM_HEIGHT) * ITEM_HEIGHT;
      var index = -(translate - Math.floor(this.visibleItemCount / 2) * ITEM_HEIGHT) / ITEM_HEIGHT;

      return this.mutatingValues[index];
    },

    updateRotate: function(currentTranslate, pickerItems) {
      if (this.divider) { return; }
      var dragRange = this.dragRange;
      var wrapper = this.$refs.wrapper;

      if (!pickerItems) {
        pickerItems = wrapper.querySelectorAll('.picker-item');
      }

      if (currentTranslate === undefined) {
        currentTranslate = translateUtil.getElementTranslate(wrapper).top;
      }

      var itemsFit = Math.ceil(this.visibleItemCount / 2);
      var angleUnit = VISIBLE_ITEMS_ANGLE_MAP[this.visibleItemCount] || -20;

      [].forEach.call(pickerItems, function (item, index) {
        var itemOffsetTop = index * ITEM_HEIGHT;
        var translateOffset = dragRange[1] - currentTranslate;
        var itemOffset = itemOffsetTop - translateOffset;
        var percentage = itemOffset / ITEM_HEIGHT;

        var angle = angleUnit * percentage;
        if (angle > 180) { angle = 180; }
        if (angle < -180) { angle = -180; }

        rotateElement(item, angle);

        if (Math.abs(percentage) > itemsFit) {
          addClass(item, 'picker-item-far');
        } else {
          removeClass(item, 'picker-item-far');
        }
      });
    },

    planUpdateRotate: function() {
      var this$1 = this;

      var el = this.$refs.wrapper;
      cancelAnimationFrame(this.animationFrameId);

      this.animationFrameId = requestAnimationFrame(function () {
        this$1.updateRotate();
      });

      once(el, translateUtil.transitionEndProperty, function () {
        this$1.animationFrameId = null;
        cancelAnimationFrame(this$1.animationFrameId);
      });
    },

    initEvents: function initEvents() {
      var this$1 = this;

      var el = this.$refs.wrapper;
      var dragState = {};

      var velocityTranslate, prevTranslate, pickerItems;

      draggable$1(el, {
        start: function (event) {
          cancelAnimationFrame(this$1.animationFrameId);
          this$1.animationFrameId = null;
          dragState = {
            range: this$1.dragRange,
            start: new Date(),
            startLeft: event.pageX,
            startTop: event.pageY,
            startTranslateTop: translateUtil.getElementTranslate(el).top
          };
          pickerItems = el.querySelectorAll('.picker-item');
        },

        drag: function (event) {
          this$1.dragging = true;

          dragState.left = event.pageX;
          dragState.top = event.pageY;

          var deltaY = dragState.top - dragState.startTop;
          var translate = dragState.startTranslateTop + deltaY;

          translateUtil.translateElement(el, null, translate);

          velocityTranslate = translate - prevTranslate || translate;

          prevTranslate = translate;

          if (this$1.rotateEffect) {
            this$1.updateRotate(prevTranslate, pickerItems);
          }
        },

        end: function () {
          this$1.dragging = false;

          var momentumRatio = 7;
          var currentTranslate = translateUtil.getElementTranslate(el).top;
          var duration = new Date() - dragState.start;

          var momentumTranslate;
          if (duration < 300) {
            momentumTranslate = currentTranslate + velocityTranslate * momentumRatio;
          }

          var dragRange = dragState.range;

          this$1.$nextTick(function () {
            var translate;
            if (momentumTranslate) {
              translate = Math.round(momentumTranslate / ITEM_HEIGHT) * ITEM_HEIGHT;
            } else {
              translate = Math.round(currentTranslate / ITEM_HEIGHT) * ITEM_HEIGHT;
            }

            translate = Math.max(Math.min(translate, dragRange[1]), dragRange[0]);

            translateUtil.translateElement(el, null, translate);

            this$1.currentValue = this$1.translate2Value(translate);

            if (this$1.rotateEffect) {
              this$1.planUpdateRotate();
            }
          });

          dragState = {};
        }
      });
    },

    doOnValueChange: function doOnValueChange() {
      var value = this.currentValue;
      var wrapper = this.$refs.wrapper;

      translateUtil.translateElement(wrapper, null, this.value2Translate(value));
    },

    doOnValuesChange: function doOnValuesChange() {
      var el = this.$el;
      var items = el.querySelectorAll('.picker-item');
      [].forEach.call(items, function (item, index) {
        translateUtil.translateElement(item, null, ITEM_HEIGHT * index);
      });
      if (this.rotateEffect) {
        this.planUpdateRotate();
      }
    }
  },

  mounted: function mounted() {
    this.ready = true;
    this.$emit('input', this.currentValue);

    if (!this.divider) {
      this.initEvents();
      this.doOnValueChange();
    }

    if (this.rotateEffect) {
      this.doOnValuesChange();
    }
  },

  watch: {
    values: function values(val) {
      this.mutatingValues = val;
    },

    mutatingValues: function mutatingValues(val) {
      var this$1 = this;

      if (this.valueIndex === -1) {
        this.currentValue = (val || [])[0];
      }
      if (this.rotateEffect) {
        this.$nextTick(function () {
          this$1.doOnValuesChange();
        });
      }
    },
    currentValue: function currentValue(val) {
      this.doOnValueChange();
      if (this.rotateEffect) {
        this.planUpdateRotate();
      }
      this.$emit('input', val);
      this.dispatch('picker', 'slotValueChange', this);
    }
  }
};

var picker$1 = { template: "<div class=\"picker\" :class=\"{ 'picker-3d': rotateEffect }\"><div class=\"picker-toolbar\" v-if=\"showToolbar\"><slot></slot></div><div class=\"picker-items\"><picker-slot v-for=\"slot in slots\" :valuekey=\"valueKey\" :values=\"slot.values || []\" :text-align=\"slot.textAlign || 'center'\" :visible-item-count=\"visibleItemCount\" :class-name=\"slot.className\" :flex=\"slot.flex\" v-model=\"values[slot.valueIndex]\" :rotate-effect=\"rotateEffect\" :divider=\"slot.divider\" :content=\"slot.content\"></picker-slot><div class=\"picker-center-highlight\"></div></div></div>",
  name: 'ai-picker',

  componentName: 'picker',

  props: {
    slots: {
      type: Array
    },
    showToolbar: {
      type: Boolean,
      default: false
    },
    visibleItemCount: {
      type: Number,
      default: 5
    },
    valueKey: String,
    rotateEffect: {
      type: Boolean,
      default: false
    }
  },

  created: function created() {
    this.$on('slotValueChange', this.slotValueChange);
    var slots = this.slots || [];
    this.values = [];
    var values = this.values;
    var valueIndexCount = 0;
    slots.forEach(function(slot) {
      if (!slot.divider) {
        slot.valueIndex = valueIndexCount++;
        values[slot.valueIndex] = (slot.values || [])[slot.defaultIndex || 0];
      }
    });
  },

  methods: {
    slotValueChange: function slotValueChange() {
      this.$emit('change', this, this.values);
    },

    getSlot: function getSlot(slotIndex) {
      var slots = this.slots || [];
      var count = 0;
      var target;
      var children = this.$children.filter(function (child) { return child.$options.name === 'picker-slot'; });

      slots.forEach(function(slot, index) {
        if (!slot.divider) {
          if (slotIndex === count) {
            target = children[index];
          }
          count++;
        }
      });

      return target;
    },
    getSlotValue: function getSlotValue(index) {
      var slot = this.getSlot(index);
      if (slot) {
        return slot.value;
      }
      return null;
    },
    setSlotValue: function setSlotValue(index, value) {
      var slot = this.getSlot(index);
      if (slot) {
        slot.currentValue = value;
      }
    },
    getSlotValues: function getSlotValues(index) {
      var slot = this.getSlot(index);
      if (slot) {
        return slot.mutatingValues;
      }
      return null;
    },
    setSlotValues: function setSlotValues(index, values) {
      var slot = this.getSlot(index);
      if (slot) {
        slot.mutatingValues = values;
      }
    },
    getValues: function getValues() {
      return this.values;
    },
    setValues: function setValues(values) {
      var this$1 = this;

      var slotCount = this.slotCount;
      values = values || [];
      if (slotCount !== values.length) {
        throw new Error('values length is not equal slot count.');
      }
      values.forEach(function (value, index) {
        this$1.setSlotValue(index, value);
      });
    }
  },

  computed: {
    values: function values() {
      var slots = this.slots || [];
      var values = [];
      slots.forEach(function(slot) {
        if (!slot.divider) { values.push(slot.value); }
      });

      return values;
    },
    slotCount: function slotCount() {
      var slots = this.slots || [];
      var result = 0;
      slots.forEach(function(slot) {
        if (!slot.divider) { result++; }
      });
      return result;
    }
  },

  components: {
    PickerSlot: PickerSlot
  }
};

var Progress$1 = { template: "<div class=\"mt-progress\"><slot name=\"start\"></slot><div class=\"mt-progress-content\"><div class=\"mt-progress-runway\" :style=\"{ height: barHeight + 'px' }\"></div><div class=\"mt-progress-progress\" :style=\"{ width: value + '%', height: barHeight + 'px' }\"></div></div><slot name=\"end\"></slot></div>",
  name: 'ai-progress',

  props: {
    value: Number,
    barHeight: {
      type: Number,
      default: 3
    }
  }
};

var _Toast = { template: "<transition name=\"mint-toast-pop\"><div class=\"mint-toast\" v-show=\"visible\" :class=\"customClass\" :style=\"{ 'padding': iconClass === '' ? '10px' : '20px' }\"><i class=\"mint-toast-icon\" :class=\"iconClass\" v-if=\"iconClass !== ''\"></i> <span class=\"mint-toast-text\" :style=\"{ 'padding-top': iconClass === '' ? '0' : '10px' }\">{{ message }}</span></div></transition>",
  props: {
    message: String,
    className: {
      type: String,
      default: ''
    },
    position: {
      type: String,
      default: 'middle'
    },
    iconClass: {
      type: String,
      default: ''
    }
  },

  data: function data() {
    return {
      visible: false
    };
  },

  computed: {
    customClass: function customClass() {
      var classes = [];
      switch (this.position) {
        case 'top':
          classes.push('is-placetop');
          break;
        case 'bottom':
          classes.push('is-placebottom');
          break;
        default:
          classes.push('is-placemiddle');
      }
      classes.push(this.className);

      return classes.join(' ');
    }
  }
};

var ToastConstructor = Vue$1.extend(_Toast);
var toastPool = [];

var getAnInstance = function () {
  if (toastPool.length > 0) {
    var instance = toastPool[0];
    toastPool.splice(0, 1);
    return instance;
  }
  return new ToastConstructor({
    el: document.createElement('div')
  });
};

var returnAnInstance = function (instance) {
  if (instance) {
    toastPool.push(instance);
  }
};

var removeDom = function (event) {
  if (event.target.parentNode) {
    event.target.parentNode.removeChild(event.target);
  }
};

ToastConstructor.prototype.close = function() {
  this.visible = false;
  this.$el.addEventListener('transitionend', removeDom);
  this.closed = true;
  returnAnInstance(this);
};

var Toast$1 = function (options) {
  if ( options === void 0 ) options = {};

  var duration = options.duration || 3000;

  var instance = getAnInstance();
  instance.closed = false;
  clearTimeout(instance.timer);
  instance.message = typeof options === 'string' ? options : options.message;
  instance.position = options.position || 'middle';
  instance.className = options.className || '';
  instance.iconClass = options.iconClass || '';

  document.body.appendChild(instance.$el);
  Vue$1.nextTick(function() {
    instance.visible = true;
    instance.$el.removeEventListener('transitionend', removeDom);
    instance.timer = setTimeout(function() {
      if (instance.closed) { return; }
      instance.close();
    }, duration);
  });
  return instance;
};

var _Indicator = { template: "<transition name=\"mint-indicator\"><div class=\"mint-indicator\" v-show=\"visible\"><div class=\"mint-indicator-wrapper\" :style=\"{ 'padding': text ? '20px' : '15px' }\"><spinner class=\"mint-indicator-spin\" :type=\"convertedSpinnerType\" :size=\"32\"></spinner><span class=\"mint-indicator-text\" v-show=\"text\">{{ text }}</span></div><div class=\"mint-indicator-mask\" @touchmove.stop.prevent></div></div></transition>",
  data: function data() {
    return {
      visible: false
    };
  },

  components: {
    Spinner: Spinner$1
  },

  computed: {
    convertedSpinnerType: function convertedSpinnerType() {
      switch (this.spinnerType) {
        case 'double-bounce':
          return 1;
        case 'triple-bounce':
          return 2;
        case 'fading-circle':
          return 3;
        default:
          return 0;
      }
    }
  },

  props: {
    text: String,
    spinnerType: {
      type: String,
      default: 'snake'
    }
  }
};

var Indicator = Vue$1.extend(_Indicator);
var instance;
var timer;

var Indicator$1 = {
  open: function open(options) {
    if ( options === void 0 ) options = {};

    if (!instance) {
      instance = new Indicator({
        el: document.createElement('div')
      });
    }
    if (instance.visible) { return; }
    instance.text = typeof options === 'string' ? options : options.text || '';
    instance.spinnerType = options.spinnerType || 'snake';
    document.body.appendChild(instance.$el);
    if (timer) {
      clearTimeout(timer);
    }

    Vue$1.nextTick(function () {
      instance.visible = true;
    });
  },

  close: function close() {
    if (instance) {
      instance.visible = false;
      timer = setTimeout(function () {
        if (instance.$el) {
          instance.$el.style.display = 'none';
        }
      }, 400);
    }
  }
};

var CONFIRM_TEXT$1 = '确定';
var CANCEL_TEXT$1 = '取消';

var msgboxVue = { template: "<div class=\"mint-msgbox-wrapper\"><transition name=\"msgbox-bounce\"><div class=\"mint-msgbox\" v-show=\"value\"><div class=\"mint-msgbox-header\" v-if=\"title !== ''\"><div class=\"mint-msgbox-title\">{{ title }}</div></div><div class=\"mint-msgbox-content\" v-if=\"message !== ''\"><div class=\"mint-msgbox-message\" v-html=\"message\"></div><div class=\"mint-msgbox-input\" v-show=\"showInput\"><input v-model=\"inputValue\" :placeholder=\"inputPlaceholder\" ref=\"input\"><div class=\"mint-msgbox-errormsg\" :style=\"{ visibility: !!editorErrorMessage ? 'visible' : 'hidden' }\">{{ editorErrorMessage }}</div></div></div><div class=\"mint-msgbox-btns\"><button :class=\"[ cancelButtonClasses ]\" v-show=\"showCancelButton\" @click=\"handleAction('cancel')\">{{ cancelButtonText }}</button> <button :class=\"[ confirmButtonClasses ]\" v-show=\"showConfirmButton\" @click=\"handleAction('confirm')\">{{ confirmButtonText }}</button></div></div></transition></div>",
  mixins: [ Popup ],

  props: {
    modal: {
      default: true
    },
    showClose: {
      type: Boolean,
      default: true
    },
    lockScroll: {
      type: Boolean,
      default: false
    },
    closeOnClickModal: {
      default: true
    },
    closeOnPressEscape: {
      default: true
    },
    inputType: {
      type: String,
      default: 'text'
    }
  },

  computed: {
    confirmButtonClasses: function confirmButtonClasses() {
      var classes = 'mint-msgbox-btn mint-msgbox-confirm ' + this.confirmButtonClass;
      if (this.confirmButtonHighlight) {
        classes += ' mint-msgbox-confirm-highlight';
      }
      return classes;
    },
    cancelButtonClasses: function cancelButtonClasses() {
      var classes = 'mint-msgbox-btn mint-msgbox-cancel ' + this.cancelButtonClass;
      if (this.cancelButtonHighlight) {
        classes += ' mint-msgbox-cancel-highlight';
      }
      return classes;
    }
  },

  methods: {
    doClose: function doClose() {
      var this$1 = this;

      this.value = false;
      this._closing = true;

      this.onClose && this.onClose();

      setTimeout(function () {
        if (this$1.modal && this$1.bodyOverflow !== 'hidden') {
          document.body.style.overflow = this$1.bodyOverflow;
          document.body.style.paddingRight = this$1.bodyPaddingRight;
        }
        this$1.bodyOverflow = null;
        this$1.bodyPaddingRight = null;
      }, 200);
      this.opened = false;

      if (!this.transition) {
        this.doAfterClose();
      }
    },

    handleAction: function handleAction(action) {
      if (this.$type === 'prompt' && action === 'confirm' && !this.validate()) {
        return;
      }
      var callback = this.callback;
      this.value = false;
      callback(action);
    },

    validate: function validate() {
      if (this.$type === 'prompt') {
        var inputPattern = this.inputPattern;
        if (inputPattern && !inputPattern.test(this.inputValue || '')) {
          this.editorErrorMessage = this.inputErrorMessage || '输入的数据不合法!';
          this.$refs.input.classList.add('invalid');
          return false;
        }
        var inputValidator = this.inputValidator;
        if (typeof inputValidator === 'function') {
          var validateResult = inputValidator(this.inputValue);
          if (validateResult === false) {
            this.editorErrorMessage = this.inputErrorMessage || '输入的数据不合法!';
            this.$refs.input.classList.add('invalid');
            return false;
          }
          if (typeof validateResult === 'string') {
            this.editorErrorMessage = validateResult;
            return false;
          }
        }
      }
      this.editorErrorMessage = '';
      this.$refs.input.classList.remove('invalid');
      return true;
    },

    handleInputType: function handleInputType(val) {
      if (val === 'range' || !this.$refs.input) { return; }
      this.$refs.input.type = val;
    }
  },

  watch: {
    inputValue: function inputValue() {
      if (this.$type === 'prompt') {
        this.validate();
      }
    },

    value: function value(val) {
      var this$1 = this;

      this.handleInputType(this.inputType);
      if (val && this.$type === 'prompt') {
        setTimeout(function () {
          if (this$1.$refs.input) {
            this$1.$refs.input.focus();
          }
        }, 500);
      }
    },

    inputType: function inputType(val) {
      this.handleInputType(val);
    }
  },

  data: function data() {
    return {
      title: '',
      message: '',
      type: '',
      showInput: false,
      inputValue: null,
      inputPlaceholder: '',
      inputPattern: null,
      inputValidator: null,
      inputErrorMessage: '',
      showConfirmButton: true,
      showCancelButton: false,
      confirmButtonText: CONFIRM_TEXT$1,
      cancelButtonText: CANCEL_TEXT$1,
      confirmButtonClass: '',
      confirmButtonDisabled: false,
      cancelButtonClass: '',
      editorErrorMessage: null,
      callback: null
    };
  }
};

var CONFIRM_TEXT = '确定';
var CANCEL_TEXT = '取消';

var defaults = {
  title: '提示',
  message: '',
  type: '',
  showInput: false,
  showClose: true,
  modalFade: false,
  lockScroll: false,
  closeOnClickModal: true,
  inputValue: null,
  inputPlaceholder: '',
  inputPattern: null,
  inputValidator: null,
  inputErrorMessage: '',
  showConfirmButton: true,
  showCancelButton: false,
  confirmButtonPosition: 'right',
  confirmButtonHighlight: false,
  cancelButtonHighlight: false,
  confirmButtonText: CONFIRM_TEXT,
  cancelButtonText: CANCEL_TEXT,
  confirmButtonClass: '',
  cancelButtonClass: ''
};

var merge = function(target) {
  var arguments$1 = arguments;

  for (var i = 1, j = arguments.length; i < j; i++) {
    var source = arguments$1[i];
    for (var prop in source) {
      if (source.hasOwnProperty(prop)) {
        var value = source[prop];
        if (value !== undefined) {
          target[prop] = value;
        }
      }
    }
  }

  return target;
};

var MessageBoxConstructor = Vue$1.extend(msgboxVue);

var currentMsg;
var instance$1;
var msgQueue = [];

var defaultCallback = function (action) {
  if (currentMsg) {
    var callback = currentMsg.callback;
    if (typeof callback === 'function') {
      if (instance$1.showInput) {
        callback(instance$1.inputValue, action);
      } else {
        callback(action);
      }
    }
    if (currentMsg.resolve) {
      var $type = currentMsg.options.$type;
      if ($type === 'confirm' || $type === 'prompt') {
        if (action === 'confirm') {
          if (instance$1.showInput) {
            currentMsg.resolve({ value: instance$1.inputValue, action: action });
          } else {
            currentMsg.resolve(action);
          }
        } else if (action === 'cancel' && currentMsg.reject) {
          currentMsg.reject(action);
        }
      } else {
        currentMsg.resolve(action);
      }
    }
  }
};

var initInstance = function() {
  instance$1 = new MessageBoxConstructor({
    el: document.createElement('div')
  });

  instance$1.callback = defaultCallback;
};

var showNextMsg = function() {
  if (!instance$1) {
    initInstance();
  }

  if (!instance$1.value || instance$1.closeTimer) {
    if (msgQueue.length > 0) {
      currentMsg = msgQueue.shift();

      var options = currentMsg.options;
      for (var prop in options) {
        if (options.hasOwnProperty(prop)) {
          instance$1[prop] = options[prop];
        }
      }
      if (options.callback === undefined) {
        instance$1.callback = defaultCallback;
      }
      ['modal', 'showClose', 'closeOnClickModal', 'closeOnPressEscape'].forEach(function (prop) {
        if (instance$1[prop] === undefined) {
          instance$1[prop] = true;
        }
      });
      document.body.appendChild(instance$1.$el);

      Vue$1.nextTick(function () {
        instance$1.value = true;
      });
    }
  }
};

var MessageBox$1 = function(options, callback) {
  if (typeof options === 'string') {
    options = {
      title: options
    };
    if (arguments[1]) {
      options.message = arguments[1];
    }
    if (arguments[2]) {
      options.type = arguments[2];
    }
  } else if (options.callback && !callback) {
    callback = options.callback;
  }

  if (typeof Promise !== 'undefined') {
    return new Promise(function(resolve, reject) { // eslint-disable-line
      msgQueue.push({
        options: merge({}, defaults, MessageBox$1.defaults || {}, options),
        callback: callback,
        resolve: resolve,
        reject: reject
      });

      showNextMsg();
    });
  } else {
    msgQueue.push({
      options: merge({}, defaults, MessageBox$1.defaults || {}, options),
      callback: callback
    });

    showNextMsg();
  }
};

MessageBox$1.setDefaults = function(defaults) {
  MessageBox$1.defaults = defaults;
};

MessageBox$1.alert = function(message, title, options) {
  if (typeof title === 'object') {
    options = title;
    title = '';
  }
  return MessageBox$1(merge({
    title: title,
    message: message,
    $type: 'alert',
    closeOnPressEscape: false,
    closeOnClickModal: false
  }, options));
};

MessageBox$1.confirm = function(message, title, options) {
  if (typeof title === 'object') {
    options = title;
    title = '';
  }
  return MessageBox$1(merge({
    title: title,
    message: message,
    $type: 'confirm',
    showCancelButton: true
  }, options));
};

MessageBox$1.prompt = function(message, title, options) {
  if (typeof title === 'object') {
    options = title;
    title = '';
  }
  return MessageBox$1(merge({
    title: title,
    message: message,
    showCancelButton: true,
    showInput: true,
    $type: 'prompt'
  }, options));
};

MessageBox$1.close = function() {
  instance$1.value = false;
  msgQueue = [];
  currentMsg = null;
};

var ctx = '@@InfiniteScroll';

var throttle = function(fn, delay) {
  var now, lastExec, timer, context, args; //eslint-disable-line

  var execute = function() {
    fn.apply(context, args);
    lastExec = now;
  };

  return function() {
    context = this;
    args = arguments;

    now = Date.now();

    if (timer) {
      clearTimeout(timer);
      timer = null;
    }

    if (lastExec) {
      var diff = delay - (now - lastExec);
      if (diff < 0) {
        execute();
      } else {
        timer = setTimeout(function () {
          execute();
        }, diff);
      }
    } else {
      execute();
    }
  };
};

var getScrollTop$1 = function(element) {
  if (element === window) {
    return Math.max(window.pageYOffset || 0, document.documentElement.scrollTop);
  }

  return element.scrollTop;
};

var getComputedStyle$1 = document.defaultView.getComputedStyle;

var getScrollEventTarget$1 = function(element) {
  var currentNode = element;
  // bugfix, see http://w3help.org/zh-cn/causes/SD9013 and http://stackoverflow.com/questions/17016740/onscroll-function-is-not-working-for-chrome
  while (currentNode && currentNode.tagName !== 'HTML' && currentNode.tagName !== 'BODY' && currentNode.nodeType === 1) {
    var overflowY = getComputedStyle$1(currentNode).overflowY;
    if (overflowY === 'scroll' || overflowY === 'auto') {
      return currentNode;
    }
    currentNode = currentNode.parentNode;
  }
  return window;
};

var getVisibleHeight = function(element) {
  if (element === window) {
    return document.documentElement.clientHeight;
  }

  return element.clientHeight;
};

var getElementTop = function(element) {
  if (element === window) {
    return getScrollTop$1(window);
  }
  return element.getBoundingClientRect().top + getScrollTop$1(window);
};

var isAttached = function(element) {
  var currentNode = element.parentNode;
  while (currentNode) {
    if (currentNode.tagName === 'HTML') {
      return true;
    }
    if (currentNode.nodeType === 11) {
      return false;
    }
    currentNode = currentNode.parentNode;
  }
  return false;
};

var doBind = function() {
  if (this.binded) { return; } // eslint-disable-line
  this.binded = true;

  var directive = this;
  var element = directive.el;

  directive.scrollEventTarget = getScrollEventTarget$1(element);
  directive.scrollListener = throttle(doCheck.bind(directive), 200);
  directive.scrollEventTarget.addEventListener('scroll', directive.scrollListener);

  var disabledExpr = element.getAttribute('infinite-scroll-disabled');
  var disabled = false;

  if (disabledExpr) {
    this.vm.$watch(disabledExpr, function(value) {
      directive.disabled = value;
      if (!value && directive.immediateCheck) {
        doCheck.call(directive);
      }
    });
    disabled = Boolean(directive.vm[disabledExpr]);
  }
  directive.disabled = disabled;

  var distanceExpr = element.getAttribute('infinite-scroll-distance');
  var distance = 0;
  if (distanceExpr) {
    distance = Number(directive.vm[distanceExpr] || distanceExpr);
    if (isNaN(distance)) {
      distance = 0;
    }
  }
  directive.distance = distance;

  var immediateCheckExpr = element.getAttribute('infinite-scroll-immediate-check');
  var immediateCheck = true;
  if (immediateCheckExpr) {
    immediateCheck = Boolean(directive.vm[immediateCheckExpr]);
  }
  directive.immediateCheck = immediateCheck;

  if (immediateCheck) {
    doCheck.call(directive);
  }

  var eventName = element.getAttribute('infinite-scroll-listen-for-event');
  if (eventName) {
    directive.vm.$on(eventName, function() {
      doCheck.call(directive);
    });
  }
};

var doCheck = function(force) {
  var scrollEventTarget = this.scrollEventTarget;
  var element = this.el;
  var distance = this.distance;

  if (force !== true && this.disabled) { return; } //eslint-disable-line
  var viewportScrollTop = getScrollTop$1(scrollEventTarget);
  var viewportBottom = viewportScrollTop + getVisibleHeight(scrollEventTarget);

  var shouldTrigger = false;

  if (scrollEventTarget === element) {
    shouldTrigger = scrollEventTarget.scrollHeight - viewportBottom <= distance;
  } else {
    var elementBottom = getElementTop(element) - getElementTop(scrollEventTarget) + element.offsetHeight + viewportScrollTop;

    shouldTrigger = viewportBottom + distance >= elementBottom;
  }

  if (shouldTrigger && this.expression) {
    this.expression();
  }
};

var InfiniteScroll$2 = {
  bind: function bind(el, binding, vnode) {
    el[ctx] = {
      el: el,
      vm: vnode.context,
      expression: binding.value
    };
    var args = arguments;
    el[ctx].vm.$on('hook:mounted', function() {
      el[ctx].vm.$nextTick(function() {
        if (isAttached(el)) {
          doBind.call(el[ctx], args);
        }

        el[ctx].bindTryCount = 0;

        var tryBind = function() {
          if (el[ctx].bindTryCount > 10) { return; } //eslint-disable-line
          el[ctx].bindTryCount++;
          if (isAttached(el)) {
            doBind.call(el[ctx], args);
          } else {
            setTimeout(tryBind, 50);
          }
        };

        tryBind();
      });
    });
  },

  unbind: function unbind(el) {
    el[ctx].scrollEventTarget.removeEventListener('scroll', el[ctx].scrollListener);
  }
};

var install$2 = function(Vue) {
  Vue.directive('InfiniteScroll', InfiniteScroll$2);
};

if (window.Vue) {
  window.infiniteScroll = InfiniteScroll$2;
  Vue.use(install$2); // eslint-disable-line
}

InfiniteScroll$2.install = install$2;

var vueLazyload = createCommonjsModule(function (module, exports) {
/*!
 * Vue-Lazyload.js v1.0.0-rc5
 * (c) 2016 Awe <hilongjw@gmail.com>
 * Released under the MIT License.
 */
(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(Vue$1) :
    typeof undefined === 'function' && undefined.amd ? undefined(['vue'], factory) :
    (global.install = factory(global.Vue));
}(commonjsGlobal, (function (Vue) { 'use strict';

Vue = 'default' in Vue ? Vue['default'] : Vue;

var inBrowser = typeof window !== 'undefined';

function remove$1(arr, item) {
    if (!arr.length) { return; }
    var index = arr.indexOf(item);
    if (index > -1) { return arr.splice(index, 1); }
}

function some(arr, fn) {
    var has = false;
    for (var i = 0, len = arr.length; i < len; i++) {
        if (fn(arr[i])) {
            has = true;
            break;
        }
    }
    return has;
}

function find(arr, fn) {
    var item = void 0;
    for (var i = 0, len = arr.length; i < len; i++) {
        if (fn(arr[i])) {
            item = arr[i];
            break;
        }
    }
    return item;
}

function getDPR() {
    var scale = arguments.length <= 0 || arguments[0] === undefined ? 1 : arguments[0];

    if (!inBrowser) { return scale; }
    if (window.devicePixelRatio) {
        return window.devicePixelRatio;
    }
    return scale;
}

function supportWebp() {
    var support = true;
    var d = document;

    try {
        var el = d.createElement('object');
        el.type = 'image/webp';
        el.innerHTML = '!';
        d.body.appendChild(el);
        support = !el.offsetWidth;
        d.body.removeChild(el);
    } catch (err) {
        support = false;
    }

    return support;
}

function throttle(action, delay) {
    var timeout = null;
    var lastRun = 0;
    return function () {
        if (timeout) {
            return;
        }
        var elapsed = Date.now() - lastRun;
        var context = this;
        var args = arguments;
        var runCallback = function runCallback() {
            lastRun = Date.now();
            timeout = false;
            action.apply(context, args);
        };
        if (elapsed >= delay) {
            runCallback();
        } else {
            timeout = setTimeout(runCallback, delay);
        }
    };
}

var _ = {
    on: function on(el, type, func) {
        el.addEventListener(type, func);
    },
    off: function off(el, type, func) {
        el.removeEventListener(type, func);
    }
};

var loadImageAsync = function loadImageAsync(item, resolve, reject) {
    var image = new Image();
    image.src = item.src;

    image.onload = function () {
        resolve({
            naturalHeight: image.naturalHeight,
            naturalWidth: image.naturalWidth,
            src: item.src
        });
    };

    image.onerror = function (e) {
        reject(e);
    };
};

var _createClass$1 = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) { descriptor.writable = true; } Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) { defineProperties(Constructor.prototype, protoProps); } if (staticProps) { defineProperties(Constructor, staticProps); } return Constructor; }; }();

function _classCallCheck$1(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var imageCache = {};

var ReactiveListener = function () {
    function ReactiveListener(_ref) {
        var el = _ref.el;
        var src = _ref.src;
        var error = _ref.error;
        var loading = _ref.loading;
        var bindType = _ref.bindType;
        var $parent = _ref.$parent;
        var options = _ref.options;
        var elRenderer = _ref.elRenderer;

        _classCallCheck$1(this, ReactiveListener);

        this.el = el;
        this.src = src;
        this.error = error;
        this.loading = loading;
        this.bindType = bindType;
        this.attempt = 0;

        this.naturalHeight = 0;
        this.naturalWidth = 0;

        this.options = options;

        this.initState();

        this.rect = el.getBoundingClientRect();

        this.$parent = $parent;
        this.elRenderer = elRenderer;
    }

    _createClass$1(ReactiveListener, [{
        key: 'initState',
        value: function initState() {
            this.state = {
                error: false,
                loaded: false,
                rendered: false
            };
        }
    }, {
        key: 'update',
        value: function update(_ref2) {
            var src = _ref2.src;
            var loading = _ref2.loading;
            var error = _ref2.error;

            this.src = src;
            this.loading = loading;
            this.error = error;
            this.attempt = 0;
            this.initState();
        }
    }, {
        key: 'getRect',
        value: function getRect() {
            this.rect = this.el.getBoundingClientRect();
        }
    }, {
        key: 'checkInView',
        value: function checkInView() {
            this.getRect();
            return this.rect.top < window.innerHeight * this.options.preLoad && this.rect.bottom > 0 && this.rect.left < window.innerWidth * this.options.preLoad && this.rect.right > 0;
        }
    }, {
        key: 'load',
        value: function load() {
            var _this = this;

            if (this.attempt > this.options.attempt - 1 && this.state.error) {
                if (!this.options.slient) { console.log('error end'); }
                return;
            }

            if (this.state.loaded || imageCache[this.src]) {
                return this.render('loaded');
            }

            this.render('loading', true);

            this.attempt++;

            loadImageAsync({
                src: this.src
            }, function (data) {
                _this.naturalHeight = data.naturalHeight;
                _this.naturalWidth = data.naturalWidth;
                _this.state.loaded = true;
                _this.state.error = false;
                _this.render('loaded', true);
                imageCache[_this.src] = 1;
            }, function (err) {
                _this.state.error = true;
                _this.state.loaded = false;
                _this.render('error', true);
            });
        }
    }, {
        key: 'render',
        value: function render(state, notify) {
            var src = void 0;
            switch (state) {
                case 'loading':
                    src = this.loading;
                    break;
                case 'error':
                    src = this.error;
                    break;
                default:
                    src = this.src;
                    break;
            }

            this.elRenderer({
                el: this.el,
                bindType: this.bindType,
                src: src
            }, state, notify);
        }
    }, {
        key: 'destroy',
        value: function destroy() {
            this.el = null;
            this.src = null;
            this.error = null;
            this.loading = null;
            this.bindType = null;
            this.attempt = 0;
        }
    }]);

    return ReactiveListener;
}();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) { descriptor.writable = true; } Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) { defineProperties(Constructor.prototype, protoProps); } if (staticProps) { defineProperties(Constructor, staticProps); } return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var isVueNext = Vue.version.split('.')[0] === '2';
var DEFAULT_URL = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
var DEFAULT_EVENTS = ['scroll', 'wheel', 'mousewheel', 'resize', 'animationend', 'transitionend'];

var Lazy = function () {
    function Lazy(_ref) {
        var _this = this;

        var preLoad = _ref.preLoad;
        var error = _ref.error;
        var loading = _ref.loading;
        var attempt = _ref.attempt;
        var silent = _ref.silent;
        var scale = _ref.scale;
        var listenEvents = _ref.listenEvents;
        var hasbind = _ref.hasbind;
        var filter = _ref.filter;
        var adapter = _ref.adapter;

        _classCallCheck(this, Lazy);

        this.ListenerQueue = [];
        this.options = {
            silent: silent || true,
            preLoad: preLoad || 1.3,
            error: error || DEFAULT_URL,
            loading: loading || DEFAULT_URL,
            attempt: attempt || 3,
            scale: getDPR(scale),
            ListenEvents: listenEvents || DEFAULT_EVENTS,
            hasbind: false,
            supportWebp: supportWebp(),
            filter: filter || {},
            adapter: adapter || {}
        };
        this.initEvent();

        this.lazyLoadHandler = throttle(function () {
            var catIn = false;
            _this.ListenerQueue.forEach(function (listener) {
                if (listener.state.loaded) { return; }
                catIn = listener.checkInView();
                catIn && listener.load();
            });
        }, 300);
    }

    _createClass(Lazy, [{
        key: 'add',
        value: function add(el, binding, vnode) {
            var _this2 = this;

            if (some(this.ListenerQueue, function (item) {
                return item.el === el;
            })) {
                updateListener(el, binding);
                return Vue.nextTick(this.lazyLoadHandler);
            }

            var _valueFormater = this.valueFormater(binding.value);

            var src = _valueFormater.src;
            var loading = _valueFormater.loading;
            var error = _valueFormater.error;


            Vue.nextTick(function () {
                var $parent = vnode.context.$refs[Object.keys(binding.modifiers)[0]];
                $parent = $parent && $parent.$el || $parent;

                _this2.ListenerQueue.push(_this2.listenerFilter(new ReactiveListener({
                    bindType: binding.arg,
                    $parent: $parent,
                    el: el,
                    loading: loading,
                    error: error,
                    src: src,
                    elRenderer: _this2.elRenderer.bind(_this2),
                    options: _this2.options
                })));

                if (!_this2.ListenerQueue.length || _this2.options.hasbind) { return; }

                _this2.options.hasbind = true;
                _this2.initListen(window, true);
                $parent && _this2.initListen($parent, true);
                Vue.nextTick(function () {
                    _this2.lazyLoadHandler();
                });
            });
        }
    }, {
        key: 'update',
        value: function update(el, binding) {
            var _valueFormater2 = this.valueFormater(binding.value);

            var src = _valueFormater2.src;
            var loading = _valueFormater2.loading;
            var error = _valueFormater2.error;


            var exist = find(this.ListenerQueue, function (item) {
                return item.el === el;
            });

            exist && exist.src !== src && exist.update({
                src: src,
                loading: loading,
                error: error
            });
        }
    }, {
        key: 'remove',
        value: function remove(el) {
            if (!el) { return; }
            var existItem = find(this.ListenerQueue, function (item) {
                return item.el === el;
            });
            existItem && remove$1(this.ListenerQueue, existItem) && existItem.destroy();
            this.options.hasbind && !this.ListenerQueue.length && this.initListen(window, false);
        }
    }, {
        key: 'initListen',
        value: function initListen(el, start) {
            var _this3 = this;

            this.options.hasbind = start;
            this.options.ListenEvents.forEach(function (evt) {
                _[start ? 'on' : 'off'](el, evt, _this3.lazyLoadHandler);
            });
        }
    }, {
        key: 'initEvent',
        value: function initEvent() {
            this.Event = {
                listeners: {
                    loading: [],
                    loaded: [],
                    error: []
                },
                $on: function $on(event, func) {
                    this.listeners[event].push(func);
                },
                $once: function $once(event, func) {
                    var vm = this;
                    function on() {
                        vm.$off(event, on);
                        func.apply(vm, arguments);
                    }
                    this.$on(event, on);
                },
                $off: function $off(event, func) {
                    if (!func) {
                        this.listeners[event] = [];
                        return;
                    }
                    remove$1(this.listeners[event], func);
                },
                $emit: function $emit(event, context) {
                    this.listeners[event].forEach(function (func) {
                        func(context);
                    });
                }
            };
        }
    }, {
        key: 'elRenderer',
        value: function elRenderer(data, state, notify) {
            var el = data.el;
            var bindType = data.bindType;
            var src = data.src;


            if (bindType) {
                el.style[bindType] = 'url(' + src + ')';
            } else if (el.getAttribute('src') !== src) {
                el.setAttribute('src', src);
            }

            el.setAttribute('lazy', state);

            if (!notify) { return; }
            this.Event.$emit(state, data);
            this.options.adapter[state] && this.options.adapter[state](data, this.options);
        }
    }, {
        key: 'listenerFilter',
        value: function listenerFilter(listener) {
            if (this.options.filter.webp && this.options.supportWebp) {
                listener.src = this.options.filter.webp(listener, this.options);
            }
            if (this.options.filter.customer) {
                listener.src = this.options.filter.customer(listener, this.options);
            }
            return listener;
        }
    }, {
        key: 'valueFormater',
        value: function valueFormater(value) {
            var src = value;
            var loading = this.options.loading;
            var error = this.options.error;

            if (Vue.util.isObject(value)) {
                if (!value.src && !this.options.slient) { Vue.util.warn('Vue Lazyload warning: miss src with ' + value); }
                src = value.src;
                loading = value.loading || this.options.loading;
                error = value.error || this.options.error;
            }
            return {
                src: src,
                loading: loading,
                error: error
            };
        }
    }]);

    return Lazy;
}();

var index = (function (Vue$$1) {
    var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

    var lazy = new Lazy(options);
    var isVueNext = Vue$$1.version.split('.')[0] === '2';

    Vue$$1.prototype.$Lazyload = lazy;

    if (isVueNext) {
        Vue$$1.directive('lazy', {
            bind: lazy.add.bind(lazy),
            update: lazy.update.bind(lazy),
            componentUpdated: lazy.lazyLoadHandler.bind(lazy),
            unbind: lazy.remove.bind(lazy)
        });
    } else {
        Vue$$1.directive('lazy', {
            bind: lazy.lazyLoadHandler.bind(lazy),
            update: function update(newValue, oldValue) {
                Object.assign(this.$refs, this.$els);
                lazy.add(this.el, {
                    modifiers: this.modifiers || {},
                    arg: this.arg,
                    value: newValue,
                    oldValue: oldValue
                }, {
                    context: this
                });
            },
            unbind: function unbind() {
                lazy.remove(this.el);
            }
        });
    }
});

return index;

})));
});

var FORMAT_MAP = {
  Y: 'year',
  M: 'month',
  D: 'date',
  H: 'hour',
  m: 'minute'
};

var DatetimePicker$1 = { template: "<mt-popup v-model=\"visible\" position=\"bottom\" class=\"mint-datetime\"><mt-picker :slots=\"dateSlots\" @change=\"onChange\" :visible-item-count=\"7\" class=\"mint-datetime-picker\" ref=\"picker\" show-toolbar><span class=\"mint-datetime-action mint-datetime-cancel\" @click=\"visible = false\">{{ cancelText }}</span> <span class=\"mint-datetime-action mint-datetime-confirm\" @click=\"confirm\">{{ confirmText }}</span></mt-picker></mt-popup>",
  name: 'ai-datetime-picker',

  props: {
    cancelText: {
      type: String,
      default: '取消'
    },
    confirmText: {
      type: String,
      default: '确定'
    },
    type: {
      type: String,
      default: 'datetime'
    },
    startDate: {
      type: Date,
      default: function default$1() {
        return new Date(new Date().getFullYear() - 10, 0, 1);
      }
    },
    endDate: {
      type: Date,
      default: function default$2() {
        return new Date(new Date().getFullYear() + 10, 11, 31);
      }
    },
    startHour: {
      type: Number,
      default: 0
    },
    endHour: {
      type: Number,
      default: 23
    },
    yearFormat: {
      type: String,
      default: '{value}'
    },
    monthFormat: {
      type: String,
      default: '{value}'
    },
    dateFormat: {
      type: String,
      default: '{value}'
    },
    hourFormat: {
      type: String,
      default: '{value}'
    },
    minuteFormat: {
      type: String,
      default: '{value}'
    },
    value: null
  },

  data: function data() {
    return {
      visible: false,
      startYear: null,
      endYear: null,
      startMonth: 1,
      endMonth: 12,
      startDay: 1,
      endDay: 31,
      currentValue: null,
      selfTriggered: false,
      dateSlots: [],
      shortMonthDates: [],
      longMonthDates: [],
      febDates: [],
      leapFebDates: []
    };
  },

  components: {
    'mt-picker': picker$1,
    'mt-popup': popup$1
  },

  methods: {
    open: function open() {
      this.visible = true;
    },

    close: function close() {
      this.visible = false;
    },

    isLeapYear: function isLeapYear(year) {
      return (year % 400 === 0) || (year % 100 !== 0 && year % 4 === 0);
    },

    isShortMonth: function isShortMonth(month) {
      return [4, 6, 9, 11].indexOf(month) > -1;
    },

    getMonthEndDay: function getMonthEndDay(year, month) {
      if (this.isShortMonth(month)) {
        return 30;
      } else if (month === 2) {
        return this.isLeapYear(year) ? 29 : 28;
      } else {
        return 31;
      }
    },

    getTrueValue: function getTrueValue(formattedValue) {
      if (!formattedValue) { return; }
      while (isNaN(parseInt(formattedValue, 10))) {
        formattedValue = formattedValue.slice(1);
      }
      return parseInt(formattedValue, 10);
    },

    getValue: function getValue(values) {
      var this$1 = this;

      var value;
      if (this.type === 'time') {
        value = values.map(function (value) { return ('0' + this$1.getTrueValue(value)).slice(-2); }).join(':');
      } else {
        var year = this.getTrueValue(values[0]);
        var month = this.getTrueValue(values[1]);
        var date = this.getTrueValue(values[2]);
        var maxDate = this.getMonthEndDay(year, month);
        if (date > maxDate) {
          this.selfTriggered = true;
          date = 1;
        }
        var hour = this.typeStr.indexOf('H') > -1 ? this.getTrueValue(values[this.typeStr.indexOf('H')]) : 0;
        var minute = this.typeStr.indexOf('m') > -1 ? this.getTrueValue(values[this.typeStr.indexOf('m')]) : 0;
        value = new Date(year, month - 1, date, hour, minute);
      }
      return value;
    },

    onChange: function onChange(picker) {
      var values = picker.$children.filter(function (child) { return child.currentValue !== undefined; }).map(function (child) { return child.currentValue; });
      if (this.selfTriggered) {
        this.selfTriggered = false;
        return;
      }
      this.currentValue = this.getValue(values);
      this.handleValueChange();
    },

    fillValues: function fillValues(type, start, end) {
      var this$1 = this;

      var values = [];
      for (var i = start; i <= end; i++) {
        if (i < 10) {
          values.push(this$1[((FORMAT_MAP[type]) + "Format")].replace('{value}', ('0' + i).slice(-2)));
        } else {
          values.push(this$1[((FORMAT_MAP[type]) + "Format")].replace('{value}', i));
        }
      }
      return values;
    },

    pushSlots: function pushSlots(slots, type, start, end) {
      slots.push({
        flex: 1,
        values: this.fillValues(type, start, end)
      });
    },

    generateSlots: function generateSlots() {
      var this$1 = this;

      var dateSlots = [];
      var INTERVAL_MAP = {
        Y: this.rims.year,
        M: this.rims.month,
        D: this.rims.date,
        H: this.rims.hour,
        m: this.rims.min
      };
      var typesArr = this.typeStr.split('');
      typesArr.forEach(function (type) {
        if (INTERVAL_MAP[type]) {
          this$1.pushSlots.apply(null, [dateSlots, type].concat(INTERVAL_MAP[type]));
        }
      });
      if (this.typeStr === 'Hm') {
        dateSlots.splice(1, 0, {
          divider: true,
          content: ':'
        });
      }
      this.dateSlots = dateSlots;
      this.handleExceededValue();
    },

    handleExceededValue: function handleExceededValue() {
      var this$1 = this;

      var values = [];
      if (this.type === 'time') {
        values = this.currentValue.split(':');
      } else {
        values = [
          this.yearFormat.replace('{value}', this.getYear(this.currentValue)),
          this.monthFormat.replace('{value}', ('0' + this.getMonth(this.currentValue)).slice(-2)),
          this.dateFormat.replace('{value}', ('0' + this.getDate(this.currentValue)).slice(-2))
        ];
        if (this.type === 'datetime') {
          values.push(
            this.hourFormat.replace('{value}', ('0' + this.getHour(this.currentValue)).slice(-2)),
            this.minuteFormat.replace('{value}', ('0' + this.getMinute(this.currentValue)).slice(-2))
          );
        }
      }
      this.dateSlots.filter(function (child) { return child.values !== undefined; })
        .map(function (slot) { return slot.values; }).forEach(function (slotValues, index) {
          if (slotValues.indexOf(values[index]) === -1) {
            values[index] = slotValues[0];
          }
        });
      this.$nextTick(function () {
        this$1.setSlotsByValues(values);
      });
    },

    setSlotsByValues: function setSlotsByValues(values) {
      var setSlotValue = this.$refs.picker.setSlotValue;
      if (this.type === 'time') {
        setSlotValue(0, values[0]);
        setSlotValue(1, values[1]);
      }
      if (this.type !== 'time') {
        setSlotValue(0, values[0]);
        setSlotValue(1, values[1]);
        setSlotValue(2, values[2]);
        if (this.type === 'datetime') {
          setSlotValue(3, values[3]);
          setSlotValue(4, values[4]);
        }
      }
      [].forEach.call(this.$refs.picker.$children, function (child) { return child.doOnValueChange(); });
    },

    rimDetect: function rimDetect(result, rim) {
      var position = rim === 'start' ? 0 : 1;
      var rimDate = rim === 'start' ? this.startDate : this.endDate;
      if (this.getYear(this.currentValue) === rimDate.getFullYear()) {
        result.month[position] = rimDate.getMonth() + 1;
        if (this.getMonth(this.currentValue) === rimDate.getMonth() + 1) {
          result.date[position] = rimDate.getDate();
          if (this.getDate(this.currentValue) === rimDate.getDate()) {
            result.hour[position] = rimDate.getHours();
            if (this.getHour(this.currentValue) === rimDate.getHours()) {
              result.min[position] = rimDate.getMinutes();
            }
          }
        }
      }
    },

    isDateString: function isDateString(str) {
      return /\d{4}(\-|\/|.)\d{1,2}\1\d{1,2}/.test(str);
    },

    getYear: function getYear(value) {
      return this.isDateString(value) ? value.split(' ')[0].split(/-|\/|\./)[0] : value.getFullYear();
    },

    getMonth: function getMonth(value) {
      return this.isDateString(value) ? value.split(' ')[0].split(/-|\/|\./)[1] : value.getMonth() + 1;
    },

    getDate: function getDate(value) {
      return this.isDateString(value) ? value.split(' ')[0].split(/-|\/|\./)[2] : value.getDate();
    },

    getHour: function getHour(value) {
      if (this.isDateString(value)) {
        var str = value.split(' ')[1] || '00:00:00';
        return str.split(':')[0];
      }
      return value.getHours();
    },

    getMinute: function getMinute(value) {
      if (this.isDateString(value)) {
        var str = value.split(' ')[1] || '00:00:00';
        return str.split(':')[1];
      }
      return value.getMinutes();
    },

    confirm: function confirm() {
      this.visible = false;
      this.$emit('confirm', this.currentValue);
    },

    handleValueChange: function handleValueChange() {
      this.$emit('input', this.currentValue);
    }
  },

  computed: {
    rims: function rims() {
      if (!this.currentValue) { return { year: [], month: [], date: [], hour: [], min: [] }; }
      var result;
      if (this.type === 'time') {
        result = {
          hour: [this.startHour, this.endHour],
          min: [0, 59]
        };
        return result;
      }
      result = {
        year: [this.startDate.getFullYear(), this.endDate.getFullYear()],
        month: [1, 12],
        date: [1, this.getMonthEndDay(this.getYear(this.currentValue), this.getMonth(this.currentValue))],
        hour: [0, 23],
        min: [0, 59]
      };
      this.rimDetect(result, 'start');
      this.rimDetect(result, 'end');
      return result;
    },

    typeStr: function typeStr() {
      if (this.type === 'time') {
        return 'Hm';
      } else if (this.type === 'date') {
        return 'YMD';
      } else {
        return 'YMDHm';
      }
    }
  },

  watch: {
    value: function value(val) {
      this.currentValue = val;
    },

    rims: function rims() {
      this.generateSlots();
    }
  },

  mounted: function mounted() {
    this.currentValue = this.value;
    if (!this.value) {
      if (this.type.indexOf('date') > -1) {
        this.currentValue = this.startDate;
      } else {
        this.currentValue = (('0' + this.startHour).slice(-2)) + ":00";
      }
    }
    this.generateSlots();
  }
};

var IndexList$1 = { template: "<div class=\"mint-indexlist\"><ul class=\"mint-indexlist-content\" ref=\"content\" :style=\"{ 'height': currentHeight + 'px', 'margin-right': navWidth + 'px'}\"><slot></slot></ul><div class=\"mint-indexlist-nav\" @touchstart=\"handleTouchStart\" ref=\"nav\"><ul class=\"mint-indexlist-navlist\"><li class=\"mint-indexlist-navitem\" v-for=\"section in sections\">{{ section.index }}</li></ul></div><div class=\"mint-indexlist-indicator\" v-if=\"showIndicator\" v-show=\"moving\">{{ currentIndicator }}</div></div>",
  name: 'ai-index-list',

  props: {
    height: Number,
    showIndicator: {
      type: Boolean,
      default: true
    }
  },

  data: function data() {
    return {
      sections: [],
      navWidth: 0,
      indicatorTime: null,
      moving: false,
      firstSection: null,
      currentIndicator: '',
      currentHeight: this.height
    };
  },

  watch: {
    sections: function sections() {
      this.init();
    }
  },

  methods: {
    init: function init() {
      var this$1 = this;

      this.$nextTick(function () {
        this$1.navWidth = this$1.$refs.nav.clientWidth;
      });
      var listItems = this.$refs.content.getElementsByTagName('li');
      if (listItems.length > 0) {
        this.firstSection = listItems[0];
      }
    },

    handleTouchStart: function handleTouchStart(e) {
      if (e.target.tagName !== 'LI') {
        return;
      }
      this.scrollList(e.changedTouches[0].clientY);
      if (this.indicatorTime) {
        clearTimeout(this.indicatorTime);
      }
      this.moving = true;
      window.addEventListener('touchmove', this.handleTouchMove);
      window.addEventListener('touchend', this.handleTouchEnd);
    },

    handleTouchMove: function handleTouchMove(e) {
      e.preventDefault();
      this.scrollList(e.changedTouches[0].clientY);
    },

    handleTouchEnd: function handleTouchEnd() {
      var this$1 = this;

      this.indicatorTime = setTimeout(function () {
        this$1.moving = false;
        this$1.currentIndicator = '';
      }, 500);
      window.removeEventListener('touchmove', this.handleTouchMove);
      window.removeEventListener('touchend', this.handleTouchEnd);
    },

    scrollList: function scrollList(y) {
      var currentItem = document.elementFromPoint(document.body.clientWidth - 10, y);
      if (!currentItem || !currentItem.classList.contains('mint-indexlist-navitem')) {
        return;
      }
      this.currentIndicator = currentItem.innerText;
      var targets = this.sections.filter(function (section) { return section.index === currentItem.innerText; });
      var targetDOM;
      if (targets.length > 0) {
        targetDOM = targets[0].$el;
        this.$refs.content.scrollTop = targetDOM.getBoundingClientRect().top - this.firstSection.getBoundingClientRect().top;
      }
    }
  },

  mounted: function mounted() {
    if (!this.currentHeight) {
      this.currentHeight = document.documentElement.clientHeight - this.$refs.content.getBoundingClientRect().top;
    }
    this.init();
  }
};

var IndexSection$1 = { template: "<li class=\"mint-indexsection\"><p class=\"mint-indexsection-index\">{{ index }}</p><ul><slot></slot></ul></li>",
  name: 'ai-index-section',

  props: {
    index: {
      type: String,
      required: true
    }
  },

  mounted: function mounted() {
    this.$parent.sections.push(this);
  },

  beforeDestroy: function beforeDestroy() {
    var index = this.$parent.sections.indexOf(this);
    if (index > -1) {
      this.$parent.sections.splice(index, 1);
    }
  }
};

var PaletteButton$1 = { template: "<div class=\"mint-palette-button\" :class=\"{ expand: expanded, 'mint-palette-button-active': transforming }\" @animationend=\"onMainAnimationEnd\" @webkitanimationend=\"onMainAnimationEnd\" @mozanimationend=\"onMainAnimationEnd\"><div class=\"mint-sub-button-container\"><slot></slot></div><div @touchstart=\"toggle\" class=\"mint-main-button\" :style=\"mainButtonStyle\">{{content}}</div></div>",
  name: 'ai-palette-button',
  data: function() {
    return {
      transforming: false,    // 是否正在执行动画
      expanded: false           // 是否已经展开子按钮
    };
  },
  props: {
    content: {
      type: String,
      default: ''
    },
    offset: {
      type: Number,           // 扇面偏移角，默认是四分之π，配合默认方向lt
      default: Math.PI / 4
    },
    direction: {
      type: String,
      default: 'lt'           // lt t rt this.radius rb b lb l 取值有8个方向，左上、上、右上、右、右下、下、左下、左，默认为左上
    },
    radius: {
      type: Number,
      default: 90
    },
    mainButtonStyle: {
      type: String,           // 应用到 mint-main-button 上的 class
      default: ''
    }
  },
  methods: {
    toggle: function toggle(event) {
      if (!this.transforming) {
        if (this.expanded) {
          this.collapse(event);
        } else {
          this.expand(event);
        }
      }
    },
    onMainAnimationEnd: function onMainAnimationEnd(event) {
      this.transforming = false;
      this.$emit('expanded');
    },
    expand: function expand(event) {
      this.expanded = true;
      this.transforming = true;
      this.$emit('expand', event);
    },
    collapse: function collapse(event) {
      this.expanded = false;
      this.$emit('collapse', event);
    }
  },
  mounted: function mounted() {
    var this$1 = this;

    this.slotChildren = [];
    for (var i = 0; i < this.$slots.default.length; i++) {
      if (this$1.$slots.default[i].elm.nodeType !== 3) {
        this$1.slotChildren.push(this$1.$slots.default[i]);
      }
    }

    var css = '';
    var direction_arc = Math.PI * (3 + Math.max(['lt', 't', 'rt', 'r', 'rb', 'b', 'lb', 'l'].indexOf(this.direction), 0)) / 4;
    for (var i$1 = 0; i$1 < this.slotChildren.length; i$1++) {
      var arc = (Math.PI - this$1.offset * 2) / (this$1.slotChildren.length - 1) * i$1 + this$1.offset + direction_arc;
      var x = Math.cos(arc) * this$1.radius;
      var y = Math.sin(arc) * this$1.radius;
      var item_css = '.expand .palette-button-' + this$1._uid + '-sub-' + i$1 + '{transform:translate(' + x + 'px,' + y + 'px) rotate(720deg);transition-delay:' + 0.03 * i$1 + 's}';
      css += item_css;

      this$1.slotChildren[i$1].elm.className += (' palette-button-' + this$1._uid + '-sub-' + i$1);
    }

    this.styleNode = document.createElement('style');
    this.styleNode.type = 'text/css';
    this.styleNode.rel = 'stylesheet';
    this.styleNode.title = 'palette button style';
    this.styleNode.appendChild(document.createTextNode(css));
    document.getElementsByTagName('head')[0].appendChild(this.styleNode);
  },
  destroyed: function destroyed() {
    if (this.styleNode) {
      this.styleNode.parentNode.removeChild(this.styleNode);
    }
  }
};

var MenuBlock$1 = { template: "<div class=\"mint-menu-block\"><div class=\"icons\" :style=\"{'background-color':color}\"><i class=\"aicon\" :class=\"'aicon-'+icon\"></i></div><span><slot></slot></span></div>",
    name: 'ai-menu-block',
    props:{
        icon:{
            type:String,
            default:""
        },
        color:{
            type:String,
            default:''
        }
    }
};

var _loading = "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2032%2032%22%20width%3D%2232%22%20height%3D%2232%22%20fill%3D%22white%22%3E%20%20%3Cpath%20opacity%3D%22.25%22%20d%3D%22M16%200%20A16%2016%200%200%200%2016%2032%20A16%2016%200%200%200%2016%200%20M16%204%20A12%2012%200%200%201%2016%2028%20A12%2012%200%200%201%2016%204%22%2F%3E%20%20%3Cpath%20d%3D%22M16%200%20A16%2016%200%200%201%2032%2016%20L28%2016%20A12%2012%200%200%200%2016%204z%22%3E%20%20%20%20%3CanimateTransform%20attributeName%3D%22transform%22%20type%3D%22rotate%22%20from%3D%220%2016%2016%22%20to%3D%22360%2016%2016%22%20dur%3D%220.8s%22%20repeatCount%3D%22indefinite%22%20%2F%3E%20%20%3C%2Fpath%3E%3C%2Fsvg%3E";

var install$1 = function(Vue) {
  if (install$1.installed) { return; }

  Vue.component(Header$1.name, Header$1);
  Vue.component(Button$1.name, Button$1);
  Vue.component(XCell$1.name, XCell$1);
  Vue.component(CellSwipe$1.name, CellSwipe$1);
  Vue.component(cellSpacing.name, cellSpacing);
  Vue.component(Field$1.name, Field$1);
  Vue.component(Badge$1.name, Badge$1);
  Vue.component(TabContainer.name, TabContainer);
  Vue.component(Spinner$1.name, Spinner$1);
  Vue.component(TabItem$1.name, TabItem$1);
  Vue.component(TabContainerItem$1.name, TabContainerItem$1);
  Vue.component(TabContainer$2.name, TabContainer$2);
  Vue.component(Navbar$1.name, Navbar$1);
  Vue.component(Tabbar$1.name, Tabbar$1);
  Vue.component(Search$1.name, Search$1);
  Vue.component(CheckboxGroup$1.name, CheckboxGroup$1);
  Vue.component(Checkbox$1.name, Checkbox$1);
  Vue.component(RadioGroup$1.name, RadioGroup$1);
  Vue.component(Radio$1.name, Radio$1);
  Vue.component(RadioButton$1.name, RadioButton$1);
  Vue.component(InputNumber$1.name, InputNumber$1);
  Vue.component(Loadmore$1.name, Loadmore$1);
  Vue.component(Actionsheet$1.name, Actionsheet$1);
  Vue.component(popup$1.name, popup$1);
  Vue.component(Swipe$1.name, Swipe$1);
  Vue.component(SwipeItem$1.name, SwipeItem$1);
  Vue.component(MintRange.name, MintRange);
  Vue.component(picker$1.name, picker$1);
  Vue.component(Progress$1.name, Progress$1);
  Vue.component(DatetimePicker$1.name, DatetimePicker$1);
  Vue.component(IndexList$1.name, IndexList$1);
  Vue.component(IndexSection$1.name, IndexSection$1);
  Vue.component(PaletteButton$1.name, PaletteButton$1);
  Vue.component(MenuBlock$1.name, MenuBlock$1);
  Vue.use(InfiniteScroll$2);
  Vue.use(vueLazyload, {
    loading: _loading,
    try: 3
  });

  Vue.$messagebox = Vue.prototype.$messagebox = MessageBox$1;
  Vue.$toast = Vue.prototype.$toast = Toast$1;
  Vue.$indicator = Vue.prototype.$indicator = Indicator$1;
};

// auto install
if (typeof window !== 'undefined' && window.Vue) {
  install$1(window.Vue);
}

var MINT = {
  install: install$1,
  version: '0.0.1',
  Header: Header$1,
  Button: Button$1,
  Cell: XCell$1,
  CellSwipe: CellSwipe$1,
  CellSpacing: cellSpacing,
  Field: Field$1,
  Badge: Badge$1,
  Switch: TabContainer,
  Spinner: Spinner$1,
  TabItem: TabItem$1,
  TabContainerItem: TabContainerItem$1,
  TabContainer: TabContainer$2,
  Navbar: Navbar$1,
  Tabbar: Tabbar$1,
  Search: Search$1,
  CheckboxGroup: CheckboxGroup$1,
  Checkbox: Checkbox$1,
  RadioGroup: RadioGroup$1,
  Radio: Radio$1,
  RadioButton: RadioButton$1,
  InputNumber: InputNumber$1,
  Loadmore: Loadmore$1,
  Actionsheet: Actionsheet$1,
  Popup: popup$1,
  Swipe: Swipe$1,
  SwipeItem: SwipeItem$1,
  Range: MintRange,
  Picker: picker$1,
  Progress: Progress$1,
  Toast: Toast$1,
  Indicator: Indicator$1,
  MessageBox: MessageBox$1,
  InfiniteScroll: InfiniteScroll$2,
  Lazyload: vueLazyload,
  DatetimePicker: DatetimePicker$1,
  IndexList: IndexList$1,
  IndexSection: IndexSection$1,
  PaletteButton: PaletteButton$1,
  MenuBlock: MenuBlock$1
};

return MINT;

})));
