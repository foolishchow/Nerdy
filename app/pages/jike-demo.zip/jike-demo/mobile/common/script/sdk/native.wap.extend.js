(function() {
    //global route config
    window.Router = window.Router || {};
    Router = {
        "root": {
            "name": "root",
            "url": "../platform/root/prd",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        },
        "home": {
            "name": "home",
            "url": "my/my",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "frame"
        },
        "index": {
            "name": "index_view",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "frameGroup",
            "tabs": [{
                "url": "test/test",
                "text": "测试页",
                "selected": true,
                "name": "indexFrame_test",
                "scroll": false,
                "reload": true,
                "bounces": false
            },
            {
                "url": "test/test1",
                "text": "测试页1",
                "name": "indexFrame_test1"
            }]
        },
        "mytask": {
            "name": "mytask_view",
            "url": "task/mytask",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        },
        "tasklist": {
            "name": "tasklist_view",
            "url": "task/tasklist",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        },
        "newtask": {
            "name": "newtask_view",
            "url": "task/newtask",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        },
        "taskdetail": {
            "name": "taskdetail_view",
            "url": "task/taskdetail",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        },
        "mytaskdetail": {
            "name": "mytaskdetail_view",
            "url": "task/mytaskdetail",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        },
        "manager": {
            "name": "manager_view",
            "url": "manager/manager",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        },
        "userlist": {
            "name": "userlist_view",
            "url": "user/userlist",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        },
        "adduser": {
            "name": "adduser_view",
            "url": "user/adduser",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        },
        "departlist": {
            "name": "departlist_view",
            "url": "sys/departlist",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        },
        "adddepart": {
            "name": "adddepart_view",
            "url": "sys/adddepart",
            "nav": "common",
            "pageParam": {},
            "animation": "left",
            "type": "window"
        }
    };

    //interface
    window.InterFace = window.InterFace || {};
    InterFace = {
        "index": {
            "index1": "/home/goodsList",
            "index2": "/home/goodsList"
        },
        "root": {
            "rootData": "/root/getRootData"
        },
        "cart": {
            "checkCart": "/cart/checkCart",
            "cartList": "/cart/getCartList",
            "addCart": "/cart/addCart",
            "delCart": "/cart/deleteCart",
            "updateCart": "/cart/updateCart"
        },
        "order": {
            "orderId": "/order/getOrderId",
            "orderList": "/order/getOrderList",
            "myOrder": "/order/getMyOrder",
            "orderDetail": "/order/getOrderDetail",
            "saveOrder": "/order/saveOrder",
            "modifyStatus": "/order/modifyOrderStatus",
            "sendOrder": "/order/sendOrder",
            "modifyPrice": "/order/modifyOrderPrice",
            "cancelOrder": "/order/cancelOrder"
        },
        "product": "/product/{productId}/detail",
        "brand": "/brand/getBrandList",
        "address": {
            "getAddressList": "/customer/postaddresslist",
            "addAddress": "/customer/modifypostaddress",
            "delAddress": "/customer/deletepostaddress"
        }
    };
    //message
    window.MESSAGE = window.MESSAGE || {};
    MESSAGE = {
        "2222": "hahahah",
        "300005": "您选择的商品购物车中已不存在",
        "300006": "您选择的商品购物车仅存在部分",
        "chooseGoods": "请选择商品",
        "confirmDelate": "你确定要删除{1}{0}么？"
    };

})();(function() {
    window.AI = window.AI || {};
    if ("${ai_evn}".length == 3) {
        AI = {
            app_url: '${app_url}',
            InterFaceIp: '${InterFaceIp}',
            InterfaceUrl: 'jike-platform',
            //个人资料头像上传url
            // UploadInterfaceUrl: '/mobile/upload/file',
            // 最长登录天数
            // longestDay: 3,
            // 个人头像前置路径
            // headpicPreffix: '${headpicPreffix}/mobile/upload/showImg?remoteFile=',
            // headpicPreffix: '${headpicPreffix}/JikeMobile/ImgUpDown/img?remoteFile=',
            // InterfaceName: '/mobile'
        }
    } else {
        AI = {
            //静态页面请求地址
            // app_url: 'http://192.168.0.150:9300',
            app_url: 'http://10.21.67.88:9200',
            wap_url: 'http://192.168.2.136:9100',
            // 后台接口请求地址
            // InterFaceIp: 'http://10.21.67.100:8080/',
            InterfaceUrl: 'jike-platform',
            // 上传文件接口
            // UploadInterfaceUrl: '/mobile/upload/file',
            //个人资料头像上传url
            // UploadInterfaceUrl:'/mobile/upload/file',
            // 最长登录天数
            // longestDay: 3,
            // 个人头像前置路径
            // headpicPreffix: 'http://10.20.16.74:8282/mobile/upload/showImg?remoteFile=',
            // headpicPreffix:'http://10.20.16.74:8181/JikeMobile/ImgUpDown/img?remoteFile=',
            // InterfaceName: '/mobile'
        }

    }
})();



(function() {
    window.alert = function(o) {
        if(navigator.userAgent.match(/ai-app-cloud/)){
            J(function() {
                api.alert({ msg: JSON.stringify(o) })
            });
        }else{
            if((typeof o).toLowerCase() == 'string' ){
                Vue.$messagebox.alert(o, '提示');
            }else{
                Vue.$messagebox.alert(JSON.stringify(o), '提示');
            }
        }
    };
    window.toast = window.info = window.msg = function(o) {
        if(navigator.userAgent.match(/ai-app-cloud/)){
            J(function() {
                api.toast({ msg: o })
            });
        }else{
            if((typeof o).toLowerCase() == 'string' ){
                Vue.$toast(o);
            }else{
                Vue.$toast(JSON.stringify(o));
            }
        }
    }
})();
(function(){
    Date.prototype.Format = function(fmt) {
        fmt = fmt ? fmt : "yyyy-MM-dd HH:mm:ss"; //HH:mm:ss
        var o = {
            "M+": this.getMonth() + 1,
            /*月份*/
            "d+": this.getDate(),
            /*日*/
            "H+": this.getHours(),
            /*小时*/
            "h+": this.getHours() % 12,
            /*小时*/
            "m+": this.getMinutes(),
            /*分*/
            "s+": this.getSeconds(),
            /*秒*/
            "q+": Math.floor((this.getMonth() + 3) / 3),
            /*季度*/
            "S": this.getMilliseconds() /*毫秒*/
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        if (/(Y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            }
        }
        return fmt;
    };
    Date.prototype.secondBefore = function(num){
        var time = (this.getTime() / 1000 - num - 1 ) * 1000;
        this.setTime(time)
        return this;
    };
    Date.prototype.secondAfter = function(num){
        var time = (this.getTime() / 1000 + parseInt(num) ) * 1000;
        this.setTime(time);
        return this;
    };
    Date.prototype.mimuteBefore = function(num){
        var time = this.getTime()  - num * 1000 * 60 ;
        this.setTime(time)
        return this;
    };
    Date.prototype.mimuteAfter = function(num){
        var time = this.getTime()  + parseInt(num) * 60 * 1000 ;
        this.setTime(time);
        return this;
    };
    Date.prototype.hourBefore = function(num){
        var time = this.getTime()  - num * 1000 * 60 * 60 ;
        this.setTime(time)
        return this;
    };
    Date.prototype.hourAfter = function(num){
        var time = this.getTime()  + parseInt(num) * 60 * 60 * 1000 ;
        this.setTime(time);
        return this;
    };
    Date.prototype.dayBefore = function(num){
        var time = this.getTime()  - num * 1000 * 60 * 60 * 24;
        this.setTime(time)
        return this;
    };
    Date.prototype.datAfter = function(num){
        var time = this.getTime()  + parseInt(num) * 60 * 60 * 1000 * 24;
        this.setTime(time);
        return this;
    };
    
})();
(function() {
    Array.prototype.hasString = function(str) {
        var hasString = false;
        this.forEach(function(item) {
            (item == str) && (hasString = true);
        });
        return hasString;
    };
    Array.prototype.removeString = function(str) {
        if (!this.hasString(str)) return;
        var index = -1;
        for (var i = 0; i < this.length; i++) {
            if (this[i] == str) {
                index = i;
                break;
            }
        }
        this.splice(index, 1);
    };
})();
(function() {
    if (typeof String.prototype.startsWith != 'function') {
        String.prototype.startsWith = function(prefix) {
            return this.slice(0, prefix.length) === prefix;
        };
    }
    if (typeof String.prototype.endsWith != 'function') {
        String.prototype.endsWith = function(suffix) {
            return this.indexOf(suffix, this.length - suffix.length) !== -1;
        };
    }
})();
/**
 * [Object.clone]
 * @return {[type]} [description]
 */
(function(){
    function clone(obj) {
        // Handle the 3 simple types, and null or undefined
        if (null == obj || "object" != typeof obj) return obj;

        // Handle Date
        if (obj instanceof Date) {
            var copy = new Date();
            copy.setTime(obj.getTime());
            return copy;
        }

        // Handle Array
        if (obj instanceof Array) {
            var copy = [];
            for (var i = 0, len = obj.length; i < len; ++i) {
                copy[i] = clone(obj[i]);
            }
            return copy;
        }

        // Handle Object
        if (obj instanceof Object) {

            var copy = obj.domainType ? new Cart[obj.domainType+"Domain"]() : {};
            for (var attr in obj) {
                if (obj.hasOwnProperty(attr)) copy[attr] = clone(obj[attr]);
            }
            return copy;
        }

        throw new Error("Unable to copy obj! It's type isn't supported.");
    }

    Object.clone = function(obj){
        return clone(obj); 
    }
})();
(function(){
    var staticProp = ["domainName","clear"];
    var DomainDefiner = function(name){
        var domain = function(){
            for(var key in this){
                // 将原型链上的属性拉取到自身 并解决引用 指向同一对象的问题
                if( $.inArray(key,staticProp) == -1 && !( this[key] instanceof Function) ) this[key] = Object.clone(this[key]);
            }
        };
        Object.defineProperty(domain.prototype,'domainName',{
            value        : name,
            writable     : false, 
            enumerable   : true, 
            configurable : true
        });
        Object.defineProperty(domain.prototype,'clear',{
            value        : function(){
                for(var key in this){
                    if( $.inArray(key,staticProp) == -1 && !( this[key] instanceof Function) ) this[key] = Object.clone(this["__proto__"][key]);
                }
            },
            writable     : false, 
            enumerable   : true, 
            configurable : true
        });
        Object.defineProperty(domain.prototype,'isDefault',{
            value        : function(name){
                
                // for(var key in this){
                //     if( $.inArray(key,staticProp) == -1 && !( this[key] instanceof Function) ) this[key] = Object.clone(this["__proto__"][key]);
                // }
            },
            writable     : false, 
            enumerable   : true, 
            configurable : true
        });
        $.extend(domain,{
            define:function(keys){
                /*,defaultValue,writable,enumerable,configurable*/
                if( (typeof keys).toLowerCase() == 'string') keys = [keys];
                keys.forEach(function(keyArr){
                    Object.defineProperty(domain.prototype,keyArr[0],{
                        value        : keyArr[1] != undefined ? keyArr[1] : null,
                        writable     : keyArr[2] != undefined ? keyArr[2] : true, 
                        enumerable   : keyArr[3] != undefined ? keyArr[3] : true, 
                        configurable : keyArr[4] != undefined ? keyArr[4] : true
                    });
                });
            }
        });
        return domain;
    };

    $.extend($,{
        Domain:function(name){
            return new DomainDefiner(name);
        }
    });
})();