(function() {
        window.SdkGenerater = function(Global) {
                var JsSdk = Global.JsSdk,
                    J = JsSdk,
                    Jutil = Global.Jutil,
                    Jnav = Global.Jnav,
                    Jhelper = Global.Jhelper,
                    Jview = Global.Jview,
                    Jlocation = Global.Jlocation,
                    api = Global.api;
(function() {
    if(navigator.userAgent.match(/ai-app-cloud/)){
        window.Global = window;
        Global.root = '';
    }
    var page = {},
        readyList = [],
        readyStatus = false;

    /**
     * [JsSdk JsSdk 加载成功回调]
     * @param {[function]} func [回调函数]
     */
    if (Global.JsSdk == undefined) {
        Global.JsSdk = function(func) {
            if (readyStatus) {
                func();
                return;
            }
            readyList.push(func);
        };
    }

    var JsSdk = Global.JsSdk;

    /**
     * [JsSdk.ready JsSdk 加载成功回调]
     * @param  {[type]} func [回调函数]
     */
    JsSdk.ready = function(func) {
        JsSdk(func);
    };
    /**
     * [JsSdk.context 获取/设置页面属性 ]
     * @type   attribute
     * @param  {[object]} obj [设置的属性/不传就是获取]
     * @return {[Object]}     [当前页面属性]
     *  // obj 
     *  {
     *       type     :'frame'/'win',
     *       frameName:'frameName'/undefined,
     *       winName  :'winName',
     *       __parent:{
     *           winName:'parentWinName',
     *           frameName:'parentFrameName'/undefined,
     *       },
     *       __nav:{
     *           height: num,  //nav的总高度
     *           barHeight: num //状态栏高度
     *       }
     *   }
     *
     *  
     */
    Object.defineProperty(JsSdk, 'context', {
        get: function() {
            return page;
        },
        set: function(obj) {
            if (obj != undefined) page = $.extend(page, obj, true);
            return page;
        }
    });
    // JsSdk.context = function(obj) {
    //     if (obj != undefined) page = $.extend( page, obj,true);
    //     return page;
    // };


    var parseWinType = function() {
        var context = {
            type: 'win',
            winName: api.winName
        }
        if (api.frameName) {
            context.type = 'frame';
            context.frameName = api.frameName;
        }
        if (api.pageParam == undefined) return;
        var param = api.pageParam;
        J.context = context;
    };

    var parseUI = function() {
        var param = api.pageParam;
        // if (param != undefined && param.updateTitle == false) return;
        // if (api.frameName) {
        //     JsSdk.nav.title(document.title);
        // }
    };

    window.apiready = function() {
        parseWinType();
        parseUI();
        readyStatus = true;
        readyList.forEach(function(func) {
            func();
        });
    };
    // Global.JsSdk = JsSdk;
    Global.J = JsSdk;
    // window.Global = window;
    //event
    /**
     * [JsSdk.on/JsSdk.bind 事件监听]
     *     api.addEventListener({name:'name1',function(){}}) => JsSdk.on('name1',function(){})
     *     
     * @param  {[string]} name [description]
     * @param  {[FUNCTION]} func [description]
     */
    JsSdk.on = function(name, func) {
        return api.addEventListener({
            'name': name
        }, func);
    };

    JsSdk.bind = JsSdk.on;

    /**
     * [JsSdk.unbind 解除事件监听]
     * @param  {[string]} name [解除的监听事件名称]
     */
    JsSdk.unbind = function(name) {
        api.removeEventListener({ "name": name });
    };
    /**
     * [JsSdk.once 绑定事件监听  触发一次后解除 只会触发一次]
     * @param  {[string]} name [事件名称]
     * @param  {function} func [回调方法]
     */
    JsSdk.once = function(name, func) {
        return api.addEventListener({
            'name': name
        }, function() {
            func();
            api.removeEventListener({ "name": name });
        });
    };


    J.template = function(source, data) {
        return source.replace(/\$\{(.*?)\}/gi, function(whole, $1) {
            var key = $1.replace(/\s+|\s+$/gi, '');
            if (data[key]) {
                return data[key];
            } else {
                return whole;
            }
        });
    };


    var _parent = {};

    var parent = function(obj) {
        if (obj != undefined) _parent = $.extend({}, _parent, obj);
        return _parent;
    };

    J(function() {
        if (api.pageParam && api.pageParam.__parent) parent(api.pageParam.__parent);
        J.context = {
            winName:api.winName,
            frameName:api.frameName
        };
    });
})();

// (function() {
    var getScript = function(obj){

        /**
         * (function(){
         *  var a = setInterval(function(){
         *      if(window.JsSdk){
         *           clearInterval(a);
         *           J(function(){
         *                var b = window.function(JSON.stringify(param));
         *                //if obj.back 
         *                JsSdk.fire({
         *                    function:'J.fireBack',
         *                    param:{
         *                        evalId:evalId,
         *                        result:b
         *                    },
         *                    winName:page.winName,
         *                    frameName:pahe.frameName
         *                });
         *                //if obj.back end
         *           });  
         *      }
         *  },20);
         * })()
         */
        scripts = [
            ' (function(){                                                          ',
            '  var a = setInterval(function(){                                      ',
            '      if(${env}.JsSdk){                                                ',
            '           clearInterval(a);                                           ',
            '           J(function(){                                               ',
            '                var b = Global.${funcName}(${param_string});           ',  
            // '                console.info(${param_string}) ;                         ',
            // '                console.info(Global.${funcName});                          ',
        ];
        if(obj.back){
            scripts = scripts.concat([   
            '                JsSdk.fire({                                           ',
            '                    function:"J.fireBack",                             ',
            '                    param:{                                            ',
            '                        evalId:"${evalId}",                            ',
            '                        result:b                                       ',
            '                    },                                                 ',
            '                    winName:"${current_win}",                          ',
            '                    frameName:"${current_frame}"                       ',
            '                });                                                    ',
            ]);
        }
        scripts = scripts.concat([   
            '           });                                                         ',
            '      }                                                                ',
            '  },20);                                                              ',
            ' })();                                                                 '
        ]);
        scripts = scripts.join('\n');
        scripts = J.template(scripts,obj);
        // api.toast({
        //     msg:scripts,
        //     duration:100000
        // });
        return scripts;
    }
    /**
     * [JsSdk.fire 调用目标win/frame的方法]
     * @param  {Object} obj       [入参]
     *         {
     *             funcName:''  [string]  方法名称
     *             param:''     [object]  方法入参  可选 default:{}
     *             winName:''   [string]  所属win的名称
     *             frameName:'' [string]  所属frame的名称
     *             back:false   [boolean] 目标页面执行成功后是否回调 default:false
     *         }
     * @useage
     *     //不需要回调
     *     JsSdk.fire({
     *         funcName:"alert",
     *         param:{name:11},
     *         page:{
     *             winName:"winName",
     *             frameName:"frameName"
     *         }
     *     })
     *     //回调
     *     var a = JsSdk.fire({
     *         funcName:"alert",
     *         param:{name:11},
     *         page:{
     *             winName:"winName",
     *             frameName:"frameName"
     *         },
     *         back:true
     *     });
     *     a.then(function(data){
     *         //回调目标页面执行结果
     *     })
     */
    J.fire = function(obj) {
        if (obj.param == undefined) obj.param = {};

        var scripts = "",
            evalId = Jutil.random(3, 'evalId_');
        var innerparam = $.extend({},obj);
        var page = J.context;
        innerparam.param_string = JSON.stringify(innerparam.param);
        innerparam.current_win = page.winName;
        innerparam.current_frame = page.frameName;
        innerparam.evalId = evalId;
        innerparam.env = Jutil.isApp() ? 'window':'Global';
        // innerparam.winName = obj.page.winName;
        // innerparam.frameName = obj.page.frameName

         /**
         * (function(){
         *  var a = setInterval(function(){
         *      if(JsSdk){
         *           clearInterval(a);
         *           J(function(){
         *                var b = window.function(JSON.stringify(param));
         *                JsSdk.fire({
         *                    function:'J.fireBack',
         *                    param:{
         *                        evalId:evalId,
         *                        result:b
         *                    },
         *                    winName:page.winName,
         *                    frameName:pahe.frameName
         *                });
         *           });  
         *      }
         *  },20);
         * })()
         */
        scripts = getScript(innerparam);
       
        var execScript = {
            name: obj.page.winName,
            script: scripts
        };
        if (obj.page.frameName != undefined) execScript.frameName = obj.page.frameName;
        api.execScript(execScript);
        // if (back) return _fireDefferd[evalId].promise();
    };

// })();

(function() {
    var h = {};
    var ANIMATE = {
        fade: {
            type: "fade",
            subType: "from_right",
            duration: 200
        },
        down: {
            type: "movein",
            subType: "from_top",
            duration: 200
        },
        up: {
            type: "movein",
            subType: "from_bottom",
            duration: 200
        },
        left: {
            type: "movein",
            subType: "from_right",
            duration: 200
        },
        right: {
            type: "movein",
            subType: "from_left",
            duration: 200
        }
    };

    h.isFunction = function(a) {
        return a instanceof Function;
    };
    h.isString = function(s) {
        return (typeof s).toLowerCase() == "string";
    };
    h.isObject = function(s) {
        return (typeof s).toLowerCase() == "object";
    };

    h.animate = function(animateString) {
        if (animateString == undefined) return ANIMATE['right'];
        if (h.isString(animateString)) {
            animateString = animateString.toLowerCase();
            return ANIMATE[animateString];
        }
        return animateString;
    };

    h.CALLBACK_UNITIES = {};
    h.callback = function(callback) {
        if (h.isString(callback)) return callback;
        if (h.isFunction(callback)) {
            var cacheName = Jutil.random(4, "helper_cb_cache");
            helper.CALLBACK_UNITIES[cacheName] = callback;
            return "Jhelper.CALLBACK_UNITIES." + cacheName;
        }
    };
    h.callBack = h.callback;

    h.htmlDecode = function(str) {
        if (str == null) return "<div></div>";
        var s = "";
        if (str.length == 0) return "";
        s = str.replace(/&gt;/g, "&");
        s = s.replace(/&lt;/g, "<");
        s = s.replace(/&gt;/g, ">");
        s = s.replace(/&nbsp;/g, " ");
        s = s.replace(/&#39;/g, "\'");
        s = s.replace(/&quot;/g, "\"");
        s = s.replace(/<br>/g, "\n");
        s = s.replace(/\\r\\n/g, '<br/>');
        s = s.replace(/\\n/g, '<br/>');
        s = s.replace(/\\t/g, '');
        return s;
    };

    J.helper = h;
    Global.Jhelper = h;
})();

var util = {};
/**
 * [JsSdk.util.random 生产随机数]
 * @param  {[interger]} loopNum [循环次数]
 * @param  {[string]} preffix [前缀]
 * @return {[type]}         [description]
 */
util.random = function(loopNum, preffix) {
    if (loopNum == undefined) loopNum = 3;
    var ran = preffix != undefined ? preffix : "";
    for (var i = 0; i < loopNum; i++) {
        ran += Math.round(Math.random() * i * 10)
    }
    return ran;
};

util.cloneObject = function(Obj) {
    return JSON.parse(JSON.stringify(Obj));
};


util.router = function(routeName) {
    var prefix = util.isApp() ? AI.app_url + '/modules/' : '';
    var param = util.cloneObject(Router[routeName]);
    if (param.type == 'frameGroup') {
        param.tabs.forEach(function(tab) {
            tab.url = prefix + tab.url + '.html';
        })
    } else {
        param.url = prefix + param.url + '.html';
    }
    param.pageParam.__history = J.location.history;
    return param;
};

util.isApp = function() {
    return navigator.userAgent.match(/ai-app-cloud/) ? true : false;
};

util.message = function(code) {
    if (MESSAGE[code] == undefined) return '';
    var message = MESSAGE[code];
    var arr = [],
        i = 1;
    while (i < arguments.length) {
        arr.push(arguments[i]);
        i++;
    }
    if (arr.length > 0) {
        message = message.replace(/\{(.*?)\}/gi, function(whole) {
            if (arr.length > 0) {
                return arr.shift();
            } else {
                return whole;
            }
        });
    }
    return message;
};


(function() {
    var inited = false,
        UIScrollPicture = null;
    var swraper = function() {
        if (!inited) {
            UIScrollPicture = api.require('UIScrollPicture');
            inited = true;
        }
        return UIScrollPicture;
    };

    /**
     * [JsSdk.util.swraper.open 打开轮播组件]
     * @param  {[type]} obj
     *         object : {
     *             target : ''  // String||domObject 附着于该目标上
     *             configs:[
     *                  {
     *                      src:''  //图片地址
     *                      ...     //其余参数
     *                  }
     *             ],
     *             click:function(index,configsItem){}
     *         }
     * @useage
     *       JsSdk.util.swraper.open({
     *           target:'#main',
     *           configs:[
     *               {
     *                   src:"aaa.jpg",
     *                   href:'bbb.html',
     *                   attr:{
     *                       .....
     *                   }
     *               }
     *           ],
     *           click:function(index,data){
     *               // data =>  {
     *               //     src:"aaa.jpg",
     *               //     href:'bbb.html',
     *               //     attr:{
     *               //         ...
     *               //     }
     *               // }
     *           }
     *       });
     */
    swraper.open = function(obj) {
        if (!inited) swraper();

        var paths = [],
            clicks = obj.click,
            configs = obj.configs;
        obj.configs.forEach(function(config) {
            paths.push(config.src);
        });

        UIScrollPicture.open({
            rect: {
                x: Math.ceil(obj.target.offset().left),
                y: Math.ceil(obj.target.offset().top),
                w: Math.ceil(obj.target.width()),
                h: Math.ceil(obj.target.height())
            },
            data: {
                paths: paths
            },
            styles: {
                indicator: {
                    align: 'center',
                    color: '#DA70D6',
                    activeColor: '#ffffff'
                }
            },
            contentMode: 'scaleToFill',
            interval: 3,
            loop: true,
            fixedOn: api.frameName,
            fixed: false
        }, function(ret, err) {
            if (ret) {
                if (ret.status == true && ret.eventType == "click") {
                    try {
                        var index = ret.index;
                        clicks(index, configs[index]);
                    } catch (e) {
                        // console.info("error");
                    }
                }
            }
        });
    };
    /**
     * [JsSdk.util.swraper.close 关闭轮播组件引用]
     * @useage
     *     //重新open之前，要关闭
     *     JsSdk.onPageClose(function() {
     *           JsSdk.util.swraper.close();
     *     });
     */
    swraper.close = function() {
        if (!inited) return;
        UIScrollPicture.close();
    };


    util.swraper = swraper;

})();



JsSdk.util = util;
Global.Jutil = util;

(function() {
    var navHeight = 0,
        barHeight = 0,
        navPage = {};

    var nav = {};
    nav.autoUpdateButton = true;
    nav.autoUpdateTitle = true;
    Object.defineProperty(nav, 'height', {
        get: function() {
            return navHeight;
        },
        set: function() {}
    });

    Object.defineProperty(nav, 'bar', {
        get: function() {
            return barHeight;
        },
        set: function() {}
    });

    Object.defineProperty(nav, 'title', {
        get: function() {},
        set: function(title) {
            J.fire({
                funcName: 'nav.updateTitle',
                param: {
                    title: title
                },
                page: navPage
            })
        }
    });

    var getInhertConfig = function() {
        if ($("nav-button").length == 0) return;
        var text = $("nav-button").text().replace(/^\n*/gi,'');
        var func = 'return ${config};';
        // if($("nav-button").attr('type')) func = 'return (function(){ ${config};})();'
        func = J.template(func, { config: text });
        try {
            var a = new Function(func);
            var c = a();
            return c;
        } catch (e) {
            alert(e);
            return;
        }
    };

    nav.button = function(obj) {
        if (obj == undefined) {
            obj = getInhertConfig();
        }
        if (obj == undefined) return;
        JsSdk.fire({
            funcName:'nav.configButton',
            param:{
                config:obj,
                page:J.context
            },
            page:navPage
        });
    };

    nav._onTabShow = function(){
        // console.info(api.winName +"->"+api.frameName +":show");
    };
    nav.onTabShow = function(callBack){
        nav._onTabShow = callBack;
    };
    nav._onTabHide = function(){
        // console.info(api.winName +"->"+api.frameName +":hide");
    };
    nav.onTabHide = function(callBack){
        nav._onTabHide = callBack;
    };
    J.nav = nav;
    Global.Jnav = nav;

    var updateTitle = function() {
        var param = api.pageParam;
        if (param == undefined) return;
        if (nav.autoUpdateTitle == false) return;
        if (param.updateTitle == undefined || param.updateTitle == true) {
            if (api.frameName) nav.title = document.title;
        }
    };
    var updateButton = function() {
        if (nav.autoUpdateButton == false) return;
        nav.button();
    };
    J(function() {
        var param = api.pageParam;
        if (!api.frameName) return;
        if (param.__nav) {
            navHeight = param.__nav.total;
            barHeight = param.__nav.top;
            navPage = param.__nav.page;
            J.context = {
                type: param.__nav.pageType
            }
            if (J.context.type == 'frameGroupPage') {
                // nav.autoUpdateButton = false;
                nav.autoUpdateTitle = false;
            }
            updateTitle();
            updateButton();
        };


    });
})();

(function() {

    var parsePageParam = function(option) {
        var param = option.pageParam;
        param.__parent = {
            winName: api.winName,
            frameName: api.frameName
        };
    };

    var view = {};
    view.open = function(option) {
        parsePageParam(option);
        var prefix = Jutil.isApp()?AI.app_url :'..';
        var win = {
            name: option.name + '_wrap',
            url: prefix + '/platform/nav/' + option.nav + '.html',
            slidBackEnabled: option.slidBackEnabled,
            animation: Jhelper.animate(option.animation),
            bounces: false,
        };
        option.bgColor && (win.bgColor = option.bgColor);
        
        delete option.animation;
        delete option.slidBackEnabled;
        win.pageParam = option;
        api.openWin(win);
    };

    view.frameGroup = function(opt) {
        var name = opt.name;
        var obj = Object.create({});
        obj._index = opt.index;
        obj.changed = function() {};
        Object.defineProperty(obj, 'index', {
            get: function() {
                return this._index;
            },
            set: function(i) {
                var index, scroll = false,
                    reload = false;
                if (typeof i == 'object') {
                    index = i.index;
                    (i.scroll != undefined) && (scroll = i.scroll);
                    (i.reload != undefined) && (reload = i.reload);
                } else {
                    index = i;
                }
                this._index = i;
                api.setFrameGroupIndex({
                    name: opt.name,
                    index: index,
                    reload: reload,
                    scroll: scroll
                });
            }
        });
        api.openFrameGroup(opt, function(ret) {
            J.fire({
                funcName: 'J.nav._onTabShow',
                page: {
                    winName: api.winName,
                    frameName: ret.name
                }
            });
            if (obj._frameName) {
                J.fire({
                    funcName: 'J.nav._onTabHide',
                    page: {
                        winName: api.winName,
                        frameName: obj._frameName
                    }
                });
            }
            obj._frameName = ret.name;

            obj.changed(ret.index, ret.name);
        });
        return obj;
    };

    view.frame = function (router) {
        var tabs = Jutil.cloneObject(router.tabs),
            pageParam = Jutil.cloneObject({});
        // pageParam.__nav = this.navConfig();
        var index = 0;
        for (var i = 0; i < tabs.length; i++) {
            tabs[i] = $.extend({}, {
                pageParam: Jutil.cloneObject(pageParam),
                name: "tabs" + Jutil.random(4)
            }, tabs[i]);
            if (tabs[i].selected == true || tabs[i].selected == 'true') index = i;
        }
        // this.view.active_tab_index = index;
        var group = {
            name: router.name = undefined ? Jutil.random(4, 'frameGroup') : router.name,
            background: '#fff',
            scrollEnabled: router.scroll,
            rect: router.rect,
            index: index,
            frames: tabs
        };
        return view.frameGroup(group);
    };

    view.openFrame = function(router){
        console.info(router);
        api.openFrame(router)
    };

    J.view = view;
    Global.Jview = view;
})();
(function() {
    var history = [];

    J.location = {};
    Global.Jlocation = J.location;

    Object.defineProperty(J.location, 'href', {
        get: function() {
            return J.context;
        },
        set: function(href) {
             var search = href.replace(/^(.*?)\?/,''),
                routerName = href.replace(/\?(.*?)$/,''),
                router = Jutil.router(routerName);
            if(search != ''){
                var param = {};
                search.split('&').forEach(function(line){
                    var arr = line.split('=');
                    if(arr.length == 2){
                        param[arr[0]] = arr[1];
                    }
                });
                router = $.extend(router,{pageParam:param});
                // console.info(router);
            }
            Jview.open(router);
        }
    });

    Object.defineProperty(J.location, 'history', {
        get: function() {
            return history;
        },
        set: function() {

        }
    });

    J.location.back = function(num) {
        var winName = J.location.prev(num).winName;
        api.closeToWin({
            name: winName
        })
    };

    J.location.prev = function(num) {
        if (num == undefined) num = 1;
        num = parseInt(num) + 1;
        return history[history.length - num];
    };
    J(function() {
        if (api.pageParam && api.pageParam.__history) {
            history = api.pageParam.__history;
        } else {
            history = [];
        }
        history.push({
            winName: api.winName,
            frameName: api.frameName
        });
    });
})();

if (navigator.userAgent.match(/ai-app-cloud/)) {
    JsSdk.ajax = function(options) {
        (options == undefined) && (options = {});
        //app
        options = $.extend({ method: 'post' }, options);
        var d = $.Deferred();
        var url = options.url;
        options.url = AI.InterFaceIp + AI.InterfaceUrl + options.url + '';
        options.headers = options.headers == undefined ? {} : options.headers;
        options.headers["content-type"] = 'application/json;charset=UTF-8';
        options.data = {body:JSON.stringify(options.data)};
        api.ajax(options, function(ret, err) {
            if (err) {
                d.reject(err)
            }
            if (ret) {
                if(ret.errcode != '000'){
                    toast(ret.errmsg);
                    d.reject(new Error(ret.errmsg));

                }else{
                    d.resolve(ret.data);
                }
            }
        })
        return d.promise();

    }
} else {
    JsSdk.ajax = function(options) {
        options == undefined && (options = {});
        //wap
        options = $.extend({ type: 'post', dataType: 'json' }, options);
        options.beforeSend = function(request) {
            request.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        };
        options.data = JSON.stringify(options.data);
        options.url = '/' + AI.InterfaceUrl + options.url;
        var d = $.Deferred();
        $.ajax(options)
        .then(function(data){
            if(data.errcode != '000'){
                toast(data.errmsg);
                d.reject(new Error(data.errmsg));

            }else{
                d.resolve(data.data);
            }
        })
        .fail(function(err){
            d.reject(err)
        });
        return d.promise();
    }
}
    JsSdk = Global.JsSdk,
    J = JsSdk,
    Jutil = Global.Jutil,
    Jnav = Global.Jnav,
    Jhelper = Global.Jhelper,
    Jview = Global.Jview,
    Jlocation = Global.Jlocation;
    return Global;
}
})();
