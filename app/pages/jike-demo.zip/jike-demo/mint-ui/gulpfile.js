'use strict';

const path = require('path'),
    gulp = require('gulp'),
    rename = require('gulp-rename'),
    rollup = require('gulp-rollup'),
    vue = require('./bin/vue/index'),
    css = require('./bin/post-css'),
    alias = require('./bin/alias/alias'),
    buble = require('rollup-plugin-buble'),
    nodeResolve = require('rollup-plugin-node-resolve'),
    commonjs = require('rollup-plugin-commonjs'),
    replace = require('rollup-plugin-replace'),
    url = require('rollup-plugin-url'),
    salad = require('postcss-salad'),
    pxtorem = require('postcss-pxtorem'),
    uglify = require('rollup-plugin-uglify');

// process.env.NODE_ENV = 'component';

gulp.task('mint', () => {
    return gulp.src([
            './mint-ui/**/*.js',
            './mint-ui/**/*.css',
            './mint-ui/**/*.ttf',
            './mint-ui/**/*.svg',
            './mint-ui/**/*.vue',
            './node_modules/wind-dom/**/*.js',
            './node_modules/mint-ui/**/*.js',
            './node_modules/mint-ui/**/*.vue',
            './node_modules/mint-ui/**/*.css',
            './node_modules/array-find-index/**/*.js',
            './node_modules/vue-popup/**/*.js',
            './node_modules/vue-popup/**/*.css',
            './node_modules/vue/**/*.js',
            './node_modules/vue-lazyload/**/*.js',
            './node_modules/raf.js/**/*.js'
        ])
        .pipe(rollup({
            entry: './mint-ui/src/index.js',
            globals: { 'vue': 'Vue' },
            moduleName: 'MINT',
            plugins: [
                replace({
                    'process.env.NODE_ENV': JSON.stringify('production')
                }),
                alias({
                    'mint-ui': path.resolve(__dirname, 'mint-ui')
                }),
                vue({
                    compileTemplate: false,
                    styleToImports: true
                }),
                nodeResolve({
                    browser: true,
                    jsnext: true,
                    main: true,
                    skip: ['vue']
                }),
                css({
                    output: '../mobile/common/style/mint.css',
                    postcss: [
                        salad(),
                        pxtorem({
                            rootValue: 50,
                            unitPrecision: 5,
                            propWhiteList: [
                                'font', 'font-size', 'line-height', 'letter-spacing',
                                'height', 'width', 'min-height',
                                'border-radius','background-size',
                                'padding', 'padding-top', 'padding-right', 'padding-bottom', 'padding-left',
                                'margin', 'margin-top', 'margin-right', 'margin-bottom', 'margin-left',
                                'left', 'right', 'top', 'bottom'
                            ],
                            // selectorBlackList: [],
                            replace: true,
                            mediaQuery: false,
                            minPixelValue: 0
                        })
                    ]
                }),
                url({
                    limit: 10 * 1024, // inline files < 10k, copy files > 10k
                    include: ["**/*.svg", "**/*.ttf"], // defaults to .svg, .png, .jpg and .gif files
                }),
                buble(),
                commonjs({
                    namedExports: {
                        // left-hand side can be an absolute path, a path
                        // relative to the current directory, or the name
                        // of a module in node_modules
                        'node_modules/wind-dom/src/event.js': ['once'],
                        'node_modules/wind-dom/src/class.js': ['removeClass', 'addClass']
                    }
                })
                // ,uglify()
            ],
            format: 'umd'
        }))
        .pipe(rename('mint.js'))
        .pipe(gulp.dest('../mobile/common/script/mint-ui/'))
});

gulp.task('default', ['mint'], () => {
    gulp.watch(['./mint-ui/**/*.js',
        './mint-ui/**/*.css',
        './mint-ui/**/*.ttf',
        './mint-ui/**/*.svg',
        './mint-ui/**/*.vue'
    ], ['mint']);

});
