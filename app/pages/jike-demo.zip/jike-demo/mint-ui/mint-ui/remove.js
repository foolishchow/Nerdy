'use strict';
const fs = require('fs'),
    path = require('path');
var dir = path.resolve(__dirname, 'packages');
fs.readdir(dir, function(err, files) {
    if (err) {
        console.log(err);
        return;
    }

    var count = files.length;
    var results = {};
    let i = 0;
    files.forEach(function(filename) {
        let stats = fs.statSync(dir+'/'+filename);
        if (stats.isDirectory()) {
            // console.info(dir+'/'+filename)
            if (fs.existsSync(dir+'/'+filename + '/cooking.conf.js')) {
                fs.unlinkSync(dir+'/'+filename + '/cooking.conf.js')
            }
            if (fs.existsSync(dir+'/'+filename + '/package.json')) {
                fs.unlinkSync(dir+'/'+filename + '/package.json')
            }
            // if (fs.existsSync(dir+'/'+filename + '/README.md')) {
            //     fs.unlinkSync(dir+'/'+filename + '/README.md')
            // }
        }
    });
});
