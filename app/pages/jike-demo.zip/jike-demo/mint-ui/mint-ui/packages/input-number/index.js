import InputNumber from './src/input-number.vue';
export default InputNumber;
