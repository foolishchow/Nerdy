<template>
  <div class="ai-input-number clearfix"
    :class="[
      { 'is-disabled': disabled }
    ]"
  >
     <span class="ai-input-number__decrease"
             :class="{'is-disabled': minDisabled}"
             @click.stop.prevent="decrease" >-
    </span>
    <input type="text"
      v-model="currentValue"
      :disabled="disabled"
      :class="{
        'is-active': inputActive
      }">
    <span
      class="ai-input-number__increase"
      :class="{'is-disabled': maxDisabled}"
      @click.stop.prevent="increase">+
    </span>
  </div>
</template>
<script>
//  import ElInput from 'packages/input/index.js';
//  import { once, on } from 'wind-dom/src/event';
  export default {
    name: 'ai-input-number',
    props: {
      value: {
        default: 1
      },
      step: {
        type: Number,
        default: 1
      },
      max: {
        type: Number,
        default: Infinity
      },
      min: {
        type: Number,
        default: 0
      },
      disabled: Boolean,
      size: String
    },
//    directives: {
//      repeatClick: {
//        bind(el, binding, vnode) {
//          let interval = null;
//          let startTime;
//
//          const handler = () => {
//            vnode.context[binding.expression]();
//          };
//
//          const clear = function() {
//            if (new Date() - startTime < 100) {
//              handler();
//            }
//            clearInterval(interval);
//            interval = null;
//          };
//
////          on(el, 'mousedown', function() {
////            startTime = new Date();
////            once(document, 'mouseup', clear);
////            interval = setInterval(function() {
////              handler();
////            }, 100);
////          });
//        }
//      }
//    },
//    components: {
//      ElInput
//    },
    data() {
      return {
        currentValue: parseInt(this.value),
        inputActive: false
      };
    },
    watch: {
      value(val) {
        this.currentValue = val;
      },


      currentValue(newVal, oldVal) {
        if (!isNaN(newVal) && newVal <= this.max && newVal >= this.min) {
          this.$emit('change', newVal);
          this.$emit('input', newVal);
        } else {
          this.$nextTick(() => {
            this.currentValue = oldVal;
          });
        }
      }
    },
    computed: {
      minDisabled() {
        return this.currentValue - this.step < this.min;
      },
      maxDisabled() {
        return this.currentValue + this.step > this.max;
      }
    },
    methods: {
      accSub(arg1, arg2) {
        var r1, r2, m, n;
        try {
          r1 = arg1.toString().split('.')[1].length;
        } catch (e) {
          r1 = 0;
        }
        try {
          r2 = arg2.toString().split('.')[1].length;
        } catch (e) {
          r2 = 0;
        }
        m = Math.pow(10, Math.max(r1, r2));
        n = (r1 >= r2) ? r1 : r2;
        return parseFloat(((arg1 * m - arg2 * m) / m).toFixed(n));
      },
      accAdd(arg1, arg2) {
        var r1, r2, m, c;
        try {
          r1 = arg1.toString().split('.')[1].length;
        } catch (e) {
          r1 = 0;
        }
        try {
          r2 = arg2.toString().split('.')[1].length;
        } catch (e) {
          r2 = 0;
        }
        c = Math.abs(r1 - r2);
        m = Math.pow(10, Math.max(r1, r2));
        if (c > 0) {
          var cm = Math.pow(10, c);
          if (r1 > r2) {
            arg1 = Number(arg1.toString().replace('.', ''));
            arg2 = Number(arg2.toString().replace('.', '')) * cm;
          } else {
            arg1 = Number(arg1.toString().replace('.', '')) * cm;
            arg2 = Number(arg2.toString().replace('.', ''));
          }
        } else {
          arg1 = Number(arg1.toString().replace('.', ''));
          arg2 = Number(arg2.toString().replace('.', ''));
        }
        return (arg1 + arg2) / m;
      },
      increase() {

        if (this.currentValue + this.step > this.max || this.disabled) return;
        this.currentValue = this.accAdd(this.step, this.currentValue);
        if (this.maxDisabled) {
          this.inputActive = false;
        }
      },
      decrease() {
        if (this.currentValue - this.step < this.min || this.disabled) return;
        this.currentValue = this.accSub(this.currentValue, this.step);
        if (this.minDisabled) {
          this.inputActive = false;
        }
      },
      activeInput(disabled) {
        if (!this.disabled && !disabled) {
          this.inputActive = true;
        }
      },
      inactiveInput(disabled) {
        if (!this.disabled && !disabled) {
          this.inputActive = false;
        }
      }
    }
  };
</script>

<style lang="css">

  .ai-input-number {
    display:block;
    overflow:hidden;
    width:170px;
    position: relative;
    border: 1px solid #dadada;
    border-radius: 3px;
    font-size: 30px;
    line-height:50px;

  }

  /*.ai-input-number .ai-input__inner {*/
    /*-webkit-appearance:none;*/
    /*-moz-appearance:none;*/
    /*appearance:none*/
  /*}*/
  .ai-input-number input {
    float:left;
    display: block;
    border: 0;
    width: 66px;
    height:50px;
    text-align: center;
    border-left:1px solid #dadada;
    border-right:1px solid #dadada;
  }


  .ai-input-number__decrease, .ai-input-number__increase {
    height:50px;
    width:48px;
    top:0;
    text-align:center;
    color:#99A9BF;
    cursor:pointer;
    float:left;
    position:relative;
    color:#333;
  }

  .ai-input-number__decrease.is-disabled, .ai-input-number__increase.is-disabled{
    color: #999;
  }


  </style>