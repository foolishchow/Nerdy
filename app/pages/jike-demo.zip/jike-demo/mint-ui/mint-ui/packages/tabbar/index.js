import Tabbar from './src/tabbar.vue';
export default Tabbar;
