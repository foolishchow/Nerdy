import Radiolist from './src/radiolist.vue';
export default Radiolist;
