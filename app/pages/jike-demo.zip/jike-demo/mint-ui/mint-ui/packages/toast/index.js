import Toast from './src/toast.js';
export default Toast;
