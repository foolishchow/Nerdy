import Navbar from './src/navbar.vue';
export default Navbar;
