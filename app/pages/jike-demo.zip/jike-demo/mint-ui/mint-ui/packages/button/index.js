import Button from './src/button.vue';
export default Button;
