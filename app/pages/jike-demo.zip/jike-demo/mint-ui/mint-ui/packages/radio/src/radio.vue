<template>
  <div class="mint-radio mint-cell"  :class="[{'is-border':border}]">
    <div class="mint-cell-wrapper">
      <label class="mint-cell-title mint-radio-title">
      <span class="mint-radio-i">
        <input
                class="mint-radio-input"
                :value="label"
                type="radio"
                v-model="_value"
                @focus="focus = true"
                @blur="focus = false"
                :name="name"
                :disabled="disabled">
         <span class="mint-radio-core"
                 :class="{
          'is-disabled': disabled,
          'is-checked': _value === label,
          'is-focus': focus
        }"></span>
      </span>
      <span class="mint-radio-label">
        <slot></slot>
        <template v-if="!$slots.default">{{label}}</template>
      </span>
    </label>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'ai-radio',

    props: {
      value: [String, Number],
      label: {
        type: [String, Number],
        required: true
      },
      border: Boolean,
      disabled: Boolean,
      name: String
    },
    data() {
      return {
        focus: false
      };
    },
    computed: {
      _value: {
        get() {
          return this.value !== undefined ? this.value : this.$parent.value;
        },
        set(newValue) {
          if (this.value !== undefined) {
            this.$emit('input', newValue);
          } else {
            this.$parent.$emit('input', newValue);
          }
        }
      }
    }
  };
</script>

<style lang="css">
  @import "../../../src/style/var.css";

  @component-namespace mint {


    @component radio {

      @descendent title {
        display: flex;
      }


      @descendent label {
        vertical-align: middle;
        margin-left: 12px;
      }

      @descendent input {
        display: none;

    }

  .mint-radio-core {
    &.is-checked {
       background-color: $color-red;
       border-color: $color-red;

    &::after {
       background-color: $color-white;
       transform: scale(1);
     }
    }
  &[disabled]{
     background-color: $color-grey;
     border-color: #ccc;
   }
  }

  @descendent core {
    display: inline-block;
    background-color: $color-white;
    border-radius: 100%;
    border: 1px solid #ccc;
    position: relative;
    size: 40px;
    vertical-align: middle;
    top: 50%;
    transform: translateY(-50%);

  &::after {
     content: " ";
     border-radius: 100%;
     position: absolute 10px * * 10px;
     size: 16px;
     transition: transform .2s;
     transform: scale(0);

   }
  }
  }
  }
</style>
