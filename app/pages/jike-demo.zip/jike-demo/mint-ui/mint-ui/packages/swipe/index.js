import Swipe from './src/swipe.vue';
export default Swipe;
