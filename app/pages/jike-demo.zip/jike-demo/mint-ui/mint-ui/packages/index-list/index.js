import IndexList from './src/index-list.vue';
export default IndexList;
