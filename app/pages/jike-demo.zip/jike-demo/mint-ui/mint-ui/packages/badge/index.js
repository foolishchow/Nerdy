import Badge from './src/badge.vue';
export default Badge;
