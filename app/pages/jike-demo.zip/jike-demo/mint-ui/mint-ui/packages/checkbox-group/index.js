import CheckboxGroup from './src/checkbox-group.vue';
export default CheckboxGroup;
