<script>
  export default {
    name: 'ai-checkbox-group',

    props: {
      value: {}
    },

    watch: {
      value(value) {

        this.$emit('change', value);
        //this.dispatch('form-item', 'el.form.change', [value]);


      }
    }
  };
</script>

<template>
  <div class="ai-checkbox-group">
    <slot></slot>
  </div>
</template>
