<script>
  export default {
    computed: {
      spinnerColor() {
        return this.color || this.$parent.color || '#ccc';
      },

      spinnerSize() {
        return (this.size || this.$parent.size || 1.12) +'rem';
      }
    },

    props: {
      size: Number,
      color: String
    }
  };
</script>
<template>
  
</template>
<style></style>