import DatetimePicker from './src/datetime-picker.vue';
export default DatetimePicker;
