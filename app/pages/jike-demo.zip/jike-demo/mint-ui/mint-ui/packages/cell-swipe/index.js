import CellSwipe from './src/cell-swipe.vue';
export default CellSwipe;
// export default require('./src/cell-swipe.vue');
