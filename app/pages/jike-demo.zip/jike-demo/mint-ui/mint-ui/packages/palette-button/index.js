import PaletteButton from './src/palette-button.vue';
export default PaletteButton;
