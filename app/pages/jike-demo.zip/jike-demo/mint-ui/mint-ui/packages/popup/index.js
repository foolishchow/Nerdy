import Popup from './src/popup.vue';
export default Popup;
