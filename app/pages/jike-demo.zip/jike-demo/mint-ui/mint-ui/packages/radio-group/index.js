import RadioGroup from './src/radio-group.vue';
export default RadioGroup;
