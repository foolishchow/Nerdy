import TabContainer from './src/tab-container.vue';
export default TabContainer;
