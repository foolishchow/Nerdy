import TabContainerItem from './src/tab-container-item.vue';
export default TabContainerItem;
