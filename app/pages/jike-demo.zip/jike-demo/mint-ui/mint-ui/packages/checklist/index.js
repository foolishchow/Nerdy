import Checklist from './src/checklist.vue';
export default Checklist;
