import InfiniteScroll from './src/infinite-scroll.js';
import 'mint-ui/src/style/empty.css';

export default InfiniteScroll;
