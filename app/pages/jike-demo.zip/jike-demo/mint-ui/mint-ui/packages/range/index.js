import MintRange from './src/index.vue';
// const MintRange = require('./src/index.vue');

MintRange.install = function(Vue) {
  Vue.component(MintRange.name, MintRange);
};

export default MintRange;
