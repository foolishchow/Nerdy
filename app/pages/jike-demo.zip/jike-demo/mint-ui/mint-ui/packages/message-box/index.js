import MessageBox from './src/message-box.js';
export default MessageBox;
