import Checkbox from './src/checkbox.vue';
export default Checkbox;
