<template>
  <div class="mint-checkbox mint-cell"  :class="[{'is-border':border}]">
    <div class="mint-cell-wrapper">
    <label class="mint-cell-title mint-checkbox-title">
      <span class="mint-checkbox-i">
        <span
          :class="{
            'is-disabled': disabled,
            'is-checked': checked,
            'is-indeterminate': indeterminate,
            'is-focus': focus
          }"
        ></span>
        <input
          v-if="trueLabel || falseLabel"
          class="mint-checkbox-input"
          :true-value="trueLabel"
          :false-value="falseLabel"
          v-model="_value"
          type="checkbox"
          @focus="focus = true"
          @blur="focus = false"
          :disabled="disabled"
          ref="checkbox">
        <input
          v-else
          class="mint-checkbox-input"
          :value="label"
          v-model="_value"
          @focus="focus = true"
          @blur="focus = false"
          type="checkbox"
          :disabled="disabled">
          <span class="mint-checkbox-core"></span>
      </span>
      <span class="mint-checkbox-label" v-if="$slots.default || label">
        <slot></slot>
        <template v-if="!$slots.default">{{label}}</template>
      </span>
    </label>
    </div>
  </div>
</template>
<script>
//  import Emitter from 'main/mixins/emitter';
  export default {
    name: 'ai-checkbox',

//    mixins: [Emitter],

    props: {
      value: {},
      label: {
        type: String
      },
      indeterminate: Boolean,
      disabled: Boolean,
      border: Boolean,
      trueLabel: [String, Number],
      falseLabel: [String, Number]
    },

    computed: {
      _value: {
        get() {
          return this.value !== undefined ? this.value : this.$parent.value;
        },
        set(newValue) {

          if (this.value !== undefined) {
            this.$emit('input', newValue);
          } else {
            this.$parent.$emit('input', newValue);
          }
        }
      },
      checked() {
        var type = Object.prototype.toString.call(this._value);

        if (type === '[object Boolean]') {
          return this._value;
        } else if (type === '[object Array]') {
          return this._value.indexOf(this.label) > -1;
        } else if (type === '[object String]' || type === '[object Number]') {
          return this._value === this.trueLabel;
        }
      }
    },


    data() {
      return {
        focus: false
      };
    },

    watch: {
      checked(sure) {
        this.$emit('change', sure);
      }
    }
  };
</script>


<style lang="css">
  @import "../../../src/style/var.css";

  @component-namespace mint {
    font-size: 32px;

    @component checkbox {

      @descendent title{
        display: -webkit-box;
        display: -webkit-flex;
        display: flex;

      }

      @descendent label {
        vertical-align: middle;
        margin-left: 12px;
        display: -webkit-box;
        display: -webkit-flex;
        display: flex;
      }

      @descendent input {
        display: none;

      &:checked {
      + .mint-checkbox-core {
          background-color: $color-red;
          border-color: $color-red;

      &::after {
         border-color: $color-white;
         transform: rotate(45deg) scale(1);
       }
      }
    }

  &[disabled] + .mint-checkbox-core {
     background-color: $color-grey;
     border-color: #ccc;
   }
  }

  @descendent core {
    display: inline-block;
    background-color: $color-white;
    border-radius: 100%;
    border: 1px solid #ccc;
    position: relative;
    size: 40px;
    vertical-align: middle;
    top: 50%;
    transform: translateY(-50%);

  &::after {
     border: 2px solid transparent;
     border-left: 0;
     border-top: 0;
     content: " ";
     position: absolute 6px * * 12px;
     size: 8px 16px;
     transform: rotate(45deg) scale(0);
     transition: transform .2s;
   }
  }
  }
  }
</style>
