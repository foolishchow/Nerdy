import TabItem from './src/tab-item.vue';
export default TabItem;
