import IndexSection from './src/index-section.vue';
export default IndexSection;
