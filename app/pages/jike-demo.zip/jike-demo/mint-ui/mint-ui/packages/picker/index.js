import Picker from './src/picker.vue';
export default Picker;
