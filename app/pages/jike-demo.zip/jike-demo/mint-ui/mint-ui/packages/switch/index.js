import TabContainer from './src/switch.vue';
export default TabContainer;
