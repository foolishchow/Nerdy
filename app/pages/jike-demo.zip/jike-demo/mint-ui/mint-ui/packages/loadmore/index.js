import Loadmore from './src/loadmore.vue';
export default Loadmore;
