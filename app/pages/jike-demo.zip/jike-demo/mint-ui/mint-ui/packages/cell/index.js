import Cell from './src/cell.vue';
export default Cell;
