<script>
  export default {
    name: 'ai-radio-button',

    componentName: 'radio-button',

    props: {
      label: {
        type: [String, Number],
        required: true
      },
      disabled: Boolean,
      name: String
    },
    data() {
      return {
        size: this.$parent.size
      };
    },
    computed: {
      value: {
        get() {
          return this.$parent.value;
        },
        set(newValue) {
          this.$parent.$emit('input', newValue);
        }
      }
    }
  };
</script>

<template>
  <label
    class="radio-button"
    :class="[
      size ? 'radio-button-' + size : '',
      { 'is-active': value === label }
    ]"
  >
    <input
      class="radio-button-radio"
      :value="label"
      type="radio"
      v-model="value"
      :name="name"
      :disabled="disabled">
    <span class="radio-button-inner">
      <slot></slot>
      <template v-if="!$slots.default">{{label}}</template>
    </span>
  </label>
</template>

<style lang="css">
  @import "../../../src/style/var.css";

    @component radio-button {
      appearance: none;
      box-sizing: border-box;
      display: inline-block;
      font-size: 28px;
      height: 66px;
      line-height: 66px;
      padding:0 24px;
      margin-right:20px;
      outline: 0;
      overflow: hidden;
      position: relative;
      text-align: center;
      border: 1px solid #999;
      background-color: transparent;
      color: #666;



      @when active{
        border-color:#ec2f29;
        color:#ec2f29;
        background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaBAMAAABbZFH9AAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAhUExURUxpceswKOYwJOwvKOcuLuwwKe5BO/zc2/////SGgvvW1Kz7PxkAAAAFdFJOUwDUFccWAd+9PAAAAHBJREFUGNN1zlEJgEAQhOFDrGAAM4gBzCD/gQEOwQBiAzGAYAJzyumKOw/u2/Ax7ITwXdG4EGo8VQghhBBCCCGEEEIIIYSjuONo3HC0zDhaE0ZDyoTRMWfCWuOaCWvFJRPvjOm8v5c249nS4VP7m/oLygU+ll7PTwkAAAAASUVORK5CYII=');
        background-position:right bottom;
        background-repeat:no-repeat;
        background-size:26px;
      }




    }


</style>