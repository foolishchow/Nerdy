import Progress from './src/progress.vue';
export default Progress;
