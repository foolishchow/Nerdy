import LazyLoad from './src/lazyload.js';
import 'mint-ui/src/style/empty.css';

export default LazyLoad;
