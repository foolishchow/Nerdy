<template>
    <div class="mint-cell-spacing" :class="'is-' + theme"></div>
</template>
<script>
    export default {
        name:'ai-cell-spacing',
        props: {
            size:String,
            color:String,
            theme:String
        }
    }
</script>
<style lang="css">
    @import "../../../src/style/var.css";
    @component-namespace mint {
        @component cell-spacing {
            display: block;
            position: relative;
            width: 100%;
            height: 25px;
            background-color:  $color-bg;

            @when white{
                background-color: #fff;
            }
        }
    }
</style>