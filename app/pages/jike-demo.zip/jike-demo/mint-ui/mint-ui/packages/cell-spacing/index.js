import cellSpacing from './src/cell-spacing.vue'

export default cellSpacing;