import Search from './src/search.vue';
export default Search;
