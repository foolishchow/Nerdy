import Header from '../packages/header/index.js';
import Button from '../packages/button/index.js';
import Cell from '../packages/cell/index.js';
import CellSwipe from '../packages/cell-swipe/index.js';
import CellSpacing from '../packages/cell-spacing/index.js';
import Field from '../packages/field/index.js';
import Badge from '../packages/badge/index.js';
import Switch from '../packages/switch/index.js';
import Spinner from '../packages/spinner/index.js';
import TabItem from '../packages/tab-item/index.js';
import TabContainerItem from '../packages/tab-container-item/index.js';
import TabContainer from '../packages/tab-container/index.js';
import Navbar from '../packages/navbar/index.js';
import Tabbar from '../packages/tabbar/index.js';
import Search from '../packages/search/index.js';
import CheckboxGroup from '../packages/checkbox-group/index.js';
import Checkbox from '../packages/checkbox/index.js';
import RadioGroup from '../packages/radio-group/index.js';
import Radio from '../packages/radio/index.js';
import RadioButton from '../packages/radio-button/index.js';
import InputNumber from '../packages/input-number/index.js';
import Loadmore from '../packages/loadmore/index.js';
import Actionsheet from '../packages/actionsheet/index.js';
import Popup from '../packages/popup/index.js';
import Swipe from '../packages/swipe/index.js';
import SwipeItem from '../packages/swipe-item/index.js';
import Range from '../packages/range/index.js';
import Picker from '../packages/picker/index.js';
import Progress from '../packages/progress/index.js';
import Toast from '../packages/toast/index.js';
import Indicator from '../packages/indicator/index.js';
import MessageBox from '../packages/message-box/index.js';
import InfiniteScroll from '../packages/infinite-scroll/index.js';
import Lazyload from '../packages/lazyload/index.js';
import DatetimePicker from '../packages/datetime-picker/index.js';
import IndexList from '../packages/index-list/index.js';
import IndexSection from '../packages/index-section/index.js';
import PaletteButton from '../packages/palette-button/index.js';
import MenuBlock from '../custom/menu-block/index.js';
import '../src/assets/font/iconfont.css';
import _loading from './assets/loading-spin.svg';
const install = function(Vue) {
  if (install.installed) return;

  Vue.component(Header.name, Header);
  Vue.component(Button.name, Button);
  Vue.component(Cell.name, Cell);
  Vue.component(CellSwipe.name, CellSwipe);
  Vue.component(CellSpacing.name, CellSpacing);
  Vue.component(Field.name, Field);
  Vue.component(Badge.name, Badge);
  Vue.component(Switch.name, Switch);
  Vue.component(Spinner.name, Spinner);
  Vue.component(TabItem.name, TabItem);
  Vue.component(TabContainerItem.name, TabContainerItem);
  Vue.component(TabContainer.name, TabContainer);
  Vue.component(Navbar.name, Navbar);
  Vue.component(Tabbar.name, Tabbar);
  Vue.component(Search.name, Search);
  Vue.component(CheckboxGroup.name, CheckboxGroup);
  Vue.component(Checkbox.name, Checkbox);
  Vue.component(RadioGroup.name, RadioGroup);
  Vue.component(Radio.name, Radio);
  Vue.component(RadioButton.name, RadioButton);
  Vue.component(InputNumber.name, InputNumber);
  Vue.component(Loadmore.name, Loadmore);
  Vue.component(Actionsheet.name, Actionsheet);
  Vue.component(Popup.name, Popup);
  Vue.component(Swipe.name, Swipe);
  Vue.component(SwipeItem.name, SwipeItem);
  Vue.component(Range.name, Range);
  Vue.component(Picker.name, Picker);
  Vue.component(Progress.name, Progress);
  Vue.component(DatetimePicker.name, DatetimePicker);
  Vue.component(IndexList.name, IndexList);
  Vue.component(IndexSection.name, IndexSection);
  Vue.component(PaletteButton.name, PaletteButton);
  Vue.component(MenuBlock.name, MenuBlock);
  Vue.use(InfiniteScroll);
  Vue.use(Lazyload, {
    loading: _loading,
    try: 3
  });

  Vue.$messagebox = Vue.prototype.$messagebox = MessageBox;
  Vue.$toast = Vue.prototype.$toast = Toast;
  Vue.$indicator = Vue.prototype.$indicator = Indicator;
};

// auto install
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
};

const MINT = {
  install,
  version: '0.0.1',
  Header,
  Button,
  Cell,
  CellSwipe,
  CellSpacing,
  Field,
  Badge,
  Switch,
  Spinner,
  TabItem,
  TabContainerItem,
  TabContainer,
  Navbar,
  Tabbar,
  Search,
  CheckboxGroup,
  Checkbox,
  RadioGroup,
  Radio,
  RadioButton,
  InputNumber,
  Loadmore,
  Actionsheet,
  Popup,
  Swipe,
  SwipeItem,
  Range,
  Picker,
  Progress,
  Toast,
  Indicator,
  MessageBox,
  InfiniteScroll,
  Lazyload,
  DatetimePicker,
  IndexList,
  IndexSection,
  PaletteButton,
  MenuBlock
};
export default MINT;
