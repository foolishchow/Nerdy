import MenuBlock from './src/menu-block.vue'
export default MenuBlock;