<template>
    <div class="mint-menu-block">
        <div class="icons" :style="{'background-color':color}">
            <i class="aicon" :class="'aicon-'+icon" ></i>
        </div>
        <span>
            <slot></slot>
        </span>
    </div>
</template>
<script>
    export default {
        name: 'ai-menu-block',
        props:{
            icon:{
                type:String,
                default:""
            },
            color:{
                type:String,
                default:''
            }
        }
    }
</script>
<style lang="css">
    @import "../../../src/style/var.css";

    @component-namespace mint {
        @component menu-block {
            display:block;
            width: 3.75rem;
            float: left;
            height: 3.75rem;
            text-align:center;
            color: #666;

            &>.icons{
                width: 2rem;
                height: 2rem;
                position: relative;
                text-align: center;
                margin: .5rem auto 0.2rem;
                background-color: #ff3a47;
                border-radius: 1rem;

                &>.aicon{
                    display:  inline-block;;
                    font-size: .9rem;
                    font-weight: bold;
                    color: #fff;
                    line-height:2rem;
                }
            }
        }
    }
</style>