const gulp = require('gulp'),
    gulp_concat = require('gulp-concat'),
    gulp_usemin = require('gulp-usemin'),
    gulp_header = require('gulp-header'),
    gulp_uglify = require('gulp-uglify'),
    gulp_minify_css = require('gulp-minify-css'),
    gulp_minify_html = require('gulp-minify-html'),
    gulp_clean = require('gulp-clean'),
    gulp_configration = require('gulp-configration'),
    gulp_rename = require('gulp-rename'),
    gulp_connect = require('gulp-connect'),
    gulp_log = require('gulp-log');

//清除dist目录
gulp.task('clean',function(){
    return gulp.src(['./dist/'])
            .pipe(gulp_clean({read:false}))
});
//把需要的文件拷贝到dist
gulp.task('copy',['clean'],function() {
    return gulp.src([
        './src/**/*.js',
        './src/**/*.css',
        './src/**/*.html',
        ])
        .pipe(gulp.dest('./dist'))
});
//处理html文件
gulp.task('usemin',['copy'],function() {
    return gulp.src(['./src/pages/*.html'])
        .pipe(gulp_usemin())
        .pipe(gulp_minify_html())
        .pipe(gulp.dest('./dist/pages'))
});
//压缩js
gulp.task('uglify',['usemin'],function(){
    return gulp.src(['./dist/**/*.js'])
                .pipe(gulp_uglify())
                .pipe(gulp_header('/* this is my js header */'))
                .pipe(gulp.dest('./dist/'));
});
//压缩css
gulp.task('minifycss',['uglify'],function(){
    return gulp.src(['./dist/**/*.css'])
                .pipe(gulp_minify_css())
                .pipe(gulp_header('/* this is my css header */'))
                .pipe(gulp.dest('./dist/'));
});
//开启http
gulp.task('server',function(){
    return gulp_connect.server({
        root: ['./src'],
        port: 9000,
        livereload: false
    });
});

gulp.task('default',['minifycss','server'])


