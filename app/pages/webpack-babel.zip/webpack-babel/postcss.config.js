module.exports = {
    plugins: [
        require('postcss-salad')(),
    ]
};