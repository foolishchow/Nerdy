const delay = (time) => {
    return new Promise(function(r) {
        setTimeout(function() {
            r()
        }, time);
    })
}

export { delay }
