import '../css/index.css'
import {delay} from './promise'

delay(2000).then(()=>{
    console.info("inited")
})