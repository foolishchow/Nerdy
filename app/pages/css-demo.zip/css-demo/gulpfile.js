var gulp = require('gulp');
var postcss = require('gulp-postcss');
var salad = require('postcss-salad');
var bem = require('postcss-bem');

var options = {
    browsers: ['ie > 8', 'last 2 version'],
    features: {
        "bem": true, //pass boolean false can disable the plugin
        "inlineSvg": {
            "path": "src/svgs"
        }
    }
}

gulp.task('css', function() {
    return gulp.src(['./src/*.css'])
        .pipe(
            postcss([
                salad(options)
            ])
        ).pipe(gulp.dest('./dist'));
});
